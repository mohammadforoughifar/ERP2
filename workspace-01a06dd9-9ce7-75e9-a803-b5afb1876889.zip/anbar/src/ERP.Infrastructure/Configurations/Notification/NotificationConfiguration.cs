using ERP.Domain.Entities.Notification;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace ERP.Infrastructure.Configurations.Notification;

public class NotificationConfiguration : IEntityTypeConfiguration<Notification>
{
    public void Configure(EntityTypeBuilder<Notification> builder)
    {
        builder.ToTable("Notifications");
        builder.HasKey(x => x.Id);
        builder.Property(x => x.Title).HasMaxLength(200).IsRequired();
        builder.Property(x => x.Message).HasMaxLength(2000);
        builder.Property(x => x.Type).HasMaxLength(50).HasDefaultValue("InApp");
        builder.Property(x => x.Status).HasMaxLength(50).HasDefaultValue("Unread");
        builder.Property(x => x.IsActive).HasDefaultValue(true);
    }
}
