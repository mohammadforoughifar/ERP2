using ERP.Domain.Entities.Search;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace ERP.Infrastructure.Configurations.Search;

public class SearchQueryConfiguration : IEntityTypeConfiguration<SearchQuery>
{
    public void Configure(EntityTypeBuilder<SearchQuery> builder)
    {
        builder.ToTable("SearchQueries");
        builder.HasKey(x => x.Id);
        builder.Property(x => x.QueryText).HasMaxLength(200).IsRequired();
        builder.Property(x => x.SearchType).HasMaxLength(50).HasDefaultValue("FullText");
        builder.Property(x => x.IsActive).HasDefaultValue(true);
    }
}
