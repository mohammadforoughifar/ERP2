using ERP.Domain.Entities.Event;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
namespace ERP.Infrastructure.Configurations.Event;
public class DomainEventConfiguration : IEntityTypeConfiguration<DomainEvent>
{
    public void Configure(EntityTypeBuilder<DomainEvent> builder)
    {
        builder.ToTable("DomainEvents");
        builder.HasKey(x => x.Id);
        builder.Property(x => x.EventName).HasMaxLength(200).IsRequired();
        builder.Property(x => x.Payload).HasMaxLength(500);
        builder.Property(x => x.Status).HasMaxLength(50).HasDefaultValue("Pending");
        builder.Property(x => x.IsActive).HasDefaultValue(true);
    }
}
