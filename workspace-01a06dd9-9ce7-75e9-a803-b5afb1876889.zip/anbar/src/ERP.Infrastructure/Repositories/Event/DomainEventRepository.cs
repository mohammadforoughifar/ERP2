using ERP.Application.Interfaces;
using ERP.Domain.Entities.Event;
using ERP.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
namespace ERP.Infrastructure.Repositories.Event;
public class DomainEventRepository : IDomainEventRepository
{
    private readonly ApplicationDbContext _context;
    public DomainEventRepository(ApplicationDbContext context) { _context = context; }
    public async Task<DomainEvent?> GetByIdAsync(int id) => await _context.DomainEvents.Where(x => x.IsActive == true).FirstOrDefaultAsync(x => x.Id == id);
    public async Task<IEnumerable<DomainEvent>> GetActiveAsync() => await _context.DomainEvents.Where(x => x.IsActive == true).ToListAsync();
    public async Task AddAsync(DomainEvent domainEvent) { await _context.DomainEvents.AddAsync(domainEvent); await _context.SaveChangesAsync(); }
    public async Task UpdateAsync(DomainEvent domainEvent) { _context.DomainEvents.Update(domainEvent); await _context.SaveChangesAsync(); }
    public async Task DeleteAsync(DomainEvent domainEvent) { domainEvent.IsActive = false; _context.DomainEvents.Update(domainEvent); await _context.SaveChangesAsync(); }
}
