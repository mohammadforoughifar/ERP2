using ERP.Application.Interfaces;
using ERP.Domain.Entities.Notification;
using ERP.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ERP.Infrastructure.Repositories.Notification;

public class NotificationRepository : INotificationRepository
{
    private readonly ApplicationDbContext _context;

    public NotificationRepository(ApplicationDbContext context)
    {
        _context = context;
    }

    public async Task<Notification?> GetByIdAsync(int id)
    {
        return await _context.Notifications
            .Where(x => x.IsActive == true)
            .FirstOrDefaultAsync(x => x.Id == id);
    }

    public async Task<IEnumerable<Notification>> GetActiveAsync()
    {
        return await _context.Notifications
            .Where(x => x.IsActive == true)
            .ToListAsync();
    }

    public async Task AddAsync(Notification notification)
    {
        await _context.Notifications.AddAsync(notification);
        await _context.SaveChangesAsync();
    }

    public async Task UpdateAsync(Notification notification)
    {
        _context.Notifications.Update(notification);
        await _context.SaveChangesAsync();
    }

    public async Task DeleteAsync(Notification notification)
    {
        notification.IsActive = false;
        _context.Notifications.Update(notification);
        await _context.SaveChangesAsync();
    }
}
