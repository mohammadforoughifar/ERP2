using ERP.Application.Interfaces;
using ERP.Domain.Entities.Search;
using ERP.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
namespace ERP.Infrastructure.Repositories.Search;
public class SearchQueryRepository : ISearchQueryRepository
{
    private readonly ApplicationDbContext _context;
    public SearchQueryRepository(ApplicationDbContext context) { _context = context; }
    public async Task<SearchQuery?> GetByIdAsync(int id) => await _context.SearchQueries.Where(x => x.IsActive == true).FirstOrDefaultAsync(x => x.Id == id);
    public async Task<IEnumerable<SearchQuery>> GetActiveAsync() => await _context.SearchQueries.Where(x => x.IsActive == true).ToListAsync();
    public async Task AddAsync(SearchQuery query) { await _context.SearchQueries.AddAsync(query); await _context.SaveChangesAsync(); }
    public async Task UpdateAsync(SearchQuery query) { _context.SearchQueries.Update(query); await _context.SaveChangesAsync(); }
    public async Task DeleteAsync(SearchQuery query) { query.IsActive = false; _context.SearchQueries.Update(query); await _context.SaveChangesAsync(); }
}
