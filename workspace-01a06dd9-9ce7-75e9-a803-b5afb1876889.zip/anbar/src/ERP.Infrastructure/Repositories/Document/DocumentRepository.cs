using ERP.Application.Interfaces;
using ERP.Domain.Entities.Document;
using ERP.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
namespace ERP.Infrastructure.Repositories.Document;
public class DocumentRepository : IDocumentRepository
{
    private readonly ApplicationDbContext _context;
    public DocumentRepository(ApplicationDbContext context) { _context = context; }
    public async Task<Document?> GetByIdAsync(int id) => await _context.Documents.Where(x => x.IsActive == true).FirstOrDefaultAsync(x => x.Id == id);
    public async Task<IEnumerable<Document>> GetActiveAsync() => await _context.Documents.Where(x => x.IsActive == true).ToListAsync();
    public async Task AddAsync(Document document) { await _context.Documents.AddAsync(document); await _context.SaveChangesAsync(); }
    public async Task UpdateAsync(Document document) { _context.Documents.Update(document); await _context.SaveChangesAsync(); }
    public async Task DeleteAsync(Document document) { document.IsActive = false; _context.Documents.Update(document); await _context.SaveChangesAsync(); }
}
