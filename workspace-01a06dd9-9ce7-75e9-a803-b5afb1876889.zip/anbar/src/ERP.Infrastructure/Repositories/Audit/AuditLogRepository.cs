using ERP.Application.Interfaces;
using ERP.Domain.Entities.Audit;
using ERP.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ERP.Infrastructure.Repositories.Audit;

public class AuditLogRepository : IAuditLogRepository
{
    private readonly ApplicationDbContext _context;

    public AuditLogRepository(ApplicationDbContext context)
    {
        _context = context;
    }

    public async Task<AuditLog?> GetByIdAsync(int id)
    {
        return await _context.AuditLogs
            .Where(x => x.IsActive == true)
            .FirstOrDefaultAsync(x => x.Id == id);
    }

    public async Task<IEnumerable<AuditLog>> GetActiveAsync()
    {
        return await _context.AuditLogs
            .Where(x => x.IsActive == true)
            .ToListAsync();
    }

    public async Task AddAsync(AuditLog auditLog)
    {
        await _context.AuditLogs.AddAsync(auditLog);
        await _context.SaveChangesAsync();
    }

    public async Task UpdateAsync(AuditLog auditLog)
    {
        _context.AuditLogs.Update(auditLog);
        await _context.SaveChangesAsync();
    }

    public async Task DeleteAsync(AuditLog auditLog)
    {
        auditLog.IsActive = false;
        _context.AuditLogs.Update(auditLog);
        await _context.SaveChangesAsync();
    }
}
