using ERP.Domain.Entities.FormBuilder;
using ERP.Domain.Entities.HR;
using ERP.Domain.Entities.Payroll;
using ERP.Domain.Entities.Reporting;
using ERP.Domain.Entities.Integration;
using ERP.Domain.Entities.AI;
using ERP.Domain.Entities.Notification;
using ERP.Domain.Entities.Event;
using ERP.Domain.Entities.Document;
using ERP.Domain.Entities.Search;
using ERP.Domain.Entities.Audit;
using Microsoft.EntityFrameworkCore;
using ERP.Domain.Entities;

namespace ERP.Infrastructure.Data;

/// <summary>
/// ApplicationDbContext — Phase 1 Core Database
/// Per proposal: SQL Server, EF Core 8, Multi-Tenant Filter, Audit Columns, RowVersion
/// Naming: PascalCase tables mapped to SQL Server standard
/// </summary>
public class ApplicationDbContext : DbContext
{
    public DbSet<Tenant> Tenants { get; set; } = null!;
    public DbSet<Company> Companies { get; set; } = null!;
    public DbSet<Branch> Branches { get; set; } = null!;
    public DbSet<User> Users { get; set; } = null!;
    public DbSet<Role> Roles { get; set; } = null!;
    public DbSet<Permission> Permissions { get; set; } = null!;
    public DbSet<UserRole> UserRoles { get; set; } = null!;

    public DbSet<DynamicForm> DynamicForms { get; set; } = null!;
    public DbSet<DynamicFormField> DynamicFormFields { get; set; } = null!;
    public DbSet<DynamicFormInstance> DynamicFormInstances { get; set; } = null!;
    public DbSet<DynamicFormFieldValue> DynamicFormFieldValues { get; set; } = null!;

    public DbSet<Mission> Missions { get; set; } = null!;
    public DbSet<Overtime> Overtimes { get; set; } = null!;
    public DbSet<Evaluation> Evaluations { get; set; } = null!;
    public DbSet<Training> Trainings { get; set; } = null!;
    public DbSet<Salary> Salaries { get; set; } = null!;
    public DbSet<Tax> Taxes { get; set; } = null!;
    public DbSet<Allowance> Allowances { get; set; } = null!;
    public DbSet<Bonus> Bonuses { get; set; } = null!;
    public DbSet<Loan> Loans { get; set; } = null!;
    public DbSet<Insurance> Insurances { get; set; } = null!;

    public DbSet<Report> Reports { get; set; } = null!;
    public DbSet<Chart> Charts { get; set; } = null!;
    public DbSet<Pivot> Pivots { get; set; } = null!;
    public DbSet<Dashboard> Dashboards { get; set; } = null!;
    public DbSet<KPI> KPIs { get; set; } = null!;

    public DbSet<IntegrationEndpoint> IntegrationEndpoints { get; set; } = null!;
    public DbSet<IntegrationConfig> IntegrationConfigs { get; set; } = null!;
    public DbSet<IntegrationMessage> IntegrationMessages { get; set; } = null!;
    public DbSet<IntegrationLog> IntegrationLogs { get; set; } = null!;
    public DbSet<ImportExportJob> ImportExportJobs { get; set; } = null!;

    public DbSet<AIAgent> AIAgents { get; set; } = null!;
    public DbSet<AIPrompt> AIPrompts { get; set; } = null!;
    public DbSet<AIResponse> AIResponses { get; set; } = null!;
    public DbSet<AIAnalysis> AIAnalyses { get; set; } = null!;
    public DbSet<AIPrediction> AIPredictions { get; set; } = null!;
    public DbSet<AIInsight> AIInsights { get; set; } = null!;
    public DbSet<Notification.Notification> Notifications { get; set; } = null!;
    public DbSet<Audit.AuditLog> AuditLogs { get; set; } = null!;
    public DbSet<Search.SearchQuery> SearchQueries { get; set; } = null!;
    public DbSet<Document.Document> Documents { get; set; } = null!;
    public DbSet<Event.DomainEvent> DomainEvents { get; set; } = null!;

    public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
    {
    }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.ApplyConfigurationsFromAssembly(typeof(ApplicationDbContext).Assembly);
        base.OnModelCreating(modelBuilder);
    }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        // SQL Server connection configured via DI / appsettings
        // Example: Server=.;Database=ERP_Enterprise;Trusted_Connection=True;TrustServerCertificate=True;
        base.OnConfiguring(optionsBuilder);
    }
}
