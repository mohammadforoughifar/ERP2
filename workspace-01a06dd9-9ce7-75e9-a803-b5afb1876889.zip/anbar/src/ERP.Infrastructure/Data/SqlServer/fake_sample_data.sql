-- ============================================
-- ERP Enterprise — Fake / Sample Data (SQL Server)
-- Multi-Tenant, Audit Columns, All Phases + Modules
-- Fake data for demonstration / testing only
-- ============================================

USE ERP_Enterprise;
GO

SET NOCOUNT ON;
GO

-- ============================================
-- CORE: TENANTS
-- ============================================
INSERT INTO erp.Tenants (Name, Code, IsActive, CreatedBy, CreatedAt)
VALUES
    ('شرکت نمونه الف', 'CO-001', 1, 'system', '2024-01-01'),
    ('شرکت نمونه ب', 'CO-002', 1, 'system', '2024-02-15'),
    ('شرکت نمونه ج', 'CO-003', 1, 'system', '2024-03-10');

-- ============================================
-- CORE: COMPANIES
-- ============================================
INSERT INTO erp.Companies (TenantId, Name, TaxNumber, Address, BranchId, IsActive, CreatedBy, CreatedAt)
VALUES
    (1, 'شرکت فناوری نوین', '9876543210', 'تهران، خیابان ولیعصر، برج فناوری', 1, 1, 'system', '2024-01-02'),
    (2, 'گروه صنعتی پیشتاز', '1234567890', 'اصفهان، شهرک صنعتی شماره ۳', NULL, 1, 'system', '2024-02-16'),
    (3, 'شرکت بازرگانی بین‌الملل', '1122334455', 'شیراز، بلوار امیرکبیر، ساختمان تجاری', 2, 1, 'system', '2024-03-11');

-- ============================================
-- CORE: BRANCHES
-- ============================================
INSERT INTO erp.Branches (CompanyId, Name, Code, Address, IsActive, CreatedBy, CreatedAt)
VALUES
    (1, 'شعبه تهران مرکزی', 'BR-001', 'تهران، خیابان انقلاب، ساختمان مرکزی', 1, 'system', '2024-01-03'),
    (1, 'شعبه اصفهان', 'BR-002', 'اصفهان، خیابان چهارباغ، مرکز تجاری', 1, 'system', '2024-01-05'),
    (2, 'شعبه تبریز', 'BR-003', 'تبریز، خیابان ولیعصر، مجتمع تجاری', 1, 'system', '2024-02-17');

-- ============================================
-- CORE: ROLES
-- ============================================
INSERT INTO erp.Roles (Name, Description, IsActive, CreatedBy, CreatedAt)
VALUES
    ('مدیر سیستم', 'دسترسی کامل به همه ماژول‌ها', 1, 'system', '2024-01-01'),
    ('مدیر مالی', 'دسترسی به گزارش‌گیری و مالی', 1, 'system', '2024-01-01'),
    ('کارمند', 'دسترسی محدود به وظایف روزانه', 1, 'system', '2024-01-01'),
    ('مدیر منابع انسانی', 'دسترسی به HR و حقوق', 1, 'system', '2024-01-01'),
    ('مدیر انبار', 'دسترسی به موجودی و انبار', 1, 'system', '2024-01-01');

-- ============================================
-- CORE: USERS (Fake)
-- ============================================
INSERT INTO erp.Users (TenantId, Username, FullName, Email, PasswordHash, Role, IsActive, CreatedBy, CreatedAt)
VALUES
    (1, 'admin.co1', 'علی رضایی', 'ali@co1.ir', 'HASH-ADMIN-1', 'مدیر سیستم', 1, 'system', '2024-01-01'),
    (1, 'finance.co1', 'سارا کریمی', 'sara@co1.ir', 'HASH-FIN-1', 'مدیر مالی', 1, 'system', '2024-01-02'),
    (1, 'hr.co1', 'محمد احمدی', 'mohammad@co1.ir', 'HASH-HR-1', 'مدیر منابع انسانی', 1, 'system', '2024-01-03'),
    (2, 'warehouse.co2', 'فاطمه حسینی', 'fatemeh@co2.ir', 'HASH-WH-1', 'مدیر انبار', 1, 'system', '2024-02-16'),
    (3, 'employee.co3', 'رضا نوری', 'reza@co3.ir', 'HASH-EMP-1', 'کارمند', 1, 'system', '2024-03-11');

-- ============================================
-- CORE: PERMISSIONS
-- ============================================
INSERT INTO erp.Permissions (Name, Resource, IsActive, CreatedBy, CreatedAt)
VALUES
    ('مدیریت کاربران', 'Users', 1, 'system', '2024-01-01'),
    ('مشاهده گزارش‌ها', 'Reports', 1, 'system', '2024-01-01'),
    ('مدیریت اسناد', 'Documents', 1, 'system', '2024-01-01'),
    ('جستجو', 'Search', 1, 'system', '2024-01-01'),
    ('رویدادها', 'Events', 1, 'system', '2024-01-01');

-- ============================================
-- CORE: USER ROLES
-- ============================================
INSERT INTO erp.UserRoles (UserId, RoleId)
VALUES
    (1, 1), (2, 2), (3, 4), (4, 5), (5, 3);

-- ============================================
-- FORM BUILDER (Sample)
-- ============================================
INSERT INTO erp.DynamicForms (TenantId, FormName, Description, IsActive, CreatedBy, CreatedAt)
VALUES
    (1, 'فرم استخدام', 'فرم ثبت اطلاعات استخدام جدید', 1, 'system', '2024-01-05'),
    (1, 'فرم ارزیابی', 'فرم ارزیابی عملکرد کارکنان', 1, 'system', '2024-01-06');

INSERT INTO erp.DynamicFormFields (FormId, FieldName, FieldType, IsRequired, SortOrder, IsActive, CreatedBy, CreatedAt)
VALUES
    (1, 'نام و نام خانوادگی', 'Text', 1, 1, 1, 'system', '2024-01-05'),
    (1, 'کد ملی', 'Text', 1, 2, 1, 'system', '2024-01-05'),
    (2, 'نمره عملکرد', 'Number', 1, 1, 1, 'system', '2024-01-06'),
    (2, 'نظرات', 'TextArea', 0, 2, 1, 'system', '2024-01-06');

INSERT INTO erp.DynamicFormInstances (FormId, InstanceName, Status, IsActive, CreatedBy, CreatedAt)
VALUES
    (1, 'نمونه استخدام ۱', 'Submitted', 1, 'system', '2024-01-10'),
    (2, 'نمونه ارزیابی فصل اول', 'Draft', 1, 'system', '2024-01-15');

INSERT INTO erp.DynamicFormFieldValues (InstanceId, FieldId, Value, IsActive, CreatedBy, CreatedAt)
VALUES
    (1, 1, 'علی رضایی نمونه', 1, 'system', '2024-01-10'),
    (1, 2, '1234567890', 1, 'system', '2024-01-10');

-- ============================================
-- HR: MISSIONS
-- ============================================
INSERT INTO erp.Missions (TenantId, EmployeeId, Destination, Purpose, StartDate, EndDate, Status, IsActive, CreatedBy, CreatedAt)
VALUES
    (1, 1, 'تهران → اصفهان', 'جلسه با مشتری کلیدی', '2024-01-20', '2024-01-22', 'Completed', 1, 'system', '2024-01-15'),
    (2, 4, 'تبریز → تهران', 'ارزیابی انبار مرکزی', '2024-03-01', '2024-03-03', 'Pending', 1, 'system', '2024-02-25');

-- ============================================
-- HR: OVERTIME
-- ============================================
INSERT INTO erp.Overtimes (TenantId, EmployeeId, Hours, Rate, Date, Status, IsActive, CreatedBy, CreatedAt)
VALUES
    (1, 2, 8.5, 150000, '2024-01-28', 'Approved', 1, 'system', '2024-01-29'),
    (3, 5, 4.0, 100000, '2024-03-05', 'Pending', 1, 'system', '2024-03-06');

-- ============================================
-- HR: EVALUATIONS
-- ============================================
INSERT INTO erp.Evaluations (TenantId, EmployeeId, Score, Comment, Period, IsActive, CreatedBy, CreatedAt)
VALUES
    (1, 1, 4.8, 'عملکرد عالی در مدیریت پروژه‌ها', 'Q1-2024', 1, 'system', '2024-03-31'),
    (1, 3, 4.2, 'نیاز به بهبود در ارتباطات داخلی', 'Q1-2024', 1, 'system', '2024-03-31');

-- ============================================
-- HR: SALARIES
-- ============================================
INSERT INTO erp.Salaries (TenantId, EmployeeId, BaseSalary, EffectiveDate, Status, IsActive, CreatedBy, CreatedAt)
VALUES
    (1, 1, 85000000, '2024-01-01', 'Active', 1, 'system', '2024-01-01'),
    (1, 2, 62000000, '2024-01-02', 'Active', 1, 'system', '2024-01-02'),
    (2, 4, 55000000, '2024-02-16', 'Active', 1, 'system', '2024-02-16');

-- ============================================
-- HR: BONUSES
-- ============================================
INSERT INTO erp.Bonuses (TenantId, EmployeeId, Amount, Reason, IssueDate, Status, IsActive, CreatedBy, CreatedAt)
VALUES
    (1, 1, 15000000, 'پروژه موفق', '2024-03-01', 'Paid', 1, 'system', '2024-03-02'),
    (2, 4, 8000000, 'بهبود فرآیند انبار', '2024-03-15', 'Pending', 1, 'system', '2024-03-16');

-- ============================================
-- HR: TAXES
-- ============================================
INSERT INTO erp.Taxes (Name, Rate, Type, IsActive, CreatedBy, CreatedAt)
VALUES
    ('مالیات بر درآمد', 0.0900, 'Income', 1, 'system', '2024-01-01'),
    ('مالیات بر ارزش افزوده', 0.0900, 'VAT', 1, 'system', '2024-01-01');

-- ============================================
-- HR: ALLOWANCES
-- ============================================
INSERT INTO erp.Allowances (Name, Amount, Type, IsActive, CreatedBy, CreatedAt)
VALUES
    ('حق مسکن', 5000000, 'Monthly', 1, 'system', '2024-01-01'),
    ('حق غذا', 1500000, 'Monthly', 1, 'system', '2024-01-01');

-- ============================================
-- AI: AGENTS
-- ============================================
INSERT INTO erp.AIAgents (Name, Description, Model, Temperature, MaxTokens, IsActive, CreatedBy, CreatedAt)
VALUES
    ('دستیار مالی', 'تحلیل داده‌های مالی و پیش‌بینی بودجه', 'GPT-4', 0.5, 2048, 1, 'system', '2024-01-05'),
    ('دستیار منابع انسانی', 'ارزیابی عملکرد و پیشنهاد آموزش', 'GPT-4', 0.7, 2048, 1, 'system', '2024-01-06');

INSERT INTO erp.AIPrompts (AgentId, PromptText, ContextType, IsActive, CreatedBy, CreatedAt)
VALUES
    (1, 'بودجه فصل بعدی را با توجه به داده‌های مالی تحلیل و پیشنهاد بده.', 'Finance', 1, 'system', '2024-01-05'),
    (2, 'عملکرد کارکنان را تحلیل و نقاط بهبود را شناسایی کن.', 'HR', 1, 'system', '2024-01-06');

INSERT INTO erp.AIResponses (AgentId, PromptId, ResponseText, TokenUsage, CreatedBy, CreatedAt)
VALUES
    (1, 1, 'با توجه به داده‌های مالی، بودجه فصل آینده ۱۵٪ افزایش پیشنهاد می‌شود.', 320, 'system', '2024-01-10'),
    (2, 2, 'عملکرد کارکنان در بخش فروش نیاز به بهبود ارتباط با مشتری دارد.', 280, 'system', '2024-01-12');

INSERT INTO erp.AIAnalyses (AgentId, InputData, AnalysisResult, ConfidenceScore, IsActive, CreatedBy, CreatedAt)
VALUES
    (1, '{"revenue": 850000000, "cost": 620000000}', '{"profit_margin": 0.27, "trend": "positive"}', 0.92, 1, 'system', '2024-01-08'),
    (2, '{"performance_scores": [4.8, 4.2, 3.9]}', '{"average": 4.3, "suggestion": "training"}', 0.85, 1, 'system', '2024-01-14');

INSERT INTO erp.AIPredictions (AgentId, PredictionType, PredictionValue, AccuracyScore, TargetDate, IsActive, CreatedBy, CreatedAt)
VALUES
    (1, 'RevenueForecast', '920000000', 0.88, '2024-06-30', 1, 'system', '2024-01-20'),
    (2, 'TurnoverRisk', 'Low', 0.76, '2024-12-31', 1, 'system', '2024-02-01');

INSERT INTO erp.AIInsights (InsightTitle, InsightContent, Priority, RelatedEntity, AgentId, IsActive, CreatedBy, CreatedAt)
VALUES
    ('افزایش بودجه', 'بودجه فصل آینده با توجه به رشد فروش ۱۵٪ افزایش یابد.', 'High', 'Finance', 1, 1, 'system', '2024-01-11'),
    ('آموزش ارتباطات', 'کارکنان بخش فروش نیاز به آموزش ارتباط با مشتری دارند.', 'Medium', 'HR', 2, 1, 'system', '2024-01-13');

-- ============================================
-- NOTIFICATION
-- ============================================
INSERT INTO erp.Notifications (TenantId, UserId, Title, Message, Type, Status, IsActive, CreatedBy, CreatedAt)
VALUES
    (1, 1, 'گزارش مالی آماده است', 'گزارش فصل اول آماده دانلود است.', 'InApp', 'Unread', 1, 'system', '2024-03-31'),
    (1, 2, 'یادآوری پرداخت', 'پرداخت حقوق کارکنان تا پایان هفته.', 'Email', 'Unread', 1, 'system', '2024-03-28'),
    (2, 4, 'هشدار انبار', 'موجودی کالای شماره ۵ به حداقل رسیده است.', 'SMS', 'Read', 1, 'system', '2024-03-15');

-- ============================================
-- AUDIT
-- ============================================
INSERT INTO erp.AuditLogs (TenantId, UserId, Action, TableName, RecordId, OldValue, NewValue, IPAddress, LogTime, IsActive, CreatedBy, CreatedAt)
VALUES
    (1, 1, 'UPDATE', 'Users', '1', '{"Role":"مدیر سیستم"}', '{"FullName":"علی رضایی (به‌روزرسانی)"}', '192.168.1.10', '2024-01-20 10:30:00', 1, 'system', '2024-01-20'),
    (1, 2, 'CREATE', 'Documents', '5', NULL, '{"FileName":"قرارداد_نمونه.pdf"}', '192.168.1.15', '2024-01-22 14:00:00', 1, 'system', '2024-01-22'),
    (2, 4, 'DELETE', 'AuditLogs', '3', '{"Status":"Active"}', NULL, '192.168.1.20', '2024-03-10 09:15:00', 1, 'system', '2024-03-10');

-- ============================================
-- SEARCH
-- ============================================
INSERT INTO erp.SearchQueries (TenantId, UserId, QueryText, SearchType, ResultCount, Status, IsActive, CreatedBy, CreatedAt)
VALUES
    (1, 1, 'گزارش فروش فصل اول', 'FullText', 12, 'Completed', 1, 'system', '2024-01-30'),
    (1, 3, 'مشاهده اسناد استخدام', 'Barcode', 3, 'Completed', 1, 'system', '2024-02-01'),
    (2, 4, 'موجودی انبار شماره ۵', 'QR', 1, 'Completed', 1, 'system', '2024-03-10');

-- ============================================
-- DOCUMENT MANAGEMENT
-- ============================================
INSERT INTO erp.Documents (TenantId, FileName, FilePath, FileSize, MimeType, Version, DocumentType, Tags, IsSigned, SignatureUserId, PreviewPath, OCRText, Status, IsActive, CreatedBy, CreatedAt)
VALUES
    (1, 'قرارداد_نمونه.pdf', '/uploads/contract_sample.pdf', 245760, 'application/pdf', '1.0', 'Contract', 'قرارداد;نمونه', 1, 1, '/previews/contract_sample.jpg', 'متن OCR شده از اسکن قرارداد...', 'Active', 1, 'system', '2024-01-25'),
    (1, 'گزارش_مالی_فصل_اول.pdf', '/uploads/financial_report_q1.pdf', 512000, 'application/pdf', '2.0', 'Report', 'مالی;گزارش;فصل اول', 0, NULL, '/previews/financial_report_q1.jpg', 'گزارش مالی فصل اول: درآمد ۸۵۰ میلیون، هزینه ۶۲۰ میلیون...', 'Active', 1, 'system', '2024-03-31'),
    (2, 'فاکتور_خرید_اسفند.pdf', '/uploads/invoice_03.pdf', 128000, 'application/pdf', '1.1', 'Invoice', 'فاکتور;خرید', 1, 4, '/previews/invoice_03.jpg', NULL, 'Active', 1, 'system', '2024-03-05');

-- ============================================
-- EVENT ARCHITECTURE
-- ============================================
INSERT INTO erp.DomainEvents (EventName, Payload, EventType, Status, SourceEntity, SourceId, RetryCount, IsActive, CreatedBy, CreatedAt)
VALUES
    ('DocumentUploaded', '{"documentId":1,"userId":1,"fileName":"قرارداد_نمونه.pdf"}', 'Domain', 'Processed', 'Document', '1', 0, 1, 'system', '2024-01-25'),
    ('NotificationSent', '{"notificationId":1,"userId":1,"type":"InApp"}', 'Integration', 'Processed', 'Notification', '1', 0, 1, 'system', '2024-03-31'),
    ('AuditLogCreated', '{"auditLogId":2,"action":"CREATE","table":"Documents"}', 'Domain', 'Processed', 'AuditLog', '2', 0, 1, 'system', '2024-01-22'),
    ('EmployeeUpdated', '{"userId":1,"changes":{"FullName":"به‌روزرسانی شده"}}', 'Domain', 'Pending', 'User', '1', 0, 1, 'system', '2024-01-20');

-- ============================================
-- REPORTING / BI
-- ============================================
INSERT INTO erp.Reports (TenantId, ReportName, ReportType, QueryDef, Format, IsActive, CreatedBy, CreatedAt)
VALUES
    (1, 'گزارش فروش ماهانه', 'Table', 'SELECT * FROM Sales WHERE Month = ''2024-01''', 'PDF', 1, 'system', '2024-01-01'),
    (2, 'گزارش انبار فصلی', 'Chart', 'SELECT ProductId, SUM(Quantity) FROM Inventory GROUP BY ProductId', 'Excel', 1, 'system', '2024-02-01');

INSERT INTO erp.Charts (ReportId, ChartType, DataSource, IsActive, CreatedBy, CreatedAt)
VALUES
    (1, 'Bar', 'SalesData', 1, 'system', '2024-01-02'),
    (2, 'Line', 'InventoryData', 1, 'system', '2024-02-03');

INSERT INTO erp.Pivots (ReportId, Rows, Columns, Values, IsActive, CreatedBy, CreatedAt)
VALUES
    (1, 'ProductCategory', 'Month', 'TotalSales', 1, 'system', '2024-01-04'),
    (2, 'Warehouse', 'Quarter', 'StockQuantity', 1, 'system', '2024-02-05');

INSERT INTO erp.Dashboards (TenantId, Title, Layout, IsActive, CreatedBy, CreatedAt)
VALUES
    (1, 'داشبورد مدیریت', '{"widgets":[{"type":"KPI"},{"type":"Chart"}]}', 1, 'system', '2024-01-05'),
    (2, 'داشبورد انبار', '{"widgets":[{"type":"Table"},{"type":"Chart"}]}', 1, 'system', '2024-02-06');

INSERT INTO erp.KPIs (Name, TargetValue, Unit, IsActive, CreatedBy, CreatedAt)
VALUES
    ('درآمد ماهانه', 1000000000, 'IRR', 1, 'system', '2024-01-01'),
    ('نرخ رضایت کارکنان', 85, 'Percent', 1, 'system', '2024-01-02'),
    ('دقت پیش‌بینی', 90, 'Percent', 1, 'system', '2024-01-03');

-- ============================================
-- INTEGRATION
-- ============================================
INSERT INTO erp.IntegrationEndpoints (Name, EndpointType, Url, AuthType, IsActive, CreatedBy, CreatedAt)
VALUES
    ('API مالی', 'REST', 'https://api.finance.example.com/v1', 'Bearer', 1, 'system', '2024-01-01'),
    ('وب‌سرویس انبار', 'SOAP', 'http://warehouse.local/service', 'Basic', 1, 'system', '2024-02-01');

INSERT INTO erp.IntegrationConfigs (EndpointId, KeyName, Value, IsEncrypted, IsActive, CreatedBy, CreatedAt)
VALUES
    (1, 'ApiKey', 'sk-test-123456', 0, 1, 'system', '2024-01-01'),
    (2, 'Username', 'warehouse_user', 0, 1, 'system', '2024-02-01');

INSERT INTO erp.IntegrationMessages (EndpointId, Payload, Status, RetryCount, IsActive, CreatedBy, CreatedAt)
VALUES
    (1, '{"action":"getBalance","date":"2024-01-01"}', 'Processed', 0, 1, 'system', '2024-01-02'),
    (2, '{"action":"updateStock","item":"5"}', 'Failed', 2, 1, 'system', '2024-03-05');

INSERT INTO erp.IntegrationLogs (EndpointId, Message, Status, LogTime, IsActive, CreatedBy, CreatedAt)
VALUES
    (1, 'اتصال موفق به API مالی', 'Success', '2024-01-01 09:00:00', 1, 'system', '2024-01-01'),
    (2, 'خطا در اتصال به سرویس انبار', 'Failed', '2024-03-05 11:30:00', 1, 'system', '2024-03-05');

INSERT INTO erp.ImportExportJobs (JobName, JobType, FilePath, Status, RowsProcessed, IsActive, CreatedBy, CreatedAt)
VALUES
    ('وارد کردن داده‌های فروش', 'Import', '/imports/sales_01.csv', 'Completed', 1250, 1, 'system', '2024-01-10'),
    ('صادرات گزارش مالی', 'Export', '/exports/financial_report_03.csv', 'Pending', 0, 1, 'system', '2024-03-01');

-- ============================================
-- SUMMARY
-- ============================================
SELECT 'Fake data inserted successfully' AS Status;
SELECT COUNT(*) AS TotalTenants FROM erp.Tenants;
SELECT COUNT(*) AS TotalUsers FROM erp.Users;
SELECT COUNT(*) AS TotalDocuments FROM erp.Documents;
SELECT COUNT(*) AS TotalNotifications FROM erp.Notifications;
SELECT COUNT(*) AS TotalAuditLogs FROM erp.AuditLogs;
SELECT COUNT(*) AS TotalDomainEvents FROM erp.DomainEvents;
SELECT COUNT(*) AS TotalAIEntities FROM erp.AIAgents;
GO
