-- ============================================
-- ERP Enterprise — SQL Server Database Setup
-- Multi-Tenant, Audit Columns (CreatedBy/CreatedAt/IsActive)
-- All phases + modules (Search, Document, Event, Notification, Audit, AI, Reporting, Integration)
-- ============================================

USE master;
GO

IF DB_ID('ERP_Enterprise') IS NOT NULL
    DROP DATABASE ERP_Enterprise;
GO

CREATE DATABASE ERP_Enterprise;
GO

USE ERP_Enterprise;
GO

-- ============================================
-- SCHEMA
-- ============================================

CREATE SCHEMA erp AUTHORIZATION dbo;
GO

-- ============================================
-- CORE / MULTI-TENANT
-- ============================================

CREATE TABLE erp.Tenants (
    Id INT PRIMARY KEY IDENTITY(1,1),
    Name NVARCHAR(200) NOT NULL,
    Code NVARCHAR(50) NOT NULL UNIQUE,
    IsActive BIT NOT NULL DEFAULT 1,
    CreatedBy NVARCHAR(100) NOT NULL DEFAULT 'system',
    CreatedAt DATETIME2 DEFAULT GETDATE(),
    RowVersion ROWVERSION
);

CREATE TABLE erp.Companies (
    Id INT PRIMARY KEY IDENTITY(1,1),
    TenantId INT NOT NULL REFERENCES erp.Tenants(Id),
    Name NVARCHAR(200) NOT NULL,
    TaxNumber NVARCHAR(50) NULL,
    Address NVARCHAR(500) NULL,
    BranchId INT NULL,
    IsActive BIT NOT NULL DEFAULT 1,
    CreatedBy NVARCHAR(100) NOT NULL DEFAULT 'system',
    CreatedAt DATETIME2 DEFAULT GETDATE(),
    RowVersion ROWVERSION
);

CREATE TABLE erp.Branches (
    Id INT PRIMARY KEY IDENTITY(1,1),
    CompanyId INT NOT NULL REFERENCES erp.Companies(Id),
    Name NVARCHAR(200) NOT NULL,
    Code NVARCHAR(50) NOT NULL,
    Address NVARCHAR(500) NULL,
    IsActive BIT NOT NULL DEFAULT 1,
    CreatedBy NVARCHAR(100) NOT NULL DEFAULT 'system',
    CreatedAt DATETIME2 DEFAULT GETDATE(),
    RowVersion ROWVERSION
);

CREATE TABLE erp.Users (
    Id INT PRIMARY KEY IDENTITY(1,1),
    TenantId INT NOT NULL REFERENCES erp.Tenants(Id),
    Username NVARCHAR(100) NOT NULL UNIQUE,
    FullName NVARCHAR(200) NOT NULL,
    Email NVARCHAR(200) NULL,
    PasswordHash NVARCHAR(500) NOT NULL,
    Role NVARCHAR(50) NOT NULL DEFAULT 'Employee',
    IsActive BIT NOT NULL DEFAULT 1,
    CreatedBy NVARCHAR(100) NOT NULL DEFAULT 'system',
    CreatedAt DATETIME2 DEFAULT GETDATE(),
    RowVersion ROWVERSION
);

CREATE TABLE erp.Roles (
    Id INT PRIMARY KEY IDENTITY(1,1),
    Name NVARCHAR(100) NOT NULL UNIQUE,
    Description NVARCHAR(500) NULL,
    IsActive BIT NOT NULL DEFAULT 1,
    CreatedBy NVARCHAR(100) NOT NULL DEFAULT 'system',
    CreatedAt DATETIME2 DEFAULT GETDATE(),
    RowVersion ROWVERSION
);

CREATE TABLE erp.Permissions (
    Id INT PRIMARY KEY IDENTITY(1,1),
    Name NVARCHAR(200) NOT NULL UNIQUE,
    Resource NVARCHAR(100) NOT NULL,
    IsActive BIT NOT NULL DEFAULT 1,
    CreatedBy NVARCHAR(100) NOT NULL DEFAULT 'system',
    CreatedAt DATETIME2 DEFAULT GETDATE(),
    RowVersion ROWVERSION
);

CREATE TABLE erp.UserRoles (
    UserId INT NOT NULL REFERENCES erp.Users(Id),
    RoleId INT NOT NULL REFERENCES erp.Roles(Id),
    PRIMARY KEY (UserId, RoleId)
);

-- ============================================
-- FORM BUILDER
-- ============================================

CREATE TABLE erp.DynamicForms (
    Id INT PRIMARY KEY IDENTITY(1,1),
    TenantId INT NOT NULL REFERENCES erp.Tenants(Id),
    FormName NVARCHAR(200) NOT NULL,
    Description NVARCHAR(1000) NULL,
    IsActive BIT NOT NULL DEFAULT 1,
    CreatedBy NVARCHAR(100) NOT NULL DEFAULT 'system',
    CreatedAt DATETIME2 DEFAULT GETDATE(),
    RowVersion ROWVERSION
);

CREATE TABLE erp.DynamicFormFields (
    Id INT PRIMARY KEY IDENTITY(1,1),
    FormId INT NOT NULL REFERENCES erp.DynamicForms(Id),
    FieldName NVARCHAR(200) NOT NULL,
    FieldType NVARCHAR(50) NOT NULL DEFAULT 'Text',
    IsRequired BIT NOT NULL DEFAULT 0,
    SortOrder INT NOT NULL DEFAULT 0,
    IsActive BIT NOT NULL DEFAULT 1,
    CreatedBy NVARCHAR(100) NOT NULL DEFAULT 'system',
    CreatedAt DATETIME2 DEFAULT GETDATE(),
    RowVersion ROWVERSION
);

CREATE TABLE erp.DynamicFormInstances (
    Id INT PRIMARY KEY IDENTITY(1,1),
    FormId INT NOT NULL REFERENCES erp.DynamicForms(Id),
    InstanceName NVARCHAR(200) NOT NULL,
    Status NVARCHAR(50) NOT NULL DEFAULT 'Draft',
    IsActive BIT NOT NULL DEFAULT 1,
    CreatedBy NVARCHAR(100) NOT NULL DEFAULT 'system',
    CreatedAt DATETIME2 DEFAULT GETDATE(),
    RowVersion ROWVERSION
);

CREATE TABLE erp.DynamicFormFieldValues (
    Id INT PRIMARY KEY IDENTITY(1,1),
    InstanceId INT NOT NULL REFERENCES erp.DynamicFormInstances(Id),
    FieldId INT NOT NULL REFERENCES erp.DynamicFormFields(Id),
    Value NVARCHAR(MAX) NULL,
    IsActive BIT NOT NULL DEFAULT 1,
    CreatedBy NVARCHAR(100) NOT NULL DEFAULT 'system',
    CreatedAt DATETIME2 DEFAULT GETDATE(),
    RowVersion ROWVERSION
);

-- ============================================
-- HR / PAYROLL
-- ============================================

CREATE TABLE erp.Missions (
    Id INT PRIMARY KEY IDENTITY(1,1),
    TenantId INT NOT NULL REFERENCES erp.Tenants(Id),
    EmployeeId INT NOT NULL REFERENCES erp.Users(Id),
    Destination NVARCHAR(200) NOT NULL,
    Purpose NVARCHAR(500) NULL,
    StartDate DATE NOT NULL,
    EndDate DATE NOT NULL,
    Status NVARCHAR(50) NOT NULL DEFAULT 'Pending',
    IsActive BIT NOT NULL DEFAULT 1,
    CreatedBy NVARCHAR(100) NOT NULL DEFAULT 'system',
    CreatedAt DATETIME2 DEFAULT GETDATE(),
    RowVersion ROWVERSION
);

CREATE TABLE erp.Overtimes (
    Id INT PRIMARY KEY IDENTITY(1,1),
    TenantId INT NOT NULL REFERENCES erp.Tenants(Id),
    EmployeeId INT NOT NULL REFERENCES erp.Users(Id),
    Hours DECIMAL(10,2) NOT NULL DEFAULT 0,
    Rate DECIMAL(10,2) NOT NULL DEFAULT 0,
    Date DATE NOT NULL,
    Status NVARCHAR(50) NOT NULL DEFAULT 'Pending',
    IsActive BIT NOT NULL DEFAULT 1,
    CreatedBy NVARCHAR(100) NOT NULL DEFAULT 'system',
    CreatedAt DATETIME2 DEFAULT GETDATE(),
    RowVersion ROWVERSION
);

CREATE TABLE erp.Evaluations (
    Id INT PRIMARY KEY IDENTITY(1,1),
    TenantId INT NOT NULL REFERENCES erp.Tenants(Id),
    EmployeeId INT NOT NULL REFERENCES erp.Users(Id),
    Score DECIMAL(5,2) NULL,
    Comment NVARCHAR(1000) NULL,
    Period NVARCHAR(20) NOT NULL,
    IsActive BIT NOT NULL DEFAULT 1,
    CreatedBy NVARCHAR(100) NOT NULL DEFAULT 'system',
    CreatedAt DATETIME2 DEFAULT GETDATE(),
    RowVersion ROWVERSION
);

CREATE TABLE erp.Trainings (
    Id INT PRIMARY KEY IDENTITY(1,1),
    Title NVARCHAR(200) NOT NULL,
    Description NVARCHAR(1000) NULL,
    DurationHours INT NOT NULL DEFAULT 1,
    IsActive BIT NOT NULL DEFAULT 1,
    CreatedBy NVARCHAR(100) NOT NULL DEFAULT 'system',
    CreatedAt DATETIME2 DEFAULT GETDATE(),
    RowVersion ROWVERSION
);

CREATE TABLE erp.Salaries (
    Id INT PRIMARY KEY IDENTITY(1,1),
    TenantId INT NOT NULL REFERENCES erp.Tenants(Id),
    EmployeeId INT NOT NULL REFERENCES erp.Users(Id),
    BaseSalary DECIMAL(15,2) NOT NULL DEFAULT 0,
    EffectiveDate DATE NOT NULL,
    Status NVARCHAR(50) NOT NULL DEFAULT 'Active',
    IsActive BIT NOT NULL DEFAULT 1,
    CreatedBy NVARCHAR(100) NOT NULL DEFAULT 'system',
    CreatedAt DATETIME2 DEFAULT GETDATE(),
    RowVersion ROWVERSION
);

CREATE TABLE erp.Taxes (
    Id INT PRIMARY KEY IDENTITY(1,1),
    Name NVARCHAR(100) NOT NULL,
    Rate DECIMAL(5,4) NOT NULL DEFAULT 0,
    Type NVARCHAR(50) NOT NULL DEFAULT 'Income',
    IsActive BIT NOT NULL DEFAULT 1,
    CreatedBy NVARCHAR(100) NOT NULL DEFAULT 'system',
    CreatedAt DATETIME2 DEFAULT GETDATE(),
    RowVersion ROWVERSION
);

CREATE TABLE erp.Allowances (
    Id INT PRIMARY KEY IDENTITY(1,1),
    Name NVARCHAR(100) NOT NULL,
    Amount DECIMAL(15,2) NOT NULL DEFAULT 0,
    Type NVARCHAR(50) NOT NULL DEFAULT 'Monthly',
    IsActive BIT NOT NULL DEFAULT 1,
    CreatedBy NVARCHAR(100) NOT NULL DEFAULT 'system',
    CreatedAt DATETIME2 DEFAULT GETDATE(),
    RowVersion ROWVERSION
);

CREATE TABLE erp.Bonuses (
    Id INT PRIMARY KEY IDENTITY(1,1),
    TenantId INT NOT NULL REFERENCES erp.Tenants(Id),
    EmployeeId INT NOT NULL REFERENCES erp.Users(Id),
    Amount DECIMAL(15,2) NOT NULL DEFAULT 0,
    Reason NVARCHAR(500) NULL,
    IssueDate DATE NOT NULL,
    Status NVARCHAR(50) NOT NULL DEFAULT 'Pending',
    IsActive BIT NOT NULL DEFAULT 1,
    CreatedBy NVARCHAR(100) NOT NULL DEFAULT 'system',
    CreatedAt DATETIME2 DEFAULT GETDATE(),
    RowVersion ROWVERSION
);

CREATE TABLE erp.Loans (
    Id INT PRIMARY KEY IDENTITY(1,1),
    TenantId INT NOT NULL REFERENCES erp.Tenants(Id),
    EmployeeId INT NOT NULL REFERENCES erp.Users(Id),
    Amount DECIMAL(15,2) NOT NULL DEFAULT 0,
    TermMonths INT NOT NULL DEFAULT 1,
    InterestRate DECIMAL(5,4) NULL DEFAULT 0,
    Status NVARCHAR(50) NOT NULL DEFAULT 'Active',
    IsActive BIT NOT NULL DEFAULT 1,
    CreatedBy NVARCHAR(100) NOT NULL DEFAULT 'system',
    CreatedAt DATETIME2 DEFAULT GETDATE(),
    RowVersion ROWVERSION
);

CREATE TABLE erp.Insurances (
    Id INT PRIMARY KEY IDENTITY(1,1),
    Name NVARCHAR(200) NOT NULL,
    Provider NVARCHAR(200) NULL,
    Coverage NVARCHAR(500) NULL,
    Premium DECIMAL(15,2) NULL DEFAULT 0,
    IsActive BIT NOT NULL DEFAULT 1,
    CreatedBy NVARCHAR(100) NOT NULL DEFAULT 'system',
    CreatedAt DATETIME2 DEFAULT GETDATE(),
    RowVersion ROWVERSION
);

-- ============================================
-- REPORTING / BI
-- ============================================

CREATE TABLE erp.Reports (
    Id INT PRIMARY KEY IDENTITY(1,1),
    TenantId INT NOT NULL REFERENCES erp.Tenants(Id),
    ReportName NVARCHAR(200) NOT NULL,
    ReportType NVARCHAR(50) NOT NULL DEFAULT 'Table',
    QueryDef NVARCHAR(MAX) NULL,
    Format NVARCHAR(20) NOT NULL DEFAULT 'PDF',
    IsActive BIT NOT NULL DEFAULT 1,
    CreatedBy NVARCHAR(100) NOT NULL DEFAULT 'system',
    CreatedAt DATETIME2 DEFAULT GETDATE(),
    RowVersion ROWVERSION
);

CREATE TABLE erp.Charts (
    Id INT PRIMARY KEY IDENTITY(1,1),
    ReportId INT NOT NULL REFERENCES erp.Reports(Id),
    ChartType NVARCHAR(50) NOT NULL DEFAULT 'Bar',
    DataSource NVARCHAR(200) NULL,
    IsActive BIT NOT NULL DEFAULT 1,
    CreatedBy NVARCHAR(100) NOT NULL DEFAULT 'system',
    CreatedAt DATETIME2 DEFAULT GETDATE(),
    RowVersion ROWVERSION
);

CREATE TABLE erp.Pivots (
    Id INT PRIMARY KEY IDENTITY(1,1),
    ReportId INT NOT NULL REFERENCES erp.Reports(Id),
    Rows NVARCHAR(200) NOT NULL,
    Columns NVARCHAR(200) NOT NULL,
    Values NVARCHAR(200) NOT NULL,
    IsActive BIT NOT NULL DEFAULT 1,
    CreatedBy NVARCHAR(100) NOT NULL DEFAULT 'system',
    CreatedAt DATETIME2 DEFAULT GETDATE(),
    RowVersion ROWVERSION
);

CREATE TABLE erp.Dashboards (
    Id INT PRIMARY KEY IDENTITY(1,1),
    TenantId INT NOT NULL REFERENCES erp.Tenants(Id),
    Title NVARCHAR(200) NOT NULL,
    Layout NVARCHAR(MAX) NULL,
    IsActive BIT NOT NULL DEFAULT 1,
    CreatedBy NVARCHAR(100) NOT NULL DEFAULT 'system',
    CreatedAt DATETIME2 DEFAULT GETDATE(),
    RowVersion ROWVERSION
);

CREATE TABLE erp.KPIs (
    Id INT PRIMARY KEY IDENTITY(1,1),
    Name NVARCHAR(200) NOT NULL,
    TargetValue DECIMAL(15,4) NOT NULL DEFAULT 0,
    Unit NVARCHAR(50) NOT NULL DEFAULT 'Number',
    IsActive BIT NOT NULL DEFAULT 1,
    CreatedBy NVARCHAR(100) NOT NULL DEFAULT 'system',
    CreatedAt DATETIME2 DEFAULT GETDATE(),
    RowVersion ROWVERSION
);

-- ============================================
-- INTEGRATION
-- ============================================

CREATE TABLE erp.IntegrationEndpoints (
    Id INT PRIMARY KEY IDENTITY(1,1),
    Name NVARCHAR(200) NOT NULL,
    EndpointType NVARCHAR(50) NOT NULL DEFAULT 'REST',
    Url NVARCHAR(500) NOT NULL,
    AuthType NVARCHAR(50) NOT NULL DEFAULT 'Bearer',
    IsActive BIT NOT NULL DEFAULT 1,
    CreatedBy NVARCHAR(100) NOT NULL DEFAULT 'system',
    CreatedAt DATETIME2 DEFAULT GETDATE(),
    RowVersion ROWVERSION
);

CREATE TABLE erp.IntegrationConfigs (
    Id INT PRIMARY KEY IDENTITY(1,1),
    EndpointId INT NOT NULL REFERENCES erp.IntegrationEndpoints(Id),
    KeyName NVARCHAR(200) NOT NULL,
    Value NVARCHAR(MAX) NULL,
    IsEncrypted BIT NOT NULL DEFAULT 0,
    IsActive BIT NOT NULL DEFAULT 1,
    CreatedBy NVARCHAR(100) NOT NULL DEFAULT 'system',
    CreatedAt DATETIME2 DEFAULT GETDATE(),
    RowVersion ROWVERSION
);

CREATE TABLE erp.IntegrationMessages (
    Id INT PRIMARY KEY IDENTITY(1,1),
    EndpointId INT NOT NULL REFERENCES erp.IntegrationEndpoints(Id),
    Payload NVARCHAR(MAX) NULL,
    Status NVARCHAR(50) NOT NULL DEFAULT 'Pending',
    RetryCount INT NOT NULL DEFAULT 0,
    IsActive BIT NOT NULL DEFAULT 1,
    CreatedBy NVARCHAR(100) NOT NULL DEFAULT 'system',
    CreatedAt DATETIME2 DEFAULT GETDATE(),
    RowVersion ROWVERSION
);

CREATE TABLE erp.IntegrationLogs (
    Id INT PRIMARY KEY IDENTITY(1,1),
    EndpointId INT NOT NULL REFERENCES erp.IntegrationEndpoints(Id),
    Message NVARCHAR(1000) NOT NULL,
    Status NVARCHAR(50) NOT NULL DEFAULT 'Success',
    LogTime DATETIME2 DEFAULT GETDATE(),
    IsActive BIT NOT NULL DEFAULT 1,
    CreatedBy NVARCHAR(100) NOT NULL DEFAULT 'system',
    CreatedAt DATETIME2 DEFAULT GETDATE(),
    RowVersion ROWVERSION
);

CREATE TABLE erp.ImportExportJobs (
    Id INT PRIMARY KEY IDENTITY(1,1),
    JobName NVARCHAR(200) NOT NULL,
    JobType NVARCHAR(50) NOT NULL DEFAULT 'Import',
    FilePath NVARCHAR(500) NULL,
    Status NVARCHAR(50) NOT NULL DEFAULT 'Pending',
    RowsProcessed INT NOT NULL DEFAULT 0,
    IsActive BIT NOT NULL DEFAULT 1,
    CreatedBy NVARCHAR(100) NOT NULL DEFAULT 'system',
    CreatedAt DATETIME2 DEFAULT GETDATE(),
    RowVersion ROWVERSION
);

-- ============================================
-- AI
-- ============================================

CREATE TABLE erp.AIAgents (
    Id INT PRIMARY KEY IDENTITY(1,1),
    Name NVARCHAR(200) NOT NULL,
    Description NVARCHAR(1000) NULL,
    Model NVARCHAR(100) NOT NULL DEFAULT 'GPT-4',
    Temperature DECIMAL(3,2) NOT NULL DEFAULT 0.7,
    MaxTokens INT NOT NULL DEFAULT 2048,
    IsActive BIT NOT NULL DEFAULT 1,
    CreatedBy NVARCHAR(100) NOT NULL DEFAULT 'system',
    CreatedAt DATETIME2 DEFAULT GETDATE(),
    RowVersion ROWVERSION
);

CREATE TABLE erp.AIPrompts (
    Id INT PRIMARY KEY IDENTITY(1,1),
    AgentId INT NOT NULL REFERENCES erp.AIAgents(Id),
    PromptText NVARCHAR(MAX) NOT NULL,
    ContextType NVARCHAR(50) NOT NULL DEFAULT 'General',
    IsActive BIT NOT NULL DEFAULT 1,
    CreatedBy NVARCHAR(100) NOT NULL DEFAULT 'system',
    CreatedAt DATETIME2 DEFAULT GETDATE(),
    RowVersion ROWVERSION
);

CREATE TABLE erp.AIResponses (
    Id INT PRIMARY KEY IDENTITY(1,1),
    AgentId INT NOT NULL REFERENCES erp.AIAgents(Id),
    PromptId INT NULL REFERENCES erp.AIPrompts(Id),
    ResponseText NVARCHAR(MAX) NULL,
    TokenUsage INT NOT NULL DEFAULT 0,
    CreatedBy NVARCHAR(100) NOT NULL DEFAULT 'system',
    CreatedAt DATETIME2 DEFAULT GETDATE(),
    RowVersion ROWVERSION
);

CREATE TABLE erp.AIAnalyses (
    Id INT PRIMARY KEY IDENTITY(1,1),
    AgentId INT NOT NULL REFERENCES erp.AIAgents(Id),
    InputData NVARCHAR(MAX) NULL,
    AnalysisResult NVARCHAR(MAX) NULL,
    ConfidenceScore DECIMAL(5,4) NULL DEFAULT 0,
    IsActive BIT NOT NULL DEFAULT 1,
    CreatedBy NVARCHAR(100) NOT NULL DEFAULT 'system',
    CreatedAt DATETIME2 DEFAULT GETDATE(),
    RowVersion ROWVERSION
);

CREATE TABLE erp.AIPredictions (
    Id INT PRIMARY KEY IDENTITY(1,1),
    AgentId INT NOT NULL REFERENCES erp.AIAgents(Id),
    PredictionType NVARCHAR(100) NOT NULL DEFAULT 'Forecast',
    PredictionValue NVARCHAR(500) NULL,
    AccuracyScore DECIMAL(5,4) NULL DEFAULT 0,
    TargetDate DATE NULL,
    IsActive BIT NOT NULL DEFAULT 1,
    CreatedBy NVARCHAR(100) NOT NULL DEFAULT 'system',
    CreatedAt DATETIME2 DEFAULT GETDATE(),
    RowVersion ROWVERSION
);

CREATE TABLE erp.AIInsights (
    Id INT PRIMARY KEY IDENTITY(1,1),
    InsightTitle NVARCHAR(200) NOT NULL,
    InsightContent NVARCHAR(MAX) NULL,
    Priority NVARCHAR(20) NOT NULL DEFAULT 'Medium',
    RelatedEntity NVARCHAR(200) NULL,
    AgentId INT NULL REFERENCES erp.AIAgents(Id),
    IsActive BIT NOT NULL DEFAULT 1,
    CreatedBy NVARCHAR(100) NOT NULL DEFAULT 'system',
    CreatedAt DATETIME2 DEFAULT GETDATE(),
    RowVersion ROWVERSION
);

-- ============================================
-- NOTIFICATION
-- ============================================

CREATE TABLE erp.Notifications (
    Id INT PRIMARY KEY IDENTITY(1,1),
    TenantId INT NOT NULL REFERENCES erp.Tenants(Id),
    UserId INT NULL REFERENCES erp.Users(Id),
    Title NVARCHAR(200) NOT NULL,
    Message NVARCHAR(1000) NOT NULL,
    Type NVARCHAR(50) NOT NULL DEFAULT 'InApp',
    Status NVARCHAR(50) NOT NULL DEFAULT 'Unread',
    IsActive BIT NOT NULL DEFAULT 1,
    CreatedBy NVARCHAR(100) NOT NULL DEFAULT 'system',
    CreatedAt DATETIME2 DEFAULT GETDATE(),
    RowVersion ROWVERSION
);

-- ============================================
-- AUDIT
-- ============================================

CREATE TABLE erp.AuditLogs (
    Id INT PRIMARY KEY IDENTITY(1,1),
    TenantId INT NOT NULL REFERENCES erp.Tenants(Id),
    UserId INT NULL REFERENCES erp.Users(Id),
    Action NVARCHAR(200) NOT NULL,
    TableName NVARCHAR(100) NOT NULL,
    RecordId NVARCHAR(100) NULL,
    OldValue NVARCHAR(MAX) NULL,
    NewValue NVARCHAR(MAX) NULL,
    IPAddress NVARCHAR(50) NULL,
    LogTime DATETIME2 DEFAULT GETDATE(),
    IsActive BIT NOT NULL DEFAULT 1,
    CreatedBy NVARCHAR(100) NOT NULL DEFAULT 'system',
    CreatedAt DATETIME2 DEFAULT GETDATE(),
    RowVersion ROWVERSION
);

-- ============================================
-- SEARCH
-- ============================================

CREATE TABLE erp.SearchQueries (
    Id INT PRIMARY KEY IDENTITY(1,1),
    TenantId INT NOT NULL REFERENCES erp.Tenants(Id),
    UserId INT NULL REFERENCES erp.Users(Id),
    QueryText NVARCHAR(500) NOT NULL,
    SearchType NVARCHAR(50) NOT NULL DEFAULT 'FullText',
    ResultCount INT NOT NULL DEFAULT 0,
    Status NVARCHAR(50) NOT NULL DEFAULT 'Completed',
    IsActive BIT NOT NULL DEFAULT 1,
    CreatedBy NVARCHAR(100) NOT NULL DEFAULT 'system',
    CreatedAt DATETIME2 DEFAULT GETDATE(),
    RowVersion ROWVERSION
);

-- ============================================
-- DOCUMENT MANAGEMENT
-- ============================================

CREATE TABLE erp.Documents (
    Id INT PRIMARY KEY IDENTITY(1,1),
    TenantId INT NOT NULL REFERENCES erp.Tenants(Id),
    FileName NVARCHAR(500) NOT NULL,
    FilePath NVARCHAR(1000) NOT NULL,
    FileSize BIGINT NOT NULL DEFAULT 0,
    MimeType NVARCHAR(200) NULL,
    Version NVARCHAR(20) NOT NULL DEFAULT '1.0',
    DocumentType NVARCHAR(50) NOT NULL DEFAULT 'General',
    Tags NVARCHAR(500) NULL,
    IsSigned BIT NOT NULL DEFAULT 0,
    SignatureUserId INT NULL REFERENCES erp.Users(Id),
    PreviewPath NVARCHAR(1000) NULL,
    OCRText NVARCHAR(MAX) NULL,
    Status NVARCHAR(50) NOT NULL DEFAULT 'Active',
    IsActive BIT NOT NULL DEFAULT 1,
    CreatedBy NVARCHAR(100) NOT NULL DEFAULT 'system',
    CreatedAt DATETIME2 DEFAULT GETDATE(),
    RowVersion ROWVERSION
);

-- ============================================
-- EVENT ARCHITECTURE
-- ============================================

CREATE TABLE erp.DomainEvents (
    Id INT PRIMARY KEY IDENTITY(1,1),
    EventName NVARCHAR(200) NOT NULL,
    Payload NVARCHAR(MAX) NULL,
    EventType NVARCHAR(50) NOT NULL DEFAULT 'Domain',
    Status NVARCHAR(50) NOT NULL DEFAULT 'Pending',
    SourceEntity NVARCHAR(200) NULL,
    SourceId NVARCHAR(100) NULL,
    RetryCount INT NOT NULL DEFAULT 0,
    IsActive BIT NOT NULL DEFAULT 1,
    CreatedBy NVARCHAR(100) NOT NULL DEFAULT 'system',
    CreatedAt DATETIME2 DEFAULT GETDATE(),
    RowVersion ROWVERSION
);
GO

PRINT 'Database ERP_Enterprise and all tables created successfully (SQL Server).';
