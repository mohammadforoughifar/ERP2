namespace ERP.Contracts.Dtos.Event;
public class DomainEventDto
{
    public int Id { get; set; }
    public string EventName { get; set; } = string.Empty;
    public string? Payload { get; set; }
    public string? RelatedEntity { get; set; }
    public int? RelatedEntityId { get; set; }
    public string Status { get; set; } = "Pending";
    public bool IsActive { get; set; } = true;
}
