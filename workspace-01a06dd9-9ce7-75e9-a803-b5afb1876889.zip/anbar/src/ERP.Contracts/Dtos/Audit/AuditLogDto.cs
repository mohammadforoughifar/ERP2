namespace ERP.Contracts.Dtos.Audit;

public class AuditLogDto
{
    public int Id { get; set; }
    public string User { get; set; } = string.Empty;
    public string IP { get; set; } = string.Empty;
    public string Action { get; set; } = string.Empty;
    public string Entity { get; set; } = string.Empty;
    public int? EntityId { get; set; }
    public string? OldValue { get; set; }
    public string? NewValue { get; set; }
    public bool IsActive { get; set; } = true;
}
