namespace ERP.Contracts.Dtos.Document;
public class DocumentDto
{
    public int Id { get; set; }
    public string FileName { get; set; } = string.Empty;
    public string? FilePath { get; set; }
    public string Type { get; set; } = "File";
    public string Status { get; set; } = "Active";
    public bool IsActive { get; set; } = true;
}
