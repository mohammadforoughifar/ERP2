namespace ERP.Contracts.Dtos.Search;

public class SearchQueryDto
{
    public int Id { get; set; }
    public string QueryText { get; set; } = string.Empty;
    public string SearchType { get; set; } = "FullText";
    public bool IsActive { get; set; } = true;
}
