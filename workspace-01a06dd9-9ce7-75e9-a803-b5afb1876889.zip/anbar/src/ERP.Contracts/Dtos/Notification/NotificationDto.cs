namespace ERP.Contracts.Dtos.Notification;

public class NotificationDto
{
    public int Id { get; set; }
    public string Title { get; set; } = string.Empty;
    public string Message { get; set; } = string.Empty;
    public string Type { get; set; } = "InApp";
    public string Status { get; set; } = "Unread";
    public string? Recipient { get; set; }
    public bool IsActive { get; set; } = true;
}
