using ERP.Domain.Entities.Event;
using System.Collections.Generic;
using System.Threading.Tasks;
namespace ERP.Application.Interfaces;
public interface IDomainEventRepository
{
    Task<DomainEvent?> GetByIdAsync(int id);
    Task<IEnumerable<DomainEvent>> GetActiveAsync();
    Task AddAsync(DomainEvent domainEvent);
    Task UpdateAsync(DomainEvent domainEvent);
    Task DeleteAsync(DomainEvent domainEvent);
}
