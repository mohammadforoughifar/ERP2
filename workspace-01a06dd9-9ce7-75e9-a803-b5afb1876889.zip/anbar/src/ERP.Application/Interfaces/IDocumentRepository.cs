using ERP.Domain.Entities.Document;
using System.Collections.Generic;
using System.Threading.Tasks;
namespace ERP.Application.Interfaces;
public interface IDocumentRepository
{
    Task<Document?> GetByIdAsync(int id);
    Task<IEnumerable<Document>> GetActiveAsync();
    Task AddAsync(Document document);
    Task UpdateAsync(Document document);
    Task DeleteAsync(Document document);
}
