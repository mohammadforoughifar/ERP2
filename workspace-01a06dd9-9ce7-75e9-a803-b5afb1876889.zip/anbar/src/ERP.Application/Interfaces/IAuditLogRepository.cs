using ERP.Domain.Entities.Audit;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ERP.Application.Interfaces;

public interface IAuditLogRepository
{
    Task<AuditLog?> GetByIdAsync(int id);
    Task<IEnumerable<AuditLog>> GetActiveAsync();
    Task AddAsync(AuditLog auditLog);
    Task UpdateAsync(AuditLog auditLog);
    Task DeleteAsync(AuditLog auditLog);
}
