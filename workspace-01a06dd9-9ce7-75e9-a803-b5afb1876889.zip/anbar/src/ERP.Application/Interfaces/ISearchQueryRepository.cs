using ERP.Domain.Entities.Search;
using System.Collections.Generic;
using System.Threading.Tasks;
namespace ERP.Application.Interfaces;
public interface ISearchQueryRepository
{
    Task<SearchQuery?> GetByIdAsync(int id);
    Task<IEnumerable<SearchQuery>> GetActiveAsync();
    Task AddAsync(SearchQuery query);
    Task UpdateAsync(SearchQuery query);
    Task DeleteAsync(SearchQuery query);
}
