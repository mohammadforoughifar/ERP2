using System;
using System.ComponentModel.DataAnnotations;
namespace ERP.Domain.Entities.Event;
public class DomainEvent
{
    [Key] public int Id { get; set; }
    [StringLength(200)] public string EventName { get; set; } = string.Empty;
    [StringLength(500)] public string? Payload { get; set; }
    [StringLength(200)] public string? RelatedEntity { get; set; }
    public int? RelatedEntityId { get; set; }
    [StringLength(50)] public string Status { get; set; } = "Pending"; // Pending, Processed, Failed
    public int CompanyId { get; set; }
    public int BranchId { get; set; }
    public int TenantId { get; set; }
    [StringLength(100)] public string CreatedBy { get; set; } = string.Empty;
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public bool IsActive { get; set; } = true;
}
