using System;
using System.ComponentModel.DataAnnotations;

namespace ERP.Domain.Entities.Search;

public class SearchQuery
{
    [Key]
    public int Id { get; set; }

    [StringLength(200)]
    public string QueryText { get; set; } = string.Empty;

    [StringLength(50)]
    public string SearchType { get; set; } = "FullText"; // FullText, Barcode, QR, Code

    [StringLength(500)]
    public string? Filter { get; set; }

    public int CompanyId { get; set; }
    public int BranchId { get; set; }
    public int TenantId { get; set; }

    [StringLength(100)]
    public string CreatedBy { get; set; } = string.Empty;

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    public bool IsActive { get; set; } = true;
}
