using System;
using System.ComponentModel.DataAnnotations;

namespace ERP.Domain.Entities.Audit;

public class AuditLog
{
    [Key]
    public int Id { get; set; }

    [StringLength(100)]
    public string User { get; set; } = string.Empty;

    [StringLength(50)]
    public string IP { get; set; } = string.Empty;

    [StringLength(100)]
    public string Action { get; set; } = string.Empty; // Create, Update, Delete, View, Login

    [StringLength(200)]
    public string Entity { get; set; } = string.Empty; // Customer, Invoice, etc.

    public int? EntityId { get; set; }

    [StringLength(2000)]
    public string? OldValue { get; set; }

    [StringLength(2000)]
    public string? NewValue { get; set; }

    public int CompanyId { get; set; }
    public int BranchId { get; set; }
    public int TenantId { get; set; }

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    public bool IsActive { get; set; } = true;
}
