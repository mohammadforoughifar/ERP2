using System;
using System.ComponentModel.DataAnnotations;
namespace ERP.Domain.Entities.Document;
public class Document
{
    [Key] public int Id { get; set; }
    [StringLength(200)] public string FileName { get; set; } = string.Empty;
    [StringLength(500)] public string? FilePath { get; set; }
    [StringLength(50)] public string Type { get; set; } = "File"; // File, Image, Signature, OCR, Version
    [StringLength(100)] public string Status { get; set; } = "Active";
    public int CompanyId { get; set; }
    public int BranchId { get; set; }
    public int TenantId { get; set; }
    [StringLength(100)] public string CreatedBy { get; set; } = string.Empty;
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public bool IsActive { get; set; } = true;
}
