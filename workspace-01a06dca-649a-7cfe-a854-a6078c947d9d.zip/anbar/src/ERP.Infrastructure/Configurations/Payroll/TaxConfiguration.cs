using ERP.Domain.Entities.Payroll;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace ERP.Infrastructure.Configurations.Payroll;

public class TaxConfiguration : IEntityTypeConfiguration<Tax>
{
    public void Configure(EntityTypeBuilder<Tax> builder)
    {
        builder.ToTable("Taxes");
        builder.HasKey(x => x.Id);
        builder.Property(x => x.TaxName).HasMaxLength(200).IsRequired();
        builder.Property(x => x.TaxType).HasMaxLength(50).HasDefaultValue("IncomeTax");
        builder.Property(x => x.IsActive).HasDefaultValue(true);
    }
}
