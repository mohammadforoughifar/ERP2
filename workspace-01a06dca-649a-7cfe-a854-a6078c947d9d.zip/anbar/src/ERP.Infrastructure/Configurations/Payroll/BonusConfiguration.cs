using ERP.Domain.Entities.Payroll;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace ERP.Infrastructure.Configurations.Payroll;

public class BonusConfiguration : IEntityTypeConfiguration<Bonus>
{
    public void Configure(EntityTypeBuilder<Bonus> builder)
    {
        builder.ToTable("Bonuses");
        builder.HasKey(x => x.Id);
        builder.Property(x => x.BonusName).HasMaxLength(200).IsRequired();
        builder.Property(x => x.Status).HasMaxLength(50).HasDefaultValue("Pending");
        builder.Property(x => x.IsActive).HasDefaultValue(true);
    }
}
