using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using ERP.Domain.Entities.Payroll;

namespace ERP.Infrastructure.Configurations.Payroll;

public class PayrollRunConfiguration : IEntityTypeConfiguration<PayrollRun>
{
    public void Configure(EntityTypeBuilder<PayrollRun> builder)
    {
        builder.ToTable("PayrollRuns");
        builder.HasKey(pr => pr.Id);
        builder.Property(pr => pr.Id).ValueGeneratedOnAdd();

        builder.Property(pr => pr.CompanyId).IsRequired();
        builder.Property(pr => pr.PayrollNumber).HasMaxLength(50).IsRequired();
        builder.Property(pr => pr.Status).HasMaxLength(50).IsRequired();
        builder.Property(pr => pr.IsActive).IsRequired();
        builder.Property(pr => pr.CreatedAt).IsRequired();
        builder.Property(pr => pr.CreatedBy).HasMaxLength(100).IsRequired();

        builder.HasIndex(pr => pr.PayrollNumber).IsUnique();
        builder.HasIndex(pr => pr.IsActive);
        builder.HasIndex(pr => pr.CompanyId);
    }
}
