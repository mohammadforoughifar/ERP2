using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using ERP.Domain.Entities.Payroll;

namespace ERP.Infrastructure.Configurations.Payroll;

public class PayslipConfiguration : IEntityTypeConfiguration<Payslip>
{
    public void Configure(EntityTypeBuilder<Payslip> builder)
    {
        builder.ToTable("Payslips");
        builder.HasKey(p => p.Id);
        builder.Property(p => p.Id).ValueGeneratedOnAdd();

        builder.Property(p => p.PayrollRunId).IsRequired();
        builder.Property(p => p.EmployeeId).IsRequired();
        builder.Property(p => p.ContractId).IsRequired();
        builder.Property(p => p.BaseSalary).HasColumnType("decimal(18,2)");
        builder.Property(p => p.Allowances).HasColumnType("decimal(18,2)");
        builder.Property(p => p.Deductions).HasColumnType("decimal(18,2)");
        builder.Property(p => p.Bonus).HasColumnType("decimal(18,2)");
        builder.Property(p => p.Tax).HasColumnType("decimal(18,2)");
        builder.Property(p => p.Insurance).HasColumnType("decimal(18,2)");
        builder.Property(p => p.NetPay).HasColumnType("decimal(18,2)");
        builder.Property(p => p.Status).HasMaxLength(50).IsRequired();
        builder.Property(p => p.IsActive).IsRequired();
        builder.Property(p => p.CreatedAt).IsRequired();
        builder.Property(p => p.CreatedBy).HasMaxLength(100).IsRequired();

        builder.HasIndex(p => p.IsActive);
        builder.HasIndex(p => p.PayrollRunId);
        builder.HasIndex(p => p.EmployeeId);
        builder.HasIndex(p => p.ContractId);
    }
}
