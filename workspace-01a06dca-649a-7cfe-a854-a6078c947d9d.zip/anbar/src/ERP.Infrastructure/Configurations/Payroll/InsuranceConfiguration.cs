using ERP.Domain.Entities.Payroll;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace ERP.Infrastructure.Configurations.Payroll;

public class InsuranceConfiguration : IEntityTypeConfiguration<Insurance>
{
    public void Configure(EntityTypeBuilder<Insurance> builder)
    {
        builder.ToTable("Insurances");
        builder.HasKey(x => x.Id);
        builder.Property(x => x.InsuranceName).HasMaxLength(200).IsRequired();
        builder.Property(x => x.InsuranceType).HasMaxLength(50).HasDefaultValue("Social");
        builder.Property(x => x.IsActive).HasDefaultValue(true);
    }
}
