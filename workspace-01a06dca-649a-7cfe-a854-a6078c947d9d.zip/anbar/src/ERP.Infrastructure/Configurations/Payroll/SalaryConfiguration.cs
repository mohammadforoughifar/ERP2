using ERP.Domain.Entities.Payroll;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace ERP.Infrastructure.Configurations.Payroll;

public class SalaryConfiguration : IEntityTypeConfiguration<Salary>
{
    public void Configure(EntityTypeBuilder<Salary> builder)
    {
        builder.ToTable("Salaries");
        builder.HasKey(x => x.Id);
        builder.Property(x => x.Currency).HasMaxLength(20).HasDefaultValue("IRR");
        builder.Property(x => x.Status).HasMaxLength(50).HasDefaultValue("Active");
        builder.Property(x => x.IsActive).HasDefaultValue(true);
    }
}
