using ERP.Domain.Entities.FormBuilder;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace ERP.Infrastructure.Configurations.FormBuilder;

public class DynamicFormFieldConfiguration : IEntityTypeConfiguration<DynamicFormField>
{
    public void Configure(EntityTypeBuilder<DynamicFormField> builder)
    {
        builder.ToTable("DynamicFormFields");

        builder.HasKey(x => x.Id);

        builder.Property(x => x.FieldName)
            .IsRequired()
            .HasMaxLength(150);

        builder.Property(x => x.FieldType)
            .IsRequired()
            .HasMaxLength(50);

        builder.Property(x => x.Label)
            .HasMaxLength(200);

        builder.Property(x => x.Options)
            .HasMaxLength(2000);

        builder.Property(x => x.ValidationRule)
            .HasMaxLength(500);

        builder.Property(x => x.IsActive)
            .HasDefaultValue(true);

        builder.Property(x => x.IsVisible)
            .HasDefaultValue(true);
    }
}
