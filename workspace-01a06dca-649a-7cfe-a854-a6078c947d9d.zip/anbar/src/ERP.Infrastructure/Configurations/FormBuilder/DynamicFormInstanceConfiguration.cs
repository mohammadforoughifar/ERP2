using ERP.Domain.Entities.FormBuilder;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace ERP.Infrastructure.Configurations.FormBuilder;

public class DynamicFormInstanceConfiguration : IEntityTypeConfiguration<DynamicFormInstance>
{
    public void Configure(EntityTypeBuilder<DynamicFormInstance> builder)
    {
        builder.ToTable("DynamicFormInstances");

        builder.HasKey(x => x.Id);

        builder.Property(x => x.InstanceCode)
            .HasMaxLength(100);

        builder.Property(x => x.Status)
            .HasMaxLength(50)
            .HasDefaultValue("Draft");

        builder.Property(x => x.IsActive)
            .HasDefaultValue(true);
    }
}
