using ERP.Domain.Entities.FormBuilder;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace ERP.Infrastructure.Configurations.FormBuilder;

public class DynamicFormConfiguration : IEntityTypeConfiguration<DynamicForm>
{
    public void Configure(EntityTypeBuilder<DynamicForm> builder)
    {
        builder.ToTable("DynamicForms");

        builder.HasKey(x => x.Id);

        builder.Property(x => x.Name)
            .IsRequired()
            .HasMaxLength(200);

        builder.Property(x => x.Description)
            .HasMaxLength(500);

        builder.Property(x => x.FormCode)
            .IsRequired()
            .HasMaxLength(100);

        builder.Property(x => x.IsActive)
            .HasDefaultValue(true);

        builder.HasIndex(x => x.FormCode)
            .IsUnique();
    }
}
