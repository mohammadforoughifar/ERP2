using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using ERP.Domain.Entities.Treasury;

namespace ERP.Infrastructure.Configurations.Treasury;

public class PaymentConfiguration : IEntityTypeConfiguration<Payment>
{
    public void Configure(EntityTypeBuilder<Payment> builder)
    {
        builder.ToTable("Payments");
        builder.HasKey(p => p.Id);
        builder.Property(p => p.Id).ValueGeneratedOnAdd();

        builder.Property(p => p.CompanyId).IsRequired();
        builder.Property(p => p.BranchId).IsRequired(false);
        builder.Property(p => p.DocumentNumber).HasMaxLength(50).IsRequired();
        builder.Property(p => p.Type).IsRequired();
        builder.Property(p => p.PaymentDate).IsRequired();
        builder.Property(p => p.Amount).HasColumnType("decimal(18,2)").IsRequired();
        builder.Property(p => p.CurrencyCode).HasMaxLength(10).IsRequired();
        builder.Property(p => p.Description).HasMaxLength(500);
        builder.Property(p => p.IsReconciled).IsRequired();
        builder.Property(p => p.IsActive).IsRequired();
        builder.Property(p => p.CreatedAt).IsRequired();
        builder.Property(p => p.CreatedBy).HasMaxLength(100).IsRequired();

        builder.HasIndex(p => p.DocumentNumber).IsUnique();
        builder.HasIndex(p => p.IsActive);
        builder.HasIndex(p => p.CompanyId);
        builder.HasIndex(p => p.PaymentDate);
    }
}
