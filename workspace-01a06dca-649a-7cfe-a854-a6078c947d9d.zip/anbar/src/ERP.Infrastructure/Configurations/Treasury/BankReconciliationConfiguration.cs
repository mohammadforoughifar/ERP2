using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using ERP.Domain.Entities.Treasury;

namespace ERP.Infrastructure.Configurations.Treasury;

public class BankReconciliationConfiguration : IEntityTypeConfiguration<BankReconciliation>
{
    public void Configure(EntityTypeBuilder<BankReconciliation> builder)
    {
        builder.ToTable("BankReconciliations");
        builder.HasKey(br => br.Id);
        builder.Property(br => br.Id).ValueGeneratedOnAdd();

        builder.Property(br => br.CompanyId).IsRequired();
        builder.Property(br => br.BankAccountId).IsRequired();
        builder.Property(br => br.ReconciliationDate).IsRequired();
        builder.Property(br => br.StatementStartDate).IsRequired();
        builder.Property(br => br.StatementEndDate).IsRequired();
        builder.Property(br => br.StatementBalance).HasColumnType("decimal(18,2)");
        builder.Property(br => br.SystemBalance).HasColumnType("decimal(18,2)");
        builder.Property(br => br.Difference).HasColumnType("decimal(18,2)");
        builder.Property(br => br.IsReconciled).IsRequired();
        builder.Property(br => br.IsActive).IsRequired();
        builder.Property(br => br.CreatedAt).IsRequired();
        builder.Property(br => br.CreatedBy).HasMaxLength(100).IsRequired();

        builder.HasIndex(br => br.IsActive);
        builder.HasIndex(br => br.CompanyId);
        builder.HasIndex(br => br.BankAccountId);
        builder.HasIndex(br => br.ReconciliationDate);
    }
}

public class BankReconciliationLineConfiguration : IEntityTypeConfiguration<BankReconciliationLine>
{
    public void Configure(EntityTypeBuilder<BankReconciliationLine> builder)
    {
        builder.ToTable("BankReconciliationLines");
        builder.HasKey(brl => brl.Id);
        builder.Property(brl => brl.Id).ValueGeneratedOnAdd();

        builder.Property(brl => brl.BankReconciliationId).IsRequired();
        builder.Property(brl => brl.StatementAmount).HasColumnType("decimal(18,2)");
        builder.Property(brl => brl.SystemAmount).HasColumnType("decimal(18,2)");
        builder.Property(brl => brl.IsMatched).IsRequired();

        builder.HasIndex(brl => brl.BankReconciliationId);
    }
}
