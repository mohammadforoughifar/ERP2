using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using ERP.Domain.Entities.Treasury;

namespace ERP.Infrastructure.Configurations.Treasury;

public class CheckConfiguration : IEntityTypeConfiguration<Check>
{
    public void Configure(EntityTypeBuilder<Check> builder)
    {
        builder.ToTable("Checks");
        builder.HasKey(ch => ch.Id);
        builder.Property(ch => ch.Id).ValueGeneratedOnAdd();

        builder.Property(ch => ch.CompanyId).IsRequired();
        builder.Property(ch => ch.BranchId).IsRequired(false);
        builder.Property(ch => ch.CheckNumber).HasMaxLength(50).IsRequired();
        builder.Property(ch => ch.BankName).HasMaxLength(200).IsRequired();
        builder.Property(ch => ch.BankBranch).HasMaxLength(200);
        builder.Property(ch => ch.AccountNumber).HasMaxLength(50);
        builder.Property(ch => ch.Shaba).HasMaxLength(30);
        builder.Property(ch => ch.CheckBook).HasMaxLength(100);
        builder.Property(ch => ch.IssueDate).IsRequired();
        builder.Property(ch => ch.DueDate).IsRequired();
        builder.Property(ch => ch.Amount).HasColumnType("decimal(18,2)").IsRequired();
        builder.Property(ch => ch.Status).IsRequired();
        builder.Property(ch => ch.IsEndorsed).IsRequired();
        builder.Property(ch => ch.IsActive).IsRequired();
        builder.Property(ch => ch.CreatedAt).IsRequired();
        builder.Property(ch => ch.CreatedBy).HasMaxLength(100).IsRequired();

        builder.HasIndex(ch => ch.CheckNumber);
        builder.HasIndex(ch => ch.IsActive);
        builder.HasIndex(ch => ch.CompanyId);
        builder.HasIndex(ch => ch.DueDate);
        builder.HasIndex(ch => ch.Status);
    }
}
