using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using ERP.Domain.Entities.Treasury;

namespace ERP.Infrastructure.Configurations.Treasury;

public class BankAccountConfiguration : IEntityTypeConfiguration<BankAccount>
{
    public void Configure(EntityTypeBuilder<BankAccount> builder)
    {
        builder.ToTable("BankAccounts");
        builder.HasKey(b => b.Id);
        builder.Property(b => b.Id).ValueGeneratedOnAdd();

        builder.Property(b => b.CompanyId).IsRequired();
        builder.Property(b => b.BranchId).IsRequired(false);
        builder.Property(b => b.BankName).HasMaxLength(200).IsRequired();
        builder.Property(b => b.BankBranch).HasMaxLength(200);
        builder.Property(b => b.AccountNumber).HasMaxLength(50).IsRequired();
        builder.Property(b => b.Shaba).HasMaxLength(30);
        builder.Property(b => b.CurrencyCode).HasMaxLength(10).IsRequired();
        builder.Property(b => b.OpeningBalance).HasColumnType("decimal(18,2)");
        builder.Property(b => b.IsActive).IsRequired();
        builder.Property(b => b.CreatedAt).IsRequired();
        builder.Property(b => b.CreatedBy).HasMaxLength(100).IsRequired();

        builder.HasIndex(b => b.AccountNumber);
        builder.HasIndex(b => b.IsActive);
        builder.HasIndex(b => b.CompanyId);
    }
}
