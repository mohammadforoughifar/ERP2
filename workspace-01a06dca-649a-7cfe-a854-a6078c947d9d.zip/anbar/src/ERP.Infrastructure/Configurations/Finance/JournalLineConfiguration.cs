using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using ERP.Domain.Entities.Finance;

namespace ERP.Infrastructure.Configurations.Finance;

public class JournalLineConfiguration : IEntityTypeConfiguration<JournalLine>
{
    public void Configure(EntityTypeBuilder<JournalLine> builder)
    {
        builder.ToTable("JournalLines");
        builder.HasKey(jl => jl.Id);
        builder.Property(jl => jl.Id).ValueGeneratedOnAdd();

        builder.Property(jl => jl.JournalEntryId).IsRequired();
        builder.Property(jl => jl.ChartOfAccountId).IsRequired();
        builder.Property(jl => jl.Amount).HasColumnType("decimal(18,2)").IsRequired();
        builder.Property(jl => jl.IsDebit).IsRequired();
        builder.Property(jl => jl.Description).HasMaxLength(500);
        builder.Property(jl => jl.ReferenceDocument).HasMaxLength(100);

        builder.HasOne(jl => jl.JournalEntry)
            .WithMany(je => je.Lines)
            .HasForeignKey(jl => jl.JournalEntryId)
            .OnDelete(DeleteBehavior.Cascade);

        builder.HasIndex(jl => jl.JournalEntryId);
        builder.HasIndex(jl => jl.ChartOfAccountId);
    }
}
