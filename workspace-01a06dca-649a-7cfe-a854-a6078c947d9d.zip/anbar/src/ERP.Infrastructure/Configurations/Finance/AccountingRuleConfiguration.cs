using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using ERP.Domain.Entities.Finance;

namespace ERP.Infrastructure.Configurations.Finance;

public class AccountingRuleConfiguration : IEntityTypeConfiguration<AccountingRule>
{
    public void Configure(EntityTypeBuilder<AccountingRule> builder)
    {
        builder.ToTable("AccountingRules");
        builder.HasKey(ar => ar.Id);
        builder.Property(ar => ar.Id).ValueGeneratedOnAdd();

        builder.Property(ar => ar.CompanyId).IsRequired();
        builder.Property(ar => ar.RuleName).HasMaxLength(200).IsRequired();
        builder.Property(ar => ar.DocumentType).HasMaxLength(100).IsRequired();
        builder.Property(ar => ar.Module).HasMaxLength(100).IsRequired();
        builder.Property(ar => ar.ConditionExpression).HasMaxLength(1000);
        builder.Property(ar => ar.IsActive).IsRequired();
        builder.Property(ar => ar.CreatedAt).IsRequired();
        builder.Property(ar => ar.CreatedBy).HasMaxLength(100).IsRequired();

        builder.HasIndex(ar => ar.IsActive);
        builder.HasIndex(ar => ar.CompanyId);
        builder.HasIndex(ar => ar.Module);
        builder.HasIndex(ar => ar.DocumentType);
    }
}
