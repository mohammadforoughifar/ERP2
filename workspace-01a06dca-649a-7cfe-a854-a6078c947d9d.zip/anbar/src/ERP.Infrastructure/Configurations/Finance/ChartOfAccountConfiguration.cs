using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using ERP.Domain.Entities.Finance;

namespace ERP.Infrastructure.Configurations.Finance;

public class ChartOfAccountConfiguration : IEntityTypeConfiguration<ChartOfAccount>
{
    public void Configure(EntityTypeBuilder<ChartOfAccount> builder)
    {
        builder.ToTable("ChartOfAccounts");
        builder.HasKey(a => a.Id);
        builder.Property(a => a.Id).ValueGeneratedOnAdd();

        builder.Property(a => a.CompanyId).IsRequired();
        builder.Property(a => a.ParentId).IsRequired();
        builder.Property(a => a.Code).HasMaxLength(50).IsRequired();
        builder.Property(a => a.Name).HasMaxLength(200).IsRequired();
        builder.Property(a => a.Level).IsRequired();
        builder.Property(a => a.AccountType).IsRequired();
        builder.Property(a => a.IsCostCenterApplicable).IsRequired();
        builder.Property(a => a.IsProjectApplicable).IsRequired();
        builder.Property(a => a.IsActive).IsRequired();
        builder.Property(a => a.CreatedAt).IsRequired();
        builder.Property(a => a.CreatedBy).HasMaxLength(100).IsRequired();

        builder.HasIndex(a => a.Code).IsUnique();
        builder.HasIndex(a => a.IsActive);
        builder.HasIndex(a => a.CompanyId);
        builder.HasIndex(a => a.Level);

        // Self-reference hierarchy: Parent -> Child accounts
        builder.HasOne<ChartOfAccount>()
            .WithMany()
            .HasForeignKey(a => a.ParentId)
            .OnDelete(DeleteBehavior.Restrict);
    }
}
