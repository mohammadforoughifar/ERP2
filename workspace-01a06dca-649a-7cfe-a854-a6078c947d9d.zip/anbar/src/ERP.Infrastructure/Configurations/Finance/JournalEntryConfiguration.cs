using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using ERP.Domain.Entities.Finance;

namespace ERP.Infrastructure.Configurations.Finance;

public class JournalEntryConfiguration : IEntityTypeConfiguration<JournalEntry>
{
    public void Configure(EntityTypeBuilder<JournalEntry> builder)
    {
        builder.ToTable("JournalEntries");
        builder.HasKey(je => je.Id);
        builder.Property(je => je.Id).ValueGeneratedOnAdd();

        builder.Property(je => je.CompanyId).IsRequired();
        builder.Property(je => je.DocumentNumber).HasMaxLength(50).IsRequired();
        builder.Property(je => je.EntryDate).IsRequired();
        builder.Property(je => je.Description).HasMaxLength(500);
        builder.Property(je => je.CurrencyCode).HasMaxLength(10).IsRequired();
        builder.Property(je => je.ExchangeRate).HasColumnType("decimal(18,6)");
        builder.Property(je => je.IsPosted).IsRequired();
        builder.Property(je => je.IsReversed).IsRequired();
        builder.Property(je => je.IsActive).IsRequired();
        builder.Property(je => je.CreatedAt).IsRequired();
        builder.Property(je => je.CreatedBy).HasMaxLength(100).IsRequired();

        builder.HasIndex(je => je.DocumentNumber).IsUnique();
        builder.HasIndex(je => je.IsActive);
        builder.HasIndex(je => je.CompanyId);
        builder.HasIndex(je => je.EntryDate);
    }
}
