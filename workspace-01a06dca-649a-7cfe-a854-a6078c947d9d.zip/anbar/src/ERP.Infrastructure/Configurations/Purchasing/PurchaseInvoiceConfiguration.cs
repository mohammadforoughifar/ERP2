using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using ERP.Domain.Entities.Purchasing;

namespace ERP.Infrastructure.Configurations.Purchasing;

public class PurchaseInvoiceConfiguration : IEntityTypeConfiguration<PurchaseInvoice>
{
    public void Configure(EntityTypeBuilder<PurchaseInvoice> builder)
    {
        builder.ToTable("PurchaseInvoices");
        builder.HasKey(pi => pi.Id);
        builder.Property(pi => pi.Id).ValueGeneratedOnAdd();

        builder.Property(pi => pi.CompanyId).IsRequired();
        builder.Property(pi => pi.SupplierId).IsRequired();
        builder.Property(pi => pi.InvoiceNumber).HasMaxLength(50).IsRequired();
        builder.Property(pi => pi.SubTotal).HasColumnType("decimal(18,2)");
        builder.Property(pi => pi.TaxAmount).HasColumnType("decimal(18,2)");
        builder.Property(pi => pi.DiscountAmount).HasColumnType("decimal(18,2)");
        builder.Property(pi => pi.TotalAmount).HasColumnType("decimal(18,2)");
        builder.Property(pi => pi.Status).HasMaxLength(50).IsRequired();
        builder.Property(pi => pi.IsPosted).IsRequired();
        builder.Property(pi => pi.IsActive).IsRequired();
        builder.Property(pi => pi.CreatedAt).IsRequired();
        builder.Property(pi => pi.CreatedBy).HasMaxLength(100).IsRequired();

        builder.HasIndex(pi => pi.InvoiceNumber).IsUnique();
        builder.HasIndex(pi => pi.IsActive);
        builder.HasIndex(pi => pi.CompanyId);
        builder.HasIndex(pi => pi.SupplierId);
        builder.HasIndex(pi => pi.IsPosted);
    }
}
