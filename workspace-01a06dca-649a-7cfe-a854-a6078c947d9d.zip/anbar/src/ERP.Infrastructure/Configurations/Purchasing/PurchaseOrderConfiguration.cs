using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using ERP.Domain.Entities.Purchasing;

namespace ERP.Infrastructure.Configurations.Purchasing;

public class PurchaseOrderConfiguration : IEntityTypeConfiguration<PurchaseOrder>
{
    public void Configure(EntityTypeBuilder<PurchaseOrder> builder)
    {
        builder.ToTable("PurchaseOrders");
        builder.HasKey(po => po.Id);
        builder.Property(po => po.Id).ValueGeneratedOnAdd();

        builder.Property(po => po.CompanyId).IsRequired();
        builder.Property(po => po.SupplierId).IsRequired();
        builder.Property(po => po.OrderNumber).HasMaxLength(50).IsRequired();
        builder.Property(po => po.Status).HasMaxLength(50).IsRequired();
        builder.Property(po => po.TotalAmount).HasColumnType("decimal(18,2)");
        builder.Property(po => po.IsActive).IsRequired();
        builder.Property(po => po.CreatedAt).IsRequired();
        builder.Property(po => po.CreatedBy).HasMaxLength(100).IsRequired();

        builder.HasIndex(po => po.OrderNumber).IsUnique();
        builder.HasIndex(po => po.IsActive);
        builder.HasIndex(po => po.CompanyId);
        builder.HasIndex(po => po.SupplierId);
    }
}
