using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using ERP.Domain.Entities.Purchasing;

namespace ERP.Infrastructure.Configurations.Purchasing;

public class PurchaseRequestConfiguration : IEntityTypeConfiguration<PurchaseRequest>
{
    public void Configure(EntityTypeBuilder<PurchaseRequest> builder)
    {
        builder.ToTable("PurchaseRequests");
        builder.HasKey(pr => pr.Id);
        builder.Property(pr => pr.Id).ValueGeneratedOnAdd();

        builder.Property(pr => pr.CompanyId).IsRequired();
        builder.Property(pr => pr.RequesterId).IsRequired();
        builder.Property(pr => pr.RequestNumber).HasMaxLength(50).IsRequired();
        builder.Property(pr => pr.Status).HasMaxLength(50).IsRequired();
        builder.Property(pr => pr.IsActive).IsRequired();
        builder.Property(pr => pr.CreatedAt).IsRequired();
        builder.Property(pr => pr.CreatedBy).HasMaxLength(100).IsRequired();

        builder.HasIndex(pr => pr.RequestNumber).IsUnique();
        builder.HasIndex(pr => pr.IsActive);
        builder.HasIndex(pr => pr.CompanyId);
        builder.HasIndex(pr => pr.RequesterId);
    }
}
