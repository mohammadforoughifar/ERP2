using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using ERP.Domain.Entities.MasterData;

namespace ERP.Infrastructure.Configurations.MasterData;

public class ProductConfiguration : IEntityTypeConfiguration<Product>
{
    public void Configure(EntityTypeBuilder<Product> builder)
    {
        builder.ToTable("Products");
        builder.HasKey(p => p.Id);
        builder.Property(p => p.Id).ValueGeneratedOnAdd();

        builder.Property(p => p.CompanyId).IsRequired();
        builder.Property(p => p.Code).HasMaxLength(50).IsRequired();
        builder.Property(p => p.Name).HasMaxLength(200).IsRequired();
        builder.Property(p => p.Barcode).HasMaxLength(100);
        builder.Property(p => p.Brand).HasMaxLength(100);
        builder.Property(p => p.Category).HasMaxLength(100);
        builder.Property(p => p.Unit).HasMaxLength(50).IsRequired();
        builder.Property(p => p.UnitGroup).HasMaxLength(50);
        builder.Property(p => p.IsBatchTracked).IsRequired();
        builder.Property(p => p.IsSerialTracked).IsRequired();
        builder.Property(p => p.HasExpiry).IsRequired();
        builder.Property(p => p.Weight).HasColumnType("decimal(18,4)").HasDefaultValue(0);
        builder.Property(p => p.IsActive).IsRequired();
        builder.Property(p => p.CreatedAt).IsRequired();
        builder.Property(p => p.CreatedBy).HasMaxLength(100).IsRequired();

        builder.HasIndex(p => p.Code).IsUnique();
        builder.HasIndex(p => p.IsActive);
        builder.HasIndex(p => p.CompanyId);
        builder.HasIndex(p => p.Category);
        builder.HasIndex(p => p.Barcode);
    }
}
