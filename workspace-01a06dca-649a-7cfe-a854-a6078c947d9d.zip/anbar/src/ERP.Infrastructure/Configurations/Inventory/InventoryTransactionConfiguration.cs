using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using ERP.Domain.Entities.Inventory;

namespace ERP.Infrastructure.Configurations.Inventory;

public class InventoryTransactionConfiguration : IEntityTypeConfiguration<InventoryTransaction>
{
    public void Configure(EntityTypeBuilder<InventoryTransaction> builder)
    {
        builder.ToTable("InventoryTransactions");
        builder.HasKey(it => it.Id);
        builder.Property(it => it.Id).ValueGeneratedOnAdd();

        builder.Property(it => it.CompanyId).IsRequired();
        builder.Property(it => it.WarehouseId).IsRequired();
        builder.Property(it => it.ProductId).IsRequired();
        builder.Property(it => it.Quantity).IsRequired();
        builder.Property(it => it.TransactionType).IsRequired();
        builder.Property(it => it.ReferenceDocument).HasMaxLength(100);
        builder.Property(it => it.Status).HasMaxLength(50).IsRequired();
        builder.Property(it => it.IsActive).IsRequired();
        builder.Property(it => it.CreatedAt).IsRequired();
        builder.Property(it => it.CreatedBy).HasMaxLength(100).IsRequired();

        builder.HasIndex(it => it.IsActive);
        builder.HasIndex(it => it.CompanyId);
        builder.HasIndex(it => it.WarehouseId);
        builder.HasIndex(it => it.ProductId);
        builder.HasIndex(it => it.TransactionType);
    }
}
