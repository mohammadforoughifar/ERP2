using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using ERP.Domain.Entities.Inventory;

namespace ERP.Infrastructure.Configurations.Inventory;

public class InventoryBatchConfiguration : IEntityTypeConfiguration<InventoryBatch>
{
    public void Configure(EntityTypeBuilder<InventoryBatch> builder)
    {
        builder.ToTable("InventoryBatches");
        builder.HasKey(b => b.Id);
        builder.Property(b => b.Id).ValueGeneratedOnAdd();

        builder.Property(b => b.CompanyId).IsRequired();
        builder.Property(b => b.ProductId).IsRequired();
        builder.Property(b => b.BatchNumber).HasMaxLength(100).IsRequired();
        builder.Property(b => b.ProductionDate).IsRequired();
        builder.Property(b => b.ExpirationDate).IsRequired();
        builder.Property(b => b.WarehouseId).IsRequired();
        builder.Property(b => b.CurrentQuantity).IsRequired();
        builder.Property(b => b.IsActive).IsRequired();
        builder.Property(b => b.CreatedAt).IsRequired();
        builder.Property(b => b.CreatedBy).HasMaxLength(100).IsRequired();

        builder.HasIndex(b => b.BatchNumber);
        builder.HasIndex(b => b.IsActive);
        builder.HasIndex(b => b.CompanyId);
        builder.HasIndex(b => b.ProductId);
        builder.HasIndex(b => b.ExpirationDate);
    }
}
