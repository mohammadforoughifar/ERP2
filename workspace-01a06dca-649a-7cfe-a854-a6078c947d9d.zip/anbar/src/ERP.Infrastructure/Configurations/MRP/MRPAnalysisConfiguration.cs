using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using ERP.Domain.Entities.MRP;

namespace ERP.Infrastructure.Configurations.MRP;

public class MRPAnalysisConfiguration : IEntityTypeConfiguration<MRPAnalysis>
{
    public void Configure(EntityTypeBuilder<MRPAnalysis> builder)
    {
        builder.ToTable("MRPAnalysis");
        builder.HasKey(ma => ma.Id);
        builder.Property(ma => ma.Id).ValueGeneratedOnAdd();

        builder.Property(ma => ma.MRPPlanId).IsRequired();
        builder.Property(ma => ma.AnalysisType).HasMaxLength(100).IsRequired();
        builder.Property(ma => ma.Description).HasMaxLength(500);
        builder.Property(ma => ma.AffectedQuantity).IsRequired();
        builder.Property(ma => ma.IsActive).IsRequired();
        builder.Property(ma => ma.CreatedAt).IsRequired();
        builder.Property(ma => ma.CreatedBy).HasMaxLength(100).IsRequired();

        builder.HasIndex(ma => ma.MRPPlanId);
        builder.HasIndex(ma => ma.IsActive);
        builder.HasIndex(ma => ma.AnalysisType);
    }
}
