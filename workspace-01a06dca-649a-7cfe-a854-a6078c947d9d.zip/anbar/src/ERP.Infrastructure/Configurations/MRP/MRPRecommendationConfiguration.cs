using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using ERP.Domain.Entities.MRP;

namespace ERP.Infrastructure.Configurations.MRP;

public class MRPRecommendationConfiguration : IEntityTypeConfiguration<MRPRecommendation>
{
    public void Configure(EntityTypeBuilder<MRPRecommendation> builder)
    {
        builder.ToTable("MRPRecommendations");
        builder.HasKey(mr => mr.Id);
        builder.Property(mr => mr.Id).ValueGeneratedOnAdd();

        builder.Property(mr => mr.MRPPlanId).IsRequired();
        builder.Property(mr => mr.RecommendationType).IsRequired();
        builder.Property(mr => mr.RecommendedQuantity).IsRequired();
        builder.Property(mr => mr.RecommendedCost).HasColumnType("decimal(18,2)");
        builder.Property(mr => mr.Status).HasMaxLength(50).IsRequired();
        builder.Property(mr => mr.IsActive).IsRequired();
        builder.Property(mr => mr.CreatedAt).IsRequired();
        builder.Property(mr => mr.CreatedBy).HasMaxLength(100).IsRequired();

        builder.HasIndex(mr => mr.MRPPlanId);
        builder.HasIndex(mr => mr.IsActive);
        builder.HasIndex(mr => mr.RecommendationType);
    }
}
