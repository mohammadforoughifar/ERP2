using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using ERP.Domain.Entities.MRP;

namespace ERP.Infrastructure.Configurations.MRP;

public class MRPItemRequirementConfiguration : IEntityTypeConfiguration<MRPItemRequirement>
{
    public void Configure(EntityTypeBuilder<MRPItemRequirement> builder)
    {
        builder.ToTable("MRPItemRequirements");
        builder.HasKey(mir => mir.Id);
        builder.Property(mir => mir.Id).ValueGeneratedOnAdd();

        builder.Property(mir => mir.MRPPlanId).IsRequired();
        builder.Property(mir => mir.ProductId).IsRequired();
        builder.Property(mir => mir.DemandQuantity).IsRequired();
        builder.Property(mir => mir.SupplyQuantity).IsRequired();
        builder.Property(mir => mir.NetRequirement).IsRequired();
        builder.Property(mir => mir.IsActive).IsRequired();
        builder.Property(mir => mr.CreatedAt).IsRequired();
        builder.Property(mir => mr.CreatedBy).HasMaxLength(100).IsRequired();

        builder.HasIndex(mir => mir.MRPPlanId);
        builder.HasIndex(mir => mir.ProductId);
        builder.HasIndex(mir => mir.IsActive);
    }
}
