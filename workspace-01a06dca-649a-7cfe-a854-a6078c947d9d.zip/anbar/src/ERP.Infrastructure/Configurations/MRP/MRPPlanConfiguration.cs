using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using ERP.Domain.Entities.MRP;

namespace ERP.Infrastructure.Configurations.MRP;

public class MRPPlanConfiguration : IEntityTypeConfiguration<MRPPlan>
{
    public void Configure(EntityTypeBuilder<MRPPlan> builder)
    {
        builder.ToTable("MRPPlans");
        builder.HasKey(mp => mp.Id);
        builder.Property(mp => mp.Id).ValueGeneratedOnAdd();

        builder.Property(mp => mp.CompanyId).IsRequired();
        builder.Property(mp => mp.PlanNumber).HasMaxLength(50).IsRequired();
        builder.Property(mp => mp.Status).HasMaxLength(50).IsRequired();
        builder.Property(mp => mp.IsActive).IsRequired();
        builder.Property(mp => mp.CreatedAt).IsRequired();
        builder.Property(mp => mp.CreatedBy).HasMaxLength(100).IsRequired();

        builder.HasIndex(mp => mp.PlanNumber).IsUnique();
        builder.HasIndex(mp => mp.IsActive);
        builder.HasIndex(mp => mp.CompanyId);
        builder.HasIndex(mp => mp.PlanDate);
    }
}
