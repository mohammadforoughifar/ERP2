using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using ERP.Domain.Entities.Approval;

namespace ERP.Infrastructure.Configurations.Approval;

public class ApprovalRequestConfiguration : IEntityTypeConfiguration<ApprovalRequest>
{
    public void Configure(EntityTypeBuilder<ApprovalRequest> builder)
    {
        builder.ToTable("ApprovalRequests");
        builder.HasKey(ar => ar.Id);
        builder.Property(ar => ar.Id).ValueGeneratedOnAdd();

        builder.Property(ar => ar.CompanyId).IsRequired();
        builder.Property(ar => ar.DocumentId).IsRequired();
        builder.Property(ar => ar.DocumentType).HasMaxLength(100).IsRequired();
        builder.Property(ar => ar.RequesterId).IsRequired();
        builder.Property(ar => ar.Amount).HasColumnType("decimal(18,2)");
        builder.Property(ar => ar.Priority).HasMaxLength(50).IsRequired();
        builder.Property(ar => ar.Status).HasMaxLength(50).IsRequired();
        builder.Property(ar => ar.IsActive).IsRequired();
        builder.Property(ar => ar.CreatedAt).IsRequired();
        builder.Property(ar => ar.CreatedBy).HasMaxLength(100).IsRequired();

        builder.HasIndex(ar => ar.IsActive);
        builder.HasIndex(ar => ar.CompanyId);
        builder.HasIndex(ar => ar.Status);
        builder.HasIndex(ar => ar.DocumentId);
        builder.HasIndex(ar => ar.RequesterId);
    }
}
