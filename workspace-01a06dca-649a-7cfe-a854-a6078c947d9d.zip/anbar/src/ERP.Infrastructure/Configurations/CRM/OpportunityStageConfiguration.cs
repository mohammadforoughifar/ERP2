using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using ERP.Domain.Entities.CRM;

namespace ERP.Infrastructure.Configurations.CRM;

public class OpportunityStageConfiguration : IEntityTypeConfiguration<OpportunityStage>
{
    public void Configure(EntityTypeBuilder<OpportunityStage> builder)
    {
        builder.ToTable("OpportunityStages");
        builder.HasKey(os => os.Id);
        builder.Property(os => os.Id).ValueGeneratedOnAdd();

        builder.Property(os => os.CompanyId).IsRequired();
        builder.Property(os => os.Name).HasMaxLength(200).IsRequired();
        builder.Property(os => os.Probability).HasColumnType("decimal(5,2)");
        builder.Property(os => os.IsActive).IsRequired();
        builder.Property(os => os.CreatedAt).IsRequired();
        builder.Property(os => os.CreatedBy).HasMaxLength(100).IsRequired();

        builder.HasIndex(os => os.IsActive);
        builder.HasIndex(os => os.CompanyId);
        builder.HasIndex(os => os.Order);
    }
}
