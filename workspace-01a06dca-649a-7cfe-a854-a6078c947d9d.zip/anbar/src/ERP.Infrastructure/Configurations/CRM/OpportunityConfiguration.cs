using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using ERP.Domain.Entities.CRM;

namespace ERP.Infrastructure.Configurations.CRM;

public class OpportunityConfiguration : IEntityTypeConfiguration<Opportunity>
{
    public void Configure(EntityTypeBuilder<Opportunity> builder)
    {
        builder.ToTable("Opportunities");
        builder.HasKey(o => o.Id);
        builder.Property(o => o.Id).ValueGeneratedOnAdd();

        builder.Property(o => o.CompanyId).IsRequired();
        builder.Property(o => o.AssignedToUserId).IsRequired();
        builder.Property(o => o.Title).HasMaxLength(200).IsRequired();
        builder.Property(o => o.ExpectedValue).HasColumnType("decimal(18,2)");
        builder.Property(o => o.Status).HasMaxLength(50).IsRequired();
        builder.Property(o => o.Probability).HasColumnType("decimal(5,2)");
        builder.Property(o => o.IsActive).IsRequired();
        builder.Property(o => o.CreatedAt).IsRequired();
        builder.Property(o => o.CreatedBy).HasMaxLength(100).IsRequired();

        builder.HasIndex(o => o.IsActive);
        builder.HasIndex(o => o.CompanyId);
        builder.HasIndex(o => o.CustomerId);
        builder.HasIndex(o => o.Status);
        builder.HasIndex(o => o.ExpectedCloseDate);
    }
}
