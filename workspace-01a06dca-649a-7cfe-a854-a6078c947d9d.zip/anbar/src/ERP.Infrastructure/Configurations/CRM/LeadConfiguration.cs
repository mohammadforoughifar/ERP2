using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using ERP.Domain.Entities.CRM;

namespace ERP.Infrastructure.Configurations.CRM;

public class LeadConfiguration : IEntityTypeConfiguration<Lead>
{
    public void Configure(EntityTypeBuilder<Lead> builder)
    {
        builder.ToTable("Leads");
        builder.HasKey(l => l.Id);
        builder.Property(l => l.Id).ValueGeneratedOnAdd();

        builder.Property(l => l.CompanyId).IsRequired();
        builder.Property(l => l.FirstName).HasMaxLength(100).IsRequired();
        builder.Property(l => l.LastName).HasMaxLength(100);
        builder.Property(l => l.Email).HasMaxLength(200);
        builder.Property(l => l.Phone).HasMaxLength(50);
        builder.Property(l => l.Source).HasMaxLength(100);
        builder.Property(l => l.Status).HasMaxLength(50).IsRequired();
        builder.Property(l => l.IsActive).IsRequired();
        builder.Property(l => l.CreatedAt).IsRequired();
        builder.Property(l => l.CreatedBy).HasMaxLength(100).IsRequired();

        builder.HasIndex(l => l.IsActive);
        builder.HasIndex(l => l.CompanyId);
        builder.HasIndex(l => l.Status);
    }
}
