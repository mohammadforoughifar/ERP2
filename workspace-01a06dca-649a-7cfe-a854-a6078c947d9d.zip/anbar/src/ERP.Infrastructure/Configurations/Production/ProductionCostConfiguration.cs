using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using ERP.Domain.Entities.Production;

namespace ERP.Infrastructure.Configurations.Production;

public class ProductionCostConfiguration : IEntityTypeConfiguration<ProductionCost>
{
    public void Configure(EntityTypeBuilder<ProductionCost> builder)
    {
        builder.ToTable("ProductionCosts");
        builder.HasKey(pc => pc.Id);
        builder.Property(pc => pc.Id).ValueGeneratedOnAdd();

        builder.Property(pc => pc.CompanyId).IsRequired();
        builder.Property(pc => pc.ProductionOrderId).IsRequired();
        builder.Property(pc => pc.MaterialCost).HasColumnType("decimal(18,2)");
        builder.Property(pc => pc.LaborCost).HasColumnType("decimal(18,2)");
        builder.Property(pc => pc.MachineCost).HasColumnType("decimal(18,2)");
        builder.Property(pc => pc.OverheadCost).HasColumnType("decimal(18,2)");
        builder.Property(pc => pc.ActualTotalCost).HasColumnType("decimal(18,2)");
        builder.Property(pc => pc.StandardTotalCost).HasColumnType("decimal(18,2)");
        builder.Property(pc => pc.Variance).HasColumnType("decimal(18,2)");
        builder.Property(pc => pc.CostStatus).HasMaxLength(50).IsRequired();
        builder.Property(pc => pc.IsActive).IsRequired();
        builder.Property(pc => pc.CreatedAt).IsRequired();
        builder.Property(pc => pc.CreatedBy).HasMaxLength(100).IsRequired();

        builder.HasIndex(pc => pc.IsActive);
        builder.HasIndex(pc => pc.CompanyId);
        builder.HasIndex(pc => pc.ProductionOrderId);
    }
}
