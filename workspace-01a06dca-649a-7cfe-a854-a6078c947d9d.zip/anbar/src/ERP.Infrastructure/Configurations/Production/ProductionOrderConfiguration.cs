using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using ERP.Domain.Entities.Production;

namespace ERP.Infrastructure.Configurations.Production;

public class ProductionOrderConfiguration : IEntityTypeConfiguration<ProductionOrder>
{
    public void Configure(EntityTypeBuilder<ProductionOrder> builder)
    {
        builder.ToTable("ProductionOrders");
        builder.HasKey(po => po.Id);
        builder.Property(po => po.Id).ValueGeneratedOnAdd();

        builder.Property(po => po.CompanyId).IsRequired();
        builder.Property(po => po.ProductId).IsRequired();
        builder.Property(po => po.ProductionNumber).HasMaxLength(50).IsRequired();
        builder.Property(po => po.Status).HasMaxLength(50).IsRequired();
        builder.Property(po => po.PlannedQuantity).IsRequired();
        builder.Property(po => po.IsActive).IsRequired();
        builder.Property(po => po.CreatedAt).IsRequired();
        builder.Property(po => po.CreatedBy).HasMaxLength(100).IsRequired();

        builder.HasIndex(po => po.ProductionNumber).IsUnique();
        builder.HasIndex(po => po.IsActive);
        builder.HasIndex(po => po.CompanyId);
        builder.HasIndex(po => po.ProductId);
    }
}
