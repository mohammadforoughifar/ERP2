using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using ERP.Domain.Entities.Production;

namespace ERP.Infrastructure.Configurations.Production;

public class BOMConfiguration : IEntityTypeConfiguration<BOM>
{
    public void Configure(EntityTypeBuilder<BOM> builder)
    {
        builder.ToTable("BOMs");
        builder.HasKey(b => b.Id);
        builder.Property(b => b.Id).ValueGeneratedOnAdd();

        builder.Property(b => b.CompanyId).IsRequired();
        builder.Property(b => b.ProductId).IsRequired();
        builder.Property(b => b.BOMNumber).HasMaxLength(50).IsRequired();
        builder.Property(b => b.Level).IsRequired();
        builder.Property(b => b.Quantity).HasColumnType("decimal(18,4)");
        builder.Property(b => b.IsActive).IsRequired();
        builder.Property(b => b.CreatedAt).IsRequired();
        builder.Property(b => b.CreatedBy).HasMaxLength(100).IsRequired();

        builder.HasIndex(b => b.BOMNumber).IsUnique();
        builder.HasIndex(b => b.IsActive);
        builder.HasIndex(b => b.CompanyId);
        builder.HasIndex(b => b.ProductId);
    }
}
