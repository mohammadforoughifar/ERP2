using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using ERP.Domain.Entities.Production;

namespace ERP.Infrastructure.Configurations.Production;

public class WorkCenterConfiguration : IEntityTypeConfiguration<WorkCenter>
{
    public void Configure(EntityTypeBuilder<WorkCenter> builder)
    {
        builder.ToTable("WorkCenters");
        builder.HasKey(wc => wc.Id);
        builder.Property(wc => wc.Id).ValueGeneratedOnAdd();

        builder.Property(wc => wc.CompanyId).IsRequired();
        builder.Property(wc => wc.Code).HasMaxLength(50).IsRequired();
        builder.Property(wc => wc.Name).HasMaxLength(200).IsRequired();
        builder.Property(wc => wc.Type).HasMaxLength(100);
        builder.Property(wc => wc.CapacityPerHour).HasColumnType("decimal(18,4)");
        builder.Property(wc => wc.IsActive).IsRequired();
        builder.Property(wc => wc.CreatedAt).IsRequired();
        builder.Property(wc => wc.CreatedBy).HasMaxLength(100).IsRequired();

        builder.HasIndex(wc => wc.Code).IsUnique();
        builder.HasIndex(wc => wc.IsActive);
        builder.HasIndex(wc => wc.CompanyId);
    }
}
