using ERP.Domain.Entities.Reporting;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace ERP.Infrastructure.Configurations.Reporting;

public class KPIConfiguration : IEntityTypeConfiguration<KPI>
{
    public void Configure(EntityTypeBuilder<KPI> builder)
    {
        builder.ToTable("KPIs");
        builder.HasKey(x => x.Id);
        builder.Property(x => x.KPIName).HasMaxLength(200).IsRequired();
        builder.Property(x => x.Unit).HasMaxLength(50);
        builder.Property(x => x.Trend).HasMaxLength(20).HasDefaultValue("Stable");
        builder.Property(x => x.IsActive).HasDefaultValue(true);
    }
}
