using ERP.Domain.Entities.Reporting;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace ERP.Infrastructure.Configurations.Reporting;

public class DashboardConfiguration : IEntityTypeConfiguration<Dashboard>
{
    public void Configure(EntityTypeBuilder<Dashboard> builder)
    {
        builder.ToTable("Dashboards");
        builder.HasKey(x => x.Id);
        builder.Property(x => x.DashboardName).HasMaxLength(200).IsRequired();
        builder.Property(x => x.Status).HasMaxLength(50).HasDefaultValue("Active");
        builder.Property(x => x.IsActive).HasDefaultValue(true);
    }
}
