using ERP.Domain.Entities.Reporting;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace ERP.Infrastructure.Configurations.Reporting;

public class ChartConfiguration : IEntityTypeConfiguration<Chart>
{
    public void Configure(EntityTypeBuilder<Chart> builder)
    {
        builder.ToTable("Charts");
        builder.HasKey(x => x.Id);
        builder.Property(x => x.ChartName).HasMaxLength(200).IsRequired();
        builder.Property(x => x.ChartType).HasMaxLength(50).HasDefaultValue("Bar");
        builder.Property(x => x.IsActive).HasDefaultValue(true);
    }
}
