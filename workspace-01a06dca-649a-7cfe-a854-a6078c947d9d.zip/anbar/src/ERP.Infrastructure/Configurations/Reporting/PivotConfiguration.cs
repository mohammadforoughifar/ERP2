using ERP.Domain.Entities.Reporting;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace ERP.Infrastructure.Configurations.Reporting;

public class PivotConfiguration : IEntityTypeConfiguration<Pivot>
{
    public void Configure(EntityTypeBuilder<Pivot> builder)
    {
        builder.ToTable("Pivots");
        builder.HasKey(x => x.Id);
        builder.Property(x => x.PivotName).HasMaxLength(200).IsRequired();
        builder.Property(x => x.IsActive).HasDefaultValue(true);
    }
}
