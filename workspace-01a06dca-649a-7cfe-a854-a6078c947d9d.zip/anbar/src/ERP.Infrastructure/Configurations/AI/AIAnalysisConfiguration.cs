using ERP.Domain.Entities.AI;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace ERP.Infrastructure.Configurations.AI;

public class AIAnalysisConfiguration : IEntityTypeConfiguration<AIAnalysis>
{
    public void Configure(EntityTypeBuilder<AIAnalysis> builder)
    {
        builder.ToTable("AIAnalyses");
        builder.HasKey(x => x.Id);
        builder.Property(x => x.AnalysisType).HasMaxLength(200).IsRequired();
        builder.Property(x => x.AnalysisResult).HasMaxLength(2000);
        builder.Property(x => x.Status).HasMaxLength(50).HasDefaultValue("Draft");
        builder.Property(x => x.IsActive).HasDefaultValue(true);
    }
}
