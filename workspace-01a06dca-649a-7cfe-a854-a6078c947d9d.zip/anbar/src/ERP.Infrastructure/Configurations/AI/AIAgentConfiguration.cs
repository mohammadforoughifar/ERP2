using ERP.Domain.Entities.AI;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace ERP.Infrastructure.Configurations.AI;

public class AIAgentConfiguration : IEntityTypeConfiguration<AIAgent>
{
    public void Configure(EntityTypeBuilder<AIAgent> builder)
    {
        builder.ToTable("AIAgents");
        builder.HasKey(x => x.Id);
        builder.Property(x => x.AgentName).HasMaxLength(200).IsRequired();
        builder.Property(x => x.Status).HasMaxLength(100).HasDefaultValue("Active");
        builder.Property(x => x.IsActive).HasDefaultValue(true);
    }
}
