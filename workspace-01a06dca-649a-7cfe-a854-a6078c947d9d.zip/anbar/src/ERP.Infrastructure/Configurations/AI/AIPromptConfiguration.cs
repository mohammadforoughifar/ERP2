using ERP.Domain.Entities.AI;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace ERP.Infrastructure.Configurations.AI;

public class AIPromptConfiguration : IEntityTypeConfiguration<AIPrompt>
{
    public void Configure(EntityTypeBuilder<AIPrompt> builder)
    {
        builder.ToTable("AIPrompts");
        builder.HasKey(x => x.Id);
        builder.Property(x => x.PromptText).HasMaxLength(4000);
        builder.Property(x => x.Status).HasMaxLength(50).HasDefaultValue("Pending");
        builder.Property(x => x.IsActive).HasDefaultValue(true);
    }
}
