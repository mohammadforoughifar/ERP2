using ERP.Domain.Entities.AI;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace ERP.Infrastructure.Configurations.AI;

public class AIPredictionConfiguration : IEntityTypeConfiguration<AIPrediction>
{
    public void Configure(EntityTypeBuilder<AIPrediction> builder)
    {
        builder.ToTable("AIPredictions");
        builder.HasKey(x => x.Id);
        builder.Property(x => x.PredictionType).HasMaxLength(200).IsRequired();
        builder.Property(x => x.Status).HasMaxLength(50).HasDefaultValue("Pending");
        builder.Property(x => x.IsActive).HasDefaultValue(true);
    }
}
