using ERP.Domain.Entities.AI;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace ERP.Infrastructure.Configurations.AI;

public class AIResponseConfiguration : IEntityTypeConfiguration<AIResponse>
{
    public void Configure(EntityTypeBuilder<AIResponse> builder)
    {
        builder.ToTable("AIResponses");
        builder.HasKey(x => x.Id);
        builder.Property(x => x.ResponseText).HasMaxLength(4000);
        builder.Property(x => x.Status).HasMaxLength(50).HasDefaultValue("Generated");
        builder.Property(x => x.IsActive).HasDefaultValue(true);
    }
}
