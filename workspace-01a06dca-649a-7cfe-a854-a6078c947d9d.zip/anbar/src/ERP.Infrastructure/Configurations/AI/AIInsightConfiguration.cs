using ERP.Domain.Entities.AI;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace ERP.Infrastructure.Configurations.AI;

public class AIInsightConfiguration : IEntityTypeConfiguration<AIInsight>
{
    public void Configure(EntityTypeBuilder<AIInsight> builder)
    {
        builder.ToTable("AIInsights");
        builder.HasKey(x => x.Id);
        builder.Property(x => x.InsightTitle).HasMaxLength(500).IsRequired();
        builder.Property(x => x.InsightContent).HasMaxLength(2000);
        builder.Property(x => x.Priority).HasMaxLength(100).HasDefaultValue("Medium");
        builder.Property(x => x.IsActive).HasDefaultValue(true);
    }
}
