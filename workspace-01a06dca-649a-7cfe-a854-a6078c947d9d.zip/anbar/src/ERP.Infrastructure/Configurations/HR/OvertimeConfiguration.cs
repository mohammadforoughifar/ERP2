using ERP.Domain.Entities.HR;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace ERP.Infrastructure.Configurations.HR;

public class OvertimeConfiguration : IEntityTypeConfiguration<Overtime>
{
    public void Configure(EntityTypeBuilder<Overtime> builder)
    {
        builder.ToTable("Overtimes");
        builder.HasKey(x => x.Id);
        builder.Property(x => x.Status).HasMaxLength(50).HasDefaultValue("Pending");
        builder.Property(x => x.IsActive).HasDefaultValue(true);
    }
}
