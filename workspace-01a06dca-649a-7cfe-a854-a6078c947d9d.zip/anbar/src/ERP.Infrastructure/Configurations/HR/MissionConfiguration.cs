using ERP.Domain.Entities.HR;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace ERP.Infrastructure.Configurations.HR;

public class MissionConfiguration : IEntityTypeConfiguration<Mission>
{
    public void Configure(EntityTypeBuilder<Mission> builder)
    {
        builder.ToTable("Missions");
        builder.HasKey(x => x.Id);
        builder.Property(x => x.Destination).HasMaxLength(500).IsRequired();
        builder.Property(x => x.Purpose).HasMaxLength(2000);
        builder.Property(x => x.Status).HasMaxLength(50).HasDefaultValue("Pending");
        builder.Property(x => x.IsActive).HasDefaultValue(true);
    }
}
