using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using ERP.Domain.Entities.HR;

namespace ERP.Infrastructure.Configurations.HR;

public class ContractConfiguration : IEntityTypeConfiguration<Contract>
{
    public void Configure(EntityTypeBuilder<Contract> builder)
    {
        builder.ToTable("Contracts");
        builder.HasKey(c => c.Id);
        builder.Property(c => c.Id).ValueGeneratedOnAdd();

        builder.Property(c => c.CompanyId).IsRequired();
        builder.Property(c => c.EmployeeId).IsRequired();
        builder.Property(c => c.ContractNumber).HasMaxLength(50).IsRequired();
        builder.Property(c => c.Type).IsRequired();
        builder.Property(c => c.BaseSalary).HasColumnType("decimal(18,2)");
        builder.Property(c => c.IsActive).IsRequired();
        builder.Property(c => c.CreatedAt).IsRequired();
        builder.Property(c => c.CreatedBy).HasMaxLength(100).IsRequired();

        builder.HasIndex(c => c.ContractNumber).IsUnique();
        builder.HasIndex(c => c.IsActive);
        builder.HasIndex(c => c.CompanyId);
        builder.HasIndex(c => c.EmployeeId);
    }
}
