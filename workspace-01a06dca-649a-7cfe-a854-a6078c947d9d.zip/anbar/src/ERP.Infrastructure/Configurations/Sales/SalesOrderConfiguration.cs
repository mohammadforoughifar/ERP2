using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using ERP.Domain.Entities.Sales;

namespace ERP.Infrastructure.Configurations.Sales;

public class SalesOrderConfiguration : IEntityTypeConfiguration<SalesOrder>
{
    public void Configure(EntityTypeBuilder<SalesOrder> builder)
    {
        builder.ToTable("SalesOrders");
        builder.HasKey(so => so.Id);
        builder.Property(so => so.Id).ValueGeneratedOnAdd();

        builder.Property(so => so.CompanyId).IsRequired();
        builder.Property(so => so.CustomerId).IsRequired();
        builder.Property(so => so.OrderNumber).HasMaxLength(50).IsRequired();
        builder.Property(so => so.Status).HasMaxLength(50).IsRequired();
        builder.Property(so => so.TotalAmount).HasColumnType("decimal(18,2)");
        builder.Property(so => so.IsActive).IsRequired();
        builder.Property(so => so.CreatedAt).IsRequired();
        builder.Property(so => so.CreatedBy).HasMaxLength(100).IsRequired();

        builder.HasIndex(so => so.OrderNumber).IsUnique();
        builder.HasIndex(so => so.IsActive);
        builder.HasIndex(so => so.CompanyId);
        builder.HasIndex(so => so.CustomerId);
    }
}
