using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using ERP.Domain.Entities.Sales;

namespace ERP.Infrastructure.Configurations.Sales;

public class QuotationConfiguration : IEntityTypeConfiguration<Quotation>
{
    public void Configure(EntityTypeBuilder<Quotation> builder)
    {
        builder.ToTable("Quotations");
        builder.HasKey(q => q.Id);
        builder.Property(q => q.Id).ValueGeneratedOnAdd();

        builder.Property(q => q.CompanyId).IsRequired();
        builder.Property(q => q.CustomerId).IsRequired();
        builder.Property(q => q.QuotationNumber).HasMaxLength(50).IsRequired();
        builder.Property(q => q.QuotationDate).IsRequired();
        builder.Property(q => q.ValidUntil).IsRequired();
        builder.Property(q => q.TotalAmount).HasColumnType("decimal(18,2)");
        builder.Property(q => q.Status).HasMaxLength(50).IsRequired();
        builder.Property(q => q.IsActive).IsRequired();
        builder.Property(q => q.CreatedAt).IsRequired();
        builder.Property(q => q.CreatedBy).HasMaxLength(100).IsRequired();

        builder.HasIndex(q => q.QuotationNumber).IsUnique();
        builder.HasIndex(q => q.IsActive);
        builder.HasIndex(q => q.CompanyId);
        builder.HasIndex(q => q.CustomerId);
    }
}
