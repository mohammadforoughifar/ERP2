using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using ERP.Domain.Entities.Sales;

namespace ERP.Infrastructure.Configurations.Sales;

public class SalesReceiptConfiguration : IEntityTypeConfiguration<SalesReceipt>
{
    public void Configure(EntityTypeBuilder<SalesReceipt> builder)
    {
        builder.ToTable("SalesReceipts");
        builder.HasKey(sr => sr.Id);
        builder.Property(sr => sr.Id).ValueGeneratedOnAdd();

        builder.Property(sr => sr.CompanyId).IsRequired();
        builder.Property(sr => sr.CustomerId).IsRequired();
        builder.Property(sr => sr.ReceiptNumber).HasMaxLength(50).IsRequired();
        builder.Property(sr => sr.Amount).HasColumnType("decimal(18,2)").IsRequired();
        builder.Property(sr => sr.PaymentMethod).HasMaxLength(50).IsRequired();
        builder.Property(sr => sr.IsActive).IsRequired();
        builder.Property(sr => sr.CreatedAt).IsRequired();
        builder.Property(sr => sr.CreatedBy).HasMaxLength(100).IsRequired();

        builder.HasIndex(sr => sr.ReceiptNumber).IsUnique();
        builder.HasIndex(sr => sr.IsActive);
        builder.HasIndex(sr => sr.CompanyId);
        builder.HasIndex(sr => sr.CustomerId);
        builder.HasIndex(sr => sr.ReceiptDate);
    }
}
