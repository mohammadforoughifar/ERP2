using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using ERP.Domain.Entities.Workflow;

namespace ERP.Infrastructure.Configurations.Workflow;

public class WorkflowDefinitionConfiguration : IEntityTypeConfiguration<WorkflowDefinition>
{
    public void Configure(EntityTypeBuilder<WorkflowDefinition> builder)
    {
        builder.ToTable("WorkflowDefinitions");
        builder.HasKey(wd => wd.Id);
        builder.Property(wd => wd.Id).ValueGeneratedOnAdd();

        builder.Property(wd => wd.CompanyId).IsRequired();
        builder.Property(wd => wd.WorkflowName).HasMaxLength(200).IsRequired();
        builder.Property(wd => wd.DocumentType).HasMaxLength(100).IsRequired();
        builder.Property(wd => wd.Module).HasMaxLength(100);
        builder.Property(wd => wd.IsActive).IsRequired();
        builder.Property(wd => wd.CreatedAt).IsRequired();
        builder.Property(wd => wd.CreatedBy).HasMaxLength(100).IsRequired();

        builder.HasIndex(wd => wd.WorkflowName);
        builder.HasIndex(wd => wd.IsActive);
        builder.HasIndex(wd => wd.CompanyId);
        builder.HasIndex(wd => wd.DocumentType);
    }
}
