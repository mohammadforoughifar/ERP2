using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using ERP.Domain.Entities.Workflow;

namespace ERP.Infrastructure.Configurations.Workflow;

public class WorkflowInstanceConfiguration : IEntityTypeConfiguration<WorkflowInstance>
{
    public void Configure(EntityTypeBuilder<WorkflowInstance> builder)
    {
        builder.ToTable("WorkflowInstances");
        builder.HasKey(wi => wi.Id);
        builder.Property(wi => wi.Id).ValueGeneratedOnAdd();

        builder.Property(wi => wi.WorkflowDefinitionId).IsRequired();
        builder.Property(wi => wi.DocumentId).IsRequired();
        builder.Property(wi => wi.DocumentType).HasMaxLength(100).IsRequired();
        builder.Property(wi => wi.Status).HasMaxLength(50).IsRequired();
        builder.Property(wi => wi.IsActive).IsRequired();
        builder.Property(wi => wi.CreatedAt).IsRequired();
        builder.Property(wi => wi.CreatedBy).HasMaxLength(100).IsRequired();

        builder.HasIndex(wi => wi.IsActive);
        builder.HasIndex(wi => wi.WorkflowDefinitionId);
        builder.HasIndex(wi => wi.DocumentId);
        builder.HasIndex(wi => wi.Status);
    }
}
