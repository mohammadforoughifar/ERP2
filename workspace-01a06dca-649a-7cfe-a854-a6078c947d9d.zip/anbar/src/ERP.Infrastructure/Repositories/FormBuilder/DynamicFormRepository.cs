using ERP.Application.Interfaces;
using ERP.Domain.Entities.FormBuilder;
using ERP.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ERP.Infrastructure.Repositories.FormBuilder;

public class DynamicFormRepository : IDynamicFormRepository
{
    private readonly ApplicationDbContext _context;

    public DynamicFormRepository(ApplicationDbContext context)
    {
        _context = context;
    }

    public async Task<DynamicForm?> GetByIdAsync(int id)
    {
        return await _context.DynamicForms
            .Where(x => x.IsActive == true)
            .FirstOrDefaultAsync(x => x.Id == id);
    }

    public async Task<IEnumerable<DynamicForm>> GetAllAsync()
    {
        return await _context.DynamicForms
            .Where(x => x.IsActive == true)
            .ToListAsync();
    }

    public async Task<IEnumerable<DynamicForm>> GetActiveAsync()
    {
        return await _context.DynamicForms
            .Where(x => x.IsActive == true)
            .ToListAsync();
    }

    public async Task AddAsync(DynamicForm form)
    {
        await _context.DynamicForms.AddAsync(form);
        await _context.SaveChangesAsync();
    }

    public async Task UpdateAsync(DynamicForm form)
    {
        _context.DynamicForms.Update(form);
        await _context.SaveChangesAsync();
    }

    public async Task DeleteAsync(DynamicForm form)
    {
        form.IsActive = false;
        _context.DynamicForms.Update(form);
        await _context.SaveChangesAsync();
    }
}
