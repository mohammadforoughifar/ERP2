using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using ERP.Application.Interfaces;
using ERP.Domain.Entities.Finance;
using ERP.Infrastructure.Data;

namespace ERP.Infrastructure.Repositories.Finance;

public class ChartOfAccountRepository : IChartOfAccountRepository
{
    private readonly ApplicationDbContext _context;

    public ChartOfAccountRepository(ApplicationDbContext context)
    {
        _context = context ?? throw new ArgumentNullException(nameof(context));
    }

    public async Task<ChartOfAccount?> GetByIdAsync(int id, CancellationToken cancellationToken = default)
    {
        return await _context.Set<ChartOfAccount>()
            .AsNoTracking()
            .FirstOrDefaultAsync(a => a.Id == id, cancellationToken);
    }

    public async Task<ChartOfAccount?> GetByCodeAsync(string code, int companyId, CancellationToken cancellationToken = default)
    {
        return await _context.Set<ChartOfAccount>()
            .AsNoTracking()
            .FirstOrDefaultAsync(a => a.Code == code && a.CompanyId == companyId && a.IsActive, cancellationToken);
    }

    public async Task AddAsync(ChartOfAccount account, CancellationToken cancellationToken = default)
    {
        await _context.Set<ChartOfAccount>().AddAsync(account, cancellationToken);
    }

    public async Task UpdateAsync(ChartOfAccount account, CancellationToken cancellationToken = default)
    {
        _context.Set<ChartOfAccount>().Update(account);
        await Task.CompletedTask;
    }

    public async Task SaveChangesAsync(CancellationToken cancellationToken = default)
    {
        await _context.SaveChangesAsync(cancellationToken);
    }
}
