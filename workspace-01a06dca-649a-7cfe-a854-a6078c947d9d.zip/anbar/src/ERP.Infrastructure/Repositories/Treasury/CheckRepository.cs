using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using ERP.Application.Interfaces;
using ERP.Domain.Entities.Treasury;
using ERP.Infrastructure.Data;

namespace ERP.Infrastructure.Repositories.Treasury;

public class CheckRepository : ICheckRepository
{
    private readonly ApplicationDbContext _context;

    public CheckRepository(ApplicationDbContext context)
    {
        _context = context ?? throw new ArgumentNullException(nameof(context));
    }

    public async Task<Check?> GetByIdAsync(int id, CancellationToken cancellationToken = default)
    {
        return await _context.Set<Check>()
            .AsNoTracking()
            .FirstOrDefaultAsync(c => c.Id == id, cancellationToken);
    }

    public async Task<Check?> GetByCheckNumberAsync(string checkNumber, int companyId, CancellationToken cancellationToken = default)
    {
        return await _context.Set<Check>()
            .AsNoTracking()
            .FirstOrDefaultAsync(c => c.CheckNumber == checkNumber && c.CompanyId == companyId && c.IsActive, cancellationToken);
    }

    public async Task AddAsync(Check check, CancellationToken cancellationToken = default)
    {
        await _context.Set<Check>().AddAsync(check, cancellationToken);
    }

    public async Task UpdateAsync(Check check, CancellationToken cancellationToken = default)
    {
        _context.Set<Check>().Update(check);
        await Task.CompletedTask;
    }

    public async Task SaveChangesAsync(CancellationToken cancellationToken = default)
    {
        await _context.SaveChangesAsync(cancellationToken);
    }
}
