using ERP.Application.Interfaces;
using ERP.Domain.Entities.Integration;
using ERP.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
namespace ERP.Infrastructure.Repositories.Integration;
public class IntegrationEndpointRepository : IIntegrationEndpointRepository
{
    private readonly ApplicationDbContext _context;
    public IntegrationEndpointRepository(ApplicationDbContext context) { _context = context; }
    public async Task<IntegrationEndpoint?> GetByIdAsync(int id) => await _context.IntegrationEndpoints.Where(x => x.IsActive == true).FirstOrDefaultAsync(x => x.Id == id);
    public async Task<IEnumerable<IntegrationEndpoint>> GetActiveAsync() => await _context.IntegrationEndpoints.Where(x => x.IsActive == true).ToListAsync();
    public async Task AddAsync(IntegrationEndpoint item) { await _context.IntegrationEndpoints.AddAsync(item); await _context.SaveChangesAsync(); }
    public async Task UpdateAsync(IntegrationEndpoint item) { _context.IntegrationEndpoints.Update(item); await _context.SaveChangesAsync(); }
    public async Task DeleteAsync(IntegrationEndpoint item) { item.IsActive = false; _context.IntegrationEndpoints.Update(item); await _context.SaveChangesAsync(); }
}
