using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using ERP.Application.Interfaces;
using ERP.Domain.Entities.Inventory;
using ERP.Infrastructure.Data;

namespace ERP.Infrastructure.Repositories.Inventory;

public class InventoryTransactionRepository : IInventoryTransactionRepository
{
    private readonly ApplicationDbContext _context;

    public InventoryTransactionRepository(ApplicationDbContext context)
    {
        _context = context ?? throw new ArgumentNullException(nameof(context));
    }

    public async Task<InventoryTransaction?> GetByIdAsync(int id, CancellationToken cancellationToken = default)
    {
        return await _context.Set<InventoryTransaction>()
            .AsNoTracking()
            .FirstOrDefaultAsync(t => t.Id == id, cancellationToken);
    }

    public async Task AddAsync(InventoryTransaction transaction, CancellationToken cancellationToken = default)
    {
        await _context.Set<InventoryTransaction>().AddAsync(transaction, cancellationToken);
    }

    public async Task UpdateAsync(InventoryTransaction transaction, CancellationToken cancellationToken = default)
    {
        _context.Set<InventoryTransaction>().Update(transaction);
        await Task.CompletedTask;
    }

    public async Task SaveChangesAsync(CancellationToken cancellationToken = default)
    {
        await _context.SaveChangesAsync(cancellationToken);
    }
}
