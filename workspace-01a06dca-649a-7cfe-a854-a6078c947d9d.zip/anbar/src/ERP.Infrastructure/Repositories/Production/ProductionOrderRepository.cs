using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using ERP.Application.Interfaces;
using ERP.Domain.Entities.Production;
using ERP.Infrastructure.Data;

namespace ERP.Infrastructure.Repositories.Production;

public class ProductionOrderRepository : IProductionOrderRepository
{
    private readonly ApplicationDbContext _context;

    public ProductionOrderRepository(ApplicationDbContext context)
    {
        _context = context ?? throw new ArgumentNullException(nameof(context));
    }

    public async Task<ProductionOrder?> GetByIdAsync(int id, CancellationToken cancellationToken = default)
    {
        return await _context.Set<ProductionOrder>()
            .AsNoTracking()
            .FirstOrDefaultAsync(po => po.Id == id, cancellationToken);
    }

    public async Task<ProductionOrder?> GetByProductionNumberAsync(string productionNumber, int companyId, CancellationToken cancellationToken = default)
    {
        return await _context.Set<ProductionOrder>()
            .AsNoTracking()
            .FirstOrDefaultAsync(po => po.ProductionNumber == productionNumber && po.CompanyId == companyId && po.IsActive, cancellationToken);
    }

    public async Task AddAsync(ProductionOrder productionOrder, CancellationToken cancellationToken = default)
    {
        await _context.Set<ProductionOrder>().AddAsync(productionOrder, cancellationToken);
    }

    public async Task UpdateAsync(ProductionOrder productionOrder, CancellationToken cancellationToken = default)
    {
        _context.Set<ProductionOrder>().Update(productionOrder);
        await Task.CompletedTask;
    }

    public async Task SaveChangesAsync(CancellationToken cancellationToken = default)
    {
        await _context.SaveChangesAsync(cancellationToken);
    }
}
