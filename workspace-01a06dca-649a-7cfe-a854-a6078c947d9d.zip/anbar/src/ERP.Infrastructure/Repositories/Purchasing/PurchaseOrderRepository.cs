using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using ERP.Application.Interfaces;
using ERP.Domain.Entities.Purchasing;
using ERP.Infrastructure.Data;

namespace ERP.Infrastructure.Repositories.Purchasing;

public class PurchaseOrderRepository : IPurchaseOrderRepository
{
    private readonly ApplicationDbContext _context;

    public PurchaseOrderRepository(ApplicationDbContext context)
    {
        _context = context ?? throw new ArgumentNullException(nameof(context));
    }

    public async Task<PurchaseOrder?> GetByIdAsync(int id, CancellationToken cancellationToken = default)
    {
        return await _context.Set<PurchaseOrder>()
            .AsNoTracking()
            .FirstOrDefaultAsync(po => po.Id == id, cancellationToken);
    }

    public async Task<PurchaseOrder?> GetByOrderNumberAsync(string orderNumber, int companyId, CancellationToken cancellationToken = default)
    {
        return await _context.Set<PurchaseOrder>()
            .AsNoTracking()
            .FirstOrDefaultAsync(po => po.OrderNumber == orderNumber && po.CompanyId == companyId && po.IsActive, cancellationToken);
    }

    public async Task AddAsync(PurchaseOrder purchaseOrder, CancellationToken cancellationToken = default)
    {
        await _context.Set<PurchaseOrder>().AddAsync(purchaseOrder, cancellationToken);
    }

    public async Task UpdateAsync(PurchaseOrder purchaseOrder, CancellationToken cancellationToken = default)
    {
        _context.Set<PurchaseOrder>().Update(purchaseOrder);
        await Task.CompletedTask;
    }

    public async Task SaveChangesAsync(CancellationToken cancellationToken = default)
    {
        await _context.SaveChangesAsync(cancellationToken);
    }
}
