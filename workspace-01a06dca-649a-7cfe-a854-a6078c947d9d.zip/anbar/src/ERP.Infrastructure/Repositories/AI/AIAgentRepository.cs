using ERP.Application.Interfaces;
using ERP.Domain.Entities.AI;
using ERP.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ERP.Infrastructure.Repositories.AI;

public class AIAgentRepository : IAIAgentRepository
{
    private readonly ApplicationDbContext _context;

    public AIAgentRepository(ApplicationDbContext context)
    {
        _context = context;
    }

    public async Task<AIAgent?> GetByIdAsync(int id)
    {
        return await _context.AIAgents
            .Where(x => x.IsActive == true)
            .FirstOrDefaultAsync(x => x.Id == id);
    }

    public async Task<IEnumerable<AIAgent>> GetActiveAsync()
    {
        return await _context.AIAgents
            .Where(x => x.IsActive == true)
            .ToListAsync();
    }

    public async Task AddAsync(AIAgent agent)
    {
        await _context.AIAgents.AddAsync(agent);
        await _context.SaveChangesAsync();
    }

    public async Task UpdateAsync(AIAgent agent)
    {
        _context.AIAgents.Update(agent);
        await _context.SaveChangesAsync();
    }

    public async Task DeleteAsync(AIAgent agent)
    {
        agent.IsActive = false;
        _context.AIAgents.Update(agent);
        await _context.SaveChangesAsync();
    }
}
