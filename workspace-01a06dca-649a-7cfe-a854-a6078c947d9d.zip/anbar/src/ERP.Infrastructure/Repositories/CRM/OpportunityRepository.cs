using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using ERP.Application.Interfaces;
using ERP.Domain.Entities.CRM;
using ERP.Infrastructure.Data;

namespace ERP.Infrastructure.Repositories.CRM;

public class OpportunityRepository : IOpportunityRepository
{
    private readonly ApplicationDbContext _context;

    public OpportunityRepository(ApplicationDbContext context)
    {
        _context = context ?? throw new ArgumentNullException(nameof(context));
    }

    public async Task<Opportunity?> GetByIdAsync(int id, CancellationToken cancellationToken = default)
    {
        return await _context.Set<Opportunity>()
            .AsNoTracking()
            .FirstOrDefaultAsync(o => o.Id == id, cancellationToken);
    }

    public async Task<Opportunity?> GetByTitleAsync(string title, int companyId, CancellationToken cancellationToken = default)
    {
        return await _context.Set<Opportunity>()
            .AsNoTracking()
            .FirstOrDefaultAsync(o => o.Title == title && o.CompanyId == companyId && o.IsActive, cancellationToken);
    }

    public async Task AddAsync(Opportunity opportunity, CancellationToken cancellationToken = default)
    {
        await _context.Set<Opportunity>().AddAsync(opportunity, cancellationToken);
    }

    public async Task UpdateAsync(Opportunity opportunity, CancellationToken cancellationToken = default)
    {
        _context.Set<Opportunity>().Update(opportunity);
        await Task.CompletedTask;
    }

    public async Task SaveChangesAsync(CancellationToken cancellationToken = default)
    {
        await _context.SaveChangesAsync(cancellationToken);
    }
}
