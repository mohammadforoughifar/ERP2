using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using ERP.Application.Interfaces;
using ERP.Domain.Entities.Workflow;
using ERP.Infrastructure.Data;

namespace ERP.Infrastructure.Repositories.Workflow;

public class WorkflowInstanceRepository : IWorkflowInstanceRepository
{
    private readonly ApplicationDbContext _context;

    public WorkflowInstanceRepository(ApplicationDbContext context)
    {
        _context = context ?? throw new ArgumentNullException(nameof(context));
    }

    public async Task<WorkflowInstance?> GetByIdAsync(int id, CancellationToken cancellationToken = default)
    {
        return await _context.Set<WorkflowInstance>()
            .AsNoTracking()
            .FirstOrDefaultAsync(wi => wi.Id == id, cancellationToken);
    }

    public async Task<WorkflowInstance?> GetByDocumentAsync(int documentId, string documentType, int companyId, CancellationToken cancellationToken = default)
    {
        return await _context.Set<WorkflowInstance>()
            .AsNoTracking()
            .FirstOrDefaultAsync(wi => wi.DocumentId == documentId && wi.DocumentType == documentType && wi.CompanyId == companyId && wi.IsActive, cancellationToken);
    }

    public async Task AddAsync(WorkflowInstance instance, CancellationToken cancellationToken = default)
    {
        await _context.Set<WorkflowInstance>().AddAsync(instance, cancellationToken);
    }

    public async Task UpdateAsync(WorkflowInstance instance, CancellationToken cancellationToken = default)
    {
        _context.Set<WorkflowInstance>().Update(instance);
        await Task.CompletedTask;
    }

    public async Task SaveChangesAsync(CancellationToken cancellationToken = default)
    {
        await _context.SaveChangesAsync(cancellationToken);
    }
}
