using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using ERP.Application.Interfaces;
using ERP.Domain.Entities.MRP;
using ERP.Infrastructure.Data;

namespace ERP.Infrastructure.Repositories.MRP;

public class MRPPlanRepository : IMRPPlanRepository
{
    private readonly ApplicationDbContext _context;

    public MRPPlanRepository(ApplicationDbContext context)
    {
        _context = context ?? throw new ArgumentNullException(nameof(context));
    }

    public async Task<MRPPlan?> GetByIdAsync(int id, CancellationToken cancellationToken = default)
    {
        return await _context.Set<MRPPlan>()
            .AsNoTracking()
            .FirstOrDefaultAsync(mp => mp.Id == id, cancellationToken);
    }

    public async Task<MRPPlan?> GetByPlanNumberAsync(string planNumber, int companyId, CancellationToken cancellationToken = default)
    {
        return await _context.Set<MRPPlan>()
            .AsNoTracking()
            .FirstOrDefaultAsync(mp => mp.PlanNumber == planNumber && mp.CompanyId == companyId && mp.IsActive, cancellationToken);
    }

    public async Task AddAsync(MRPPlan mrpPlan, CancellationToken cancellationToken = default)
    {
        await _context.Set<MRPPlan>().AddAsync(mrpPlan, cancellationToken);
    }

    public async Task UpdateAsync(MRPPlan mrpPlan, CancellationToken cancellationToken = default)
    {
        _context.Set<MRPPlan>().Update(mrpPlan);
        await Task.CompletedTask;
    }

    public async Task SaveChangesAsync(CancellationToken cancellationToken = default)
    {
        await _context.SaveChangesAsync(cancellationToken);
    }
}
