using System.Threading;
using System.Threading.Tasks;
using ERP.Domain.Entities.Production;

namespace ERP.Application.Interfaces;

public interface IProductionOrderRepository
{
    Task<ProductionOrder?> GetByIdAsync(int id, CancellationToken cancellationToken = default);
    Task<ProductionOrder?> GetByProductionNumberAsync(string productionNumber, int companyId, CancellationToken cancellationToken = default);
    Task AddAsync(ProductionOrder productionOrder, CancellationToken cancellationToken = default);
    Task UpdateAsync(ProductionOrder productionOrder, CancellationToken cancellationToken = default);
    Task SaveChangesAsync(CancellationToken cancellationToken = default);
}
