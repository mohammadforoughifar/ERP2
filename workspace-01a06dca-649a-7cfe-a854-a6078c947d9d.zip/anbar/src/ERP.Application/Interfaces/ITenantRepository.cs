using System.Threading;
using System.Threading.Tasks;
using ERP.Domain.Entities;

namespace ERP.Application.Interfaces;

/// <summary>
/// Repository interface for Clean Architecture — Phase 1 Core
/// Per proposal: Repository Pattern + Unit of Work
/// </summary>
public interface ITenantRepository
{
    Task<Tenant?> GetByIdAsync(int id, CancellationToken cancellationToken = default);
    Task AddAsync(Tenant tenant, CancellationToken cancellationToken = default);
    Task UpdateAsync(Tenant tenant, CancellationToken cancellationToken = default);
    Task SaveChangesAsync(CancellationToken cancellationToken = default);
}
