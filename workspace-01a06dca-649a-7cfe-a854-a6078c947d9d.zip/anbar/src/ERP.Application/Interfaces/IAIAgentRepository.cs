using ERP.Domain.Entities.AI;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ERP.Application.Interfaces;

public interface IAIAgentRepository
{
    Task<AIAgent?> GetByIdAsync(int id);
    Task<IEnumerable<AIAgent>> GetActiveAsync();
    Task AddAsync(AIAgent agent);
    Task UpdateAsync(AIAgent agent);
    Task DeleteAsync(AIAgent agent);
}
