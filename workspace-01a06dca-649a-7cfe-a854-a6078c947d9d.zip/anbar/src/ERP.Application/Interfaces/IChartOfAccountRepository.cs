using System.Threading;
using System.Threading.Tasks;
using ERP.Domain.Entities.Finance;

namespace ERP.Application.Interfaces;

public interface IChartOfAccountRepository
{
    Task<ChartOfAccount?> GetByIdAsync(int id, CancellationToken cancellationToken = default);
    Task<ChartOfAccount?> GetByCodeAsync(string code, int companyId, CancellationToken cancellationToken = default);
    Task AddAsync(ChartOfAccount account, CancellationToken cancellationToken = default);
    Task UpdateAsync(ChartOfAccount account, CancellationToken cancellationToken = default);
    Task SaveChangesAsync(CancellationToken cancellationToken = default);
}
