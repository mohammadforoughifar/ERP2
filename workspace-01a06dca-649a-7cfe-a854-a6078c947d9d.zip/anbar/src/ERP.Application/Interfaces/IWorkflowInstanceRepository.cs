using System.Threading;
using System.Threading.Tasks;
using ERP.Domain.Entities.Workflow;

namespace ERP.Application.Interfaces;

public interface IWorkflowInstanceRepository
{
    Task<WorkflowInstance?> GetByIdAsync(int id, CancellationToken cancellationToken = default);
    Task<WorkflowInstance?> GetByDocumentAsync(int documentId, string documentType, int companyId, CancellationToken cancellationToken = default);
    Task AddAsync(WorkflowInstance instance, CancellationToken cancellationToken = default);
    Task UpdateAsync(WorkflowInstance instance, CancellationToken cancellationToken = default);
    Task SaveChangesAsync(CancellationToken cancellationToken = default);
}
