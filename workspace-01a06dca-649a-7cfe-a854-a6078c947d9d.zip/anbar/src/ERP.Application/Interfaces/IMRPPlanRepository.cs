using System.Threading;
using System.Threading.Tasks;
using ERP.Domain.Entities.MRP;

namespace ERP.Application.Interfaces;

public interface IMRPPlanRepository
{
    Task<MRPPlan?> GetByIdAsync(int id, CancellationToken cancellationToken = default);
    Task<MRPPlan?> GetByPlanNumberAsync(string planNumber, int companyId, CancellationToken cancellationToken = default);
    Task AddAsync(MRPPlan mrpPlan, CancellationToken cancellationToken = default);
    Task UpdateAsync(MRPPlan mrpPlan, CancellationToken cancellationToken = default);
    Task SaveChangesAsync(CancellationToken cancellationToken = default);
}
