using System.Threading;
using System.Threading.Tasks;
using ERP.Domain.Entities.Inventory;

namespace ERP.Application.Interfaces;

public interface IInventoryTransactionRepository
{
    Task<InventoryTransaction?> GetByIdAsync(int id, CancellationToken cancellationToken = default);
    Task AddAsync(InventoryTransaction transaction, CancellationToken cancellationToken = default);
    Task UpdateAsync(InventoryTransaction transaction, CancellationToken cancellationToken = default);
    Task SaveChangesAsync(CancellationToken cancellationToken = default);
}
