using System.Threading;
using System.Threading.Tasks;
using ERP.Domain.Entities.Treasury;

namespace ERP.Application.Interfaces;

public interface ICheckRepository
{
    Task<Check?> GetByIdAsync(int id, CancellationToken cancellationToken = default);
    Task<Check?> GetByCheckNumberAsync(string checkNumber, int companyId, CancellationToken cancellationToken = default);
    Task AddAsync(Check check, CancellationToken cancellationToken = default);
    Task UpdateAsync(Check check, CancellationToken cancellationToken = default);
    Task SaveChangesAsync(CancellationToken cancellationToken = default);
}
