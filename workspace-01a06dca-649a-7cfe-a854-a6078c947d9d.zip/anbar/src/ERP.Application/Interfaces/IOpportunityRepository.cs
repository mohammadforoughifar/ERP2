using System.Threading;
using System.Threading.Tasks;
using ERP.Domain.Entities.CRM;

namespace ERP.Application.Interfaces;

public interface IOpportunityRepository
{
    Task<Opportunity?> GetByIdAsync(int id, CancellationToken cancellationToken = default);
    Task<Opportunity?> GetByTitleAsync(string title, int companyId, CancellationToken cancellationToken = default);
    Task AddAsync(Opportunity opportunity, CancellationToken cancellationToken = default);
    Task UpdateAsync(Opportunity opportunity, CancellationToken cancellationToken = default);
    Task SaveChangesAsync(CancellationToken cancellationToken = default);
}
