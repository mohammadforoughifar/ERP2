using ERP.Domain.Entities.FormBuilder;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ERP.Application.Interfaces;

public interface IDynamicFormRepository
{
    Task<DynamicForm?> GetByIdAsync(int id);
    Task<IEnumerable<DynamicForm>> GetAllAsync();
    Task<IEnumerable<DynamicForm>> GetActiveAsync();
    Task AddAsync(DynamicForm form);
    Task UpdateAsync(DynamicForm form);
    Task DeleteAsync(DynamicForm form);
}
