using MediatR;
using ERP.Contracts.Dtos.Core;

namespace ERP.Application.Commands.Core;

/// <summary>
/// CreateTenantCommand — Phase 1 Core
/// Per proposal: Clean Architecture + MediatR + FluentValidation
/// </summary>
public record CreateTenantCommand(
    string Name,
    string Code,
    string CreatedBy
) : IRequest<TenantDto>;
