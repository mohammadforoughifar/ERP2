using System;
using System.Threading;
using System.Threading.Tasks;
using MediatR;
using ERP.Domain.Entities;
using ERP.Application.Interfaces;
using ERP.Contracts.Dtos.Core;

namespace ERP.Application.Commands.Core;

public class CreateTenantCommandHandler : IRequestHandler<CreateTenantCommand, TenantDto>
{
    private readonly ITenantRepository _tenantRepo;

    public CreateTenantCommandHandler(ITenantRepository tenantRepo)
    {
        _tenantRepo = tenantRepo ?? throw new ArgumentNullException(nameof(tenantRepo));
    }

    public async Task<TenantDto> Handle(CreateTenantCommand request, CancellationToken cancellationToken)
    {
        var tenant = new Tenant(request.Name, request.Code, request.CreatedBy);
        await _tenantRepo.AddAsync(tenant, cancellationToken);
        await _tenantRepo.SaveChangesAsync(cancellationToken);

        return new TenantDto(
            tenant.Id,
            tenant.Name,
            tenant.Code,
            tenant.IsActive,
            tenant.CreatedAt,
            tenant.CreatedBy
        );
    }
}
