using System;

namespace ERP.Domain.Entities.MasterData;

/// <summary>
/// Customer — Master Data Phase 2
/// Per proposal: Customer 360 base, Multi-Branch access, Credit Management
/// </summary>
public class Customer
{
    public int Id { get; private set; }
    public int? CompanyId { get; private set; }
    public string Code { get; private set; } = string.Empty;         // Customer Number
    public string Name { get; private set; } = string.Empty;
    public string LegalName { get; private set; } = string.Empty;
    public string NationalId { get; private set; } = string.Empty;  // Iranian: کد ملی
    public string TaxNumber { get; private set; } = string.Empty;     // کد اقتصادی
    public string Phone { get; private set; } = string.Empty;
    public string Email { get; private set; } = string.Empty;
    public string Address { get; private set; } = string.Empty;
    public decimal CreditLimit { get; private set; }
    public bool IsActive { get; private set; } = true;
    public DateTime CreatedAt { get; private set; }
    public string CreatedBy { get; private set; } = string.Empty;

    private Customer() { }

    public Customer(int? companyId, string code, string name, string legalName, string nationalId, string taxNumber, string createdBy)
    {
        if (companyId == null || companyId <= 0) throw new ArgumentException("Company required", nameof(companyId));
        if (string.IsNullOrWhiteSpace(code)) throw new ArgumentException("Customer code required");
        if (string.IsNullOrWhiteSpace(name)) throw new ArgumentException("Customer name required");

        CompanyId = companyId;
        Code = code.Trim();
        Name = name.Trim();
        LegalName = legalName?.Trim() ?? name.Trim();
        NationalId = nationalId?.Trim() ?? string.Empty;
        TaxNumber = taxNumber?.Trim() ?? string.Empty;
        CreditLimit = 0;
        CreatedAt = DateTime.UtcNow;
        CreatedBy = createdBy;
        IsActive = true;
    }

    public void UpdateProfile(string name, string legalName, string phone, string email, string address)
    {
        Name = name.Trim();
        LegalName = legalName?.Trim() ?? name.Trim();
        Phone = phone?.Trim() ?? string.Empty;
        Email = email?.Trim() ?? string.Empty;
        Address = address?.Trim() ?? string.Empty;
    }

    public void UpdateCreditLimit(decimal limit)
    {
        if (limit < 0) throw new ArgumentException("Credit limit cannot be negative");
        CreditLimit = limit;
    }

    public void Deactivate() => IsActive = false;
    public void Activate() => IsActive = true;
}
