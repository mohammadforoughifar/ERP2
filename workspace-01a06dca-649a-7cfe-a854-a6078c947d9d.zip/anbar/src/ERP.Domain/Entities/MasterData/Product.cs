using System;

namespace ERP.Domain.Entities.MasterData;

/// <summary>
/// Product (Item) — Master Data Phase 2
/// Per proposal: SKU, Barcode, QR, Brand, Category, UOM Group, Batch, Serial, Expiry
/// </summary>
public class Product
{
    public int Id { get; private set; }
    public int? CompanyId { get; private set; }
    public string Code { get; private set; } = string.Empty;         // SKU / Internal Code
    public string Name { get; private set; } = string.Empty;
    public string Barcode { get; private set; } = string.Empty;
    public string Brand { get; private set; } = string.Empty;
    public string Category { get; private set; } = string.Empty;
    public string Unit { get; private set; } = string.Empty;         // UOM: kg, piece, box
    public string UnitGroup { get; private set; } = string.Empty;    // Unit Group: Weight, Length
    public bool IsBatchTracked { get; private set; } = false;
    public bool IsSerialTracked { get; private set; } = false;
    public bool HasExpiry { get; private set; } = false;
    public decimal Weight { get; private set; }
    public bool IsActive { get; private set; } = true;
    public DateTime CreatedAt { get; private set; }
    public string CreatedBy { get; private set; } = string.Empty;

    private Product() { }

    public Product(
        int? companyId,
        string code,
        string name,
        string barcode,
        string brand,
        string category,
        string unit,
        string unitGroup,
        bool isBatchTracked,
        bool isSerialTracked,
        bool hasExpiry,
        decimal weight,
        string createdBy)
    {
        if (companyId == null || companyId <= 0) throw new ArgumentException("Company required", nameof(companyId));
        if (string.IsNullOrWhiteSpace(code)) throw new ArgumentException("Product code required");
        if (string.IsNullOrWhiteSpace(name)) throw new ArgumentException("Product name required");
        if (string.IsNullOrWhiteSpace(unit)) throw new ArgumentException("Unit required");

        CompanyId = companyId;
        Code = code.Trim();
        Name = name.Trim();
        Barcode = barcode?.Trim() ?? string.Empty;
        Brand = brand?.Trim() ?? string.Empty;
        Category = category?.Trim() ?? string.Empty;
        Unit = unit.Trim();
        UnitGroup = unitGroup?.Trim() ?? string.Empty;
        IsBatchTracked = isBatchTracked;
        IsSerialTracked = isSerialTracked;
        HasExpiry = hasExpiry;
        Weight = weight >= 0 ? weight : 0;
        CreatedAt = DateTime.UtcNow;
        CreatedBy = createdBy;
        IsActive = true;
    }

    public void UpdateProfile(string name, string brand, string category, string unit, string unitGroup)
    {
        Name = name.Trim();
        Brand = brand?.Trim() ?? string.Empty;
        Category = category?.Trim() ?? string.Empty;
        Unit = unit?.Trim() ?? string.Empty;
        UnitGroup = unitGroup?.Trim() ?? string.Empty;
    }

    public void Deactivate() => IsActive = false;
    public void Activate() => IsActive = true;
}
