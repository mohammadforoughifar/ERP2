using System;

namespace ERP.Domain.Entities.MasterData;

/// <summary>
/// Supplier — Master Data Phase 2
/// Per proposal: Supplier Evaluation, Price Comparison, RFQ base
/// </summary>
public class Supplier
{
    public int Id { get; private set; }
    public int? CompanyId { get; private set; }
    public string Code { get; private set; } = string.Empty;
    public string Name { get; private set; } = string.Empty;
    public string LegalName { get; private set; } = string.Empty;
    public string NationalId { get; private set; } = string.Empty;
    public string TaxNumber { get; private set; } = string.Empty;
    public string Phone { get; private set; } = string.Empty;
    public string Email { get; private set; } = string.Empty;
    public string Address { get; private set; } = string.Empty;
    public bool IsActive { get; private set; } = true;
    public DateTime CreatedAt { get; private set; }
    public string CreatedBy { get; private set; } = string.Empty;

    private Supplier() { }

    public Supplier(int? companyId, string code, string name, string legalName, string nationalId, string taxNumber, string createdBy)
    {
        if (companyId == null || companyId <= 0) throw new ArgumentException("Company required", nameof(companyId));
        if (string.IsNullOrWhiteSpace(code)) throw new ArgumentException("Supplier code required");
        if (string.IsNullOrWhiteSpace(name)) throw new ArgumentException("Supplier name required");

        CompanyId = companyId;
        Code = code.Trim();
        Name = name.Trim();
        LegalName = legalName?.Trim() ?? name.Trim();
        NationalId = nationalId?.Trim() ?? string.Empty;
        TaxNumber = taxNumber?.Trim() ?? string.Empty;
        CreatedAt = DateTime.UtcNow;
        CreatedBy = createdBy;
        IsActive = true;
    }

    public void UpdateProfile(string name, string legalName, string phone, string email, string address)
    {
        Name = name.Trim();
        LegalName = legalName?.Trim() ?? name.Trim();
        Phone = phone?.Trim() ?? string.Empty;
        Email = email?.Trim() ?? string.Empty;
        Address = address?.Trim() ?? string.Empty;
    }

    public void Deactivate() => IsActive = false;
    public void Activate() => IsActive = true;
}
