using System;
using System.ComponentModel.DataAnnotations;

namespace ERP.Domain.Entities.Integration;

public class IntegrationMessage
{
    [Key]
    public int Id { get; set; }
    [StringLength(100)]
    public string Name { get; set; } = string.Empty;
    public int CompanyId { get; set; }
    public int BranchId { get; set; }
    public int TenantId { get; set; }
    [StringLength(100)]
    public string CreatedBy { get; set; } = string.Empty;
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public bool IsActive { get; set; } = true;
}
