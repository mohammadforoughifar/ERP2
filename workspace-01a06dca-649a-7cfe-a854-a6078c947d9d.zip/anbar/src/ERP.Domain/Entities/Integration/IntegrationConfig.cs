using System;
using System.ComponentModel.DataAnnotations;

namespace ERP.Domain.Entities.Integration;

public class IntegrationConfig
{
    [Key]
    public int Id { get; set; }

    [Required]
    [StringLength(200)]
    public string ConfigName { get; set; } = string.Empty;

    [StringLength(500)]
    public string? ServiceName { get; set; }

    [StringLength(500)]
    public string? ApiKey { get; set; }

    [StringLength(500)]
    public string? ApiSecret { get; set; }

    [StringLength(500)]
    public string? BaseUrl { get; set; }

    [StringLength(200)]
    public string IntegrationType { get; set; } = "External";

    [StringLength(50)]
    public string Status { get; set; } = "Active";

    public int CompanyId { get; set; }
    public int BranchId { get; set; }
    public int TenantId { get; set; }

    [StringLength(100)]
    public string CreatedBy { get; set; } = string.Empty;

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    [StringLength(100)]
    public string? ModifiedBy { get; set; }

    public DateTime? ModifiedAt { get; set; }

    public bool IsActive { get; set; } = true;
}
