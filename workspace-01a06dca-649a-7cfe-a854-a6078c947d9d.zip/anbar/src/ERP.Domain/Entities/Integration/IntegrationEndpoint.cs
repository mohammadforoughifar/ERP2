using System;
using System.ComponentModel.DataAnnotations;

namespace ERP.Domain.Entities.Integration;

public class IntegrationEndpoint
{
    [Key]
    public int Id { get; set; }

    [Required]
    [StringLength(200)]
    public string EndpointName { get; set; } = string.Empty;

    [StringLength(500)]
    public string? Url { get; set; }

    [StringLength(50)]
    public string Method { get; set; } = "GET"; // GET, POST, PUT, DELETE

    [StringLength(50)]
    public string EndpointType { get; set; } = "REST"; // REST, SOAP, Webhook, WebSocket

    [StringLength(2000)]
    public string? Headers { get; set; } // JSON headers

    [StringLength(2000)]
    public string? BodyTemplate { get; set; }

    [StringLength(100)]
    public string Status { get; set; } = "Active"; // Active, Disabled, Maintenance

    public int CompanyId { get; set; }
    public int BranchId { get; set; }
    public int TenantId { get; set; }

    [StringLength(100)]
    public string CreatedBy { get; set; } = string.Empty;

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    [StringLength(100)]
    public string? ModifiedBy { get; set; }

    public DateTime? ModifiedAt { get; set; }

    public bool IsActive { get; set; } = true;
}
