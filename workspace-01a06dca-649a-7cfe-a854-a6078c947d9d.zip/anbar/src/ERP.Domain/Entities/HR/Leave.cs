using System;

namespace ERP.Domain.Entities.HR;

/// <summary>
/// Leave — Phase 11 HR
/// Per proposal: Leave management (Annual, Sick, Unpaid, Mission, etc.)
/// </summary>
public enum LeaveType
{
    Annual = 1,
    Sick = 2,
    Unpaid = 3,
    Mission = 4,
    Study = 5,
    Maternity = 6,
    Paternity = 7,
    Emergency = 8
}

public class Leave
{
    public int Id { get; private set; }
    public int? CompanyId { get; private set; }
    public int EmployeeId { get; private set; }
    public LeaveType Type { get; private set; }
    public DateTime StartDate { get; private set; }
    public DateTime EndDate { get; private set; }
    public int Days { get; private set; }
    public string Reason { get; private set; } = string.Empty;
    public string Status { get; private set; } = "Pending";      // Pending, Approved, Rejected, Cancelled
    public bool IsActive { get; private set; } = true;
    public DateTime CreatedAt { get; private set; }
    public string CreatedBy { get; private set; } = string.Empty;

    private Leave() { }

    public Leave(
        int? companyId,
        int employeeId,
        LeaveType type,
        DateTime startDate,
        DateTime endDate,
        string reason,
        string createdBy)
    {
        if (companyId == null || companyId <= 0) throw new ArgumentException("Company required", nameof(companyId));
        if (employeeId <= 0) throw new ArgumentException("Employee required", nameof(employeeId));
        if (endDate < startDate) throw new ArgumentException("End date must be after start date");

        CompanyId = companyId;
        EmployeeId = employeeId;
        Type = type;
        StartDate = startDate;
        EndDate = endDate;
        Days = (endDate - startDate).Days + 1;
        Reason = reason?.Trim() ?? string.Empty;
        Status = "Pending";
        CreatedAt = DateTime.UtcNow;
        CreatedBy = createdBy;
        IsActive = true;
    }

    public void Approve() => Status = "Approved";
    public void Reject() => Status = "Rejected";
    public void Cancel() => Status = "Cancelled";
    public void Deactivate() => IsActive = false;
    public void Activate() => IsActive = true;
}
