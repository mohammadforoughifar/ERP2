using System;

namespace ERP.Domain.Entities.HR;

/// <summary>
/// Employee — Phase 11 HR
/// Per proposal: HR, Contract, Attendance, Leave, Overtime, Evaluation, Training
/// Per previous constraints: IsActive filter applies; save rules validated (FirstName + StaffNumber + CompanyId > 0)
/// </summary>
public class Employee
{
    public int Id { get; private set; }
    public int? CompanyId { get; private set; }
    public string FirstName { get; private set; } = string.Empty;
    public string LastName { get; private set; } = string.Empty;
    public string StaffNumber { get; private set; } = string.Empty;      // شماره پرسنلی
    public string NationalId { get; private set; } = string.Empty;        // کد ملی
    public string Phone { get; private set; } = string.Empty;
    public string Email { get; private set; } = string.Empty;
    public string Address { get; private set; } = string.Empty;
    public int? DepartmentId { get; private set; }
    public int? PositionId { get; private set; }
    public DateTime HireDate { get; private set; }
    public DateTime? TerminationDate { get; private set; }
    public bool IsActive { get; private set; } = true;
    public DateTime CreatedAt { get; private set; }
    public string CreatedBy { get; private set; } = string.Empty;

    private Employee() { }

    public Employee(
        int? companyId,
        string firstName,
        string lastName,
        string staffNumber,
        string nationalId,
        string phone,
        string email,
        string address,
        int? departmentId,
        int? positionId,
        DateTime hireDate,
        string createdBy)
    {
        if (companyId == null || companyId <= 0) throw new ArgumentException("CompanyId > 0 required");
        if (string.IsNullOrWhiteSpace(firstName)) throw new ArgumentException("FirstName required");
        if (string.IsNullOrWhiteSpace(staffNumber)) throw new ArgumentException("StaffNumber required");

        CompanyId = companyId;
        FirstName = firstName.Trim();
        LastName = lastName?.Trim() ?? string.Empty;
        StaffNumber = staffNumber.Trim();
        NationalId = nationalId?.Trim() ?? string.Empty;
        Phone = phone?.Trim() ?? string.Empty;
        Email = email?.Trim() ?? string.Empty;
        Address = address?.Trim() ?? string.Empty;
        DepartmentId = departmentId;
        PositionId = positionId;
        HireDate = hireDate;
        TerminationDate = null;
        CreatedAt = DateTime.UtcNow;
        CreatedBy = createdBy;
        IsActive = true;
    }

    public void UpdateProfile(string firstName, string lastName, string phone, string email, string address)
    {
        FirstName = firstName.Trim();
        LastName = lastName?.Trim() ?? string.Empty;
        Phone = phone?.Trim() ?? string.Empty;
        Email = email?.Trim() ?? string.Empty;
        Address = address?.Trim() ?? string.Empty;
    }

    public void Terminate(DateTime terminationDate) => TerminationDate = terminationDate;
    public void Deactivate() => IsActive = false;
    public void Activate() => IsActive = true;
}
