using System;

namespace ERP.Domain.Entities.HR;

/// <summary>
/// Attendance — Phase 11 HR
/// Per proposal: Attendance tracking for payroll calculation
/// </summary>
public enum AttendanceStatus
{
    Present = 1,
    Absent = 2,
    Late = 3,
    Leave = 4,
    Mission = 5,
    Overtime = 6
}

public class Attendance
{
    public int Id { get; private set; }
    public int? CompanyId { get; private set; }
    public int EmployeeId { get; private set; }
    public DateTime Date { get; private set; }
    public AttendanceStatus Status { get; private set; }
    public int? HoursWorked { get; private set; }
    public int? OvertimeHours { get; private set; }
    public bool IsActive { get; private set; } = true;
    public DateTime CreatedAt { get; private set; }
    public string CreatedBy { get; private set; } = string.Empty;

    private Attendance() { }

    public Attendance(
        int? companyId,
        int employeeId,
        DateTime date,
        AttendanceStatus status,
        int? hoursWorked = null,
        int? overtimeHours = null,
        string createdBy = "")
    {
        if (companyId == null || companyId <= 0) throw new ArgumentException("Company required", nameof(companyId));
        if (employeeId <= 0) throw new ArgumentException("Employee required", nameof(employeeId));

        CompanyId = companyId;
        EmployeeId = employeeId;
        Date = date.Date;
        Status = status;
        HoursWorked = hoursWorked;
        OvertimeHours = overtimeHours;
        CreatedAt = DateTime.UtcNow;
        CreatedBy = createdBy ?? "system";
        IsActive = true;
    }

    public void UpdateStatus(AttendanceStatus status, int? hoursWorked, int? overtimeHours)
    {
        Status = status;
        HoursWorked = hoursWorked;
        OvertimeHours = overtimeHours;
    }

    public void Deactivate() => IsActive = false;
    public void Activate() => IsActive = true;
}
