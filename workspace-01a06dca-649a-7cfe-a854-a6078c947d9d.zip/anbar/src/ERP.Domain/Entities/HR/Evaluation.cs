using System;
using System.ComponentModel.DataAnnotations;

namespace ERP.Domain.Entities.HR;

public class Evaluation
{
    [Key]
    public int Id { get; set; }

    [Required]
    public int EmployeeId { get; set; }

    [StringLength(200)]
    public string Title { get; set; } = string.Empty;

    public int Score { get; set; } = 0; // 0-100

    [StringLength(2000)]
    public string Comments { get; set; } = string.Empty;

    public DateTime EvaluationDate { get; set; } = DateTime.UtcNow;

    [StringLength(50)]
    public string Status { get; set; } = "Draft"; // Draft, Completed, Approved, Cancelled

    public int CompanyId { get; set; }
    public int BranchId { get; set; }
    public int TenantId { get; set; }

    [StringLength(100)]
    public string CreatedBy { get; set; } = string.Empty;

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    [StringLength(100)]
    public string? ModifiedBy { get; set; }

    public DateTime? ModifiedAt { get; set; }

    public bool IsActive { get; set; } = true;
}
