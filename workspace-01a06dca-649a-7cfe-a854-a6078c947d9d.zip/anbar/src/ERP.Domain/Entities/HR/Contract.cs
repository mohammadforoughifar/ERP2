using System;

namespace ERP.Domain.Entities.HR;

/// <summary>
/// Employee Contract — Phase 11 HR
/// Per proposal: Contract types (Permanent, Temporary, Part-time, Contract), Start/End dates, Renewal
/// </summary>
public enum ContractType
{
    Permanent = 1,
    Temporary = 2,
    PartTime = 3,
    Contract = 4,
    ProjectBased = 5
}

public class Contract
{
    public int Id { get; private set; }
    public int? CompanyId { get; private set; }
    public int EmployeeId { get; private set; }
    public ContractType Type { get; private set; }
    public string ContractNumber { get; private set; } = string.Empty;
    public DateTime StartDate { get; private set; }
    public DateTime? EndDate { get; private set; }
    public DateTime? RenewalDate { get; private set; }
    public decimal BaseSalary { get; private set; }            // حقوق پایه
    public bool IsActive { get; private set; } = true;
    public DateTime CreatedAt { get; private set; }
    public string CreatedBy { get; private set; } = string.Empty;

    private Contract() { }

    public Contract(
        int? companyId,
        int employeeId,
        ContractType type,
        string contractNumber,
        DateTime startDate,
        DateTime? endDate,
        DateTime? renewalDate,
        decimal baseSalary,
        string createdBy)
    {
        if (companyId == null || companyId <= 0) throw new ArgumentException("Company required", nameof(companyId));
        if (employeeId <= 0) throw new ArgumentException("Employee required", nameof(employeeId));
        if (string.IsNullOrWhiteSpace(contractNumber)) throw new ArgumentException("Contract number required");
        if (baseSalary < 0) throw new ArgumentException("Base salary must be non-negative");

        CompanyId = companyId;
        EmployeeId = employeeId;
        Type = type;
        ContractNumber = contractNumber.Trim();
        StartDate = startDate;
        EndDate = endDate;
        RenewalDate = renewalDate;
        BaseSalary = baseSalary;
        CreatedAt = DateTime.UtcNow;
        CreatedBy = createdBy;
        IsActive = true;
    }

    public void UpdateBaseSalary(decimal newSalary)
    {
        if (newSalary < 0) throw new ArgumentException("Base salary must be non-negative");
        BaseSalary = newSalary;
    }

    public void Renew(DateTime renewalDate) => RenewalDate = renewalDate;
    public void Deactivate() => IsActive = false;
    public void Activate() => IsActive = true;
}
