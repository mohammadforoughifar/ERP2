using System;
using System.ComponentModel.DataAnnotations;

namespace ERP.Domain.Entities.HR;

public class Overtime
{
    [Key]
    public int Id { get; set; }

    [Required]
    public int EmployeeId { get; set; }

    public DateTime WorkDate { get; set; } = DateTime.UtcNow;

    public decimal Hours { get; set; } = 0;

    [StringLength(50)]
    public string Status { get; set; } = "Pending"; // Pending, Approved, Paid, Rejected

    public int CompanyId { get; set; }
    public int BranchId { get; set; }
    public int TenantId { get; set; }

    [StringLength(100)]
    public string CreatedBy { get; set; } = string.Empty;

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    [StringLength(100)]
    public string? ModifiedBy { get; set; }

    public DateTime? ModifiedAt { get; set; }

    public bool IsActive { get; set; } = true;
}
