using System;
using System.ComponentModel.DataAnnotations;

namespace ERP.Domain.Entities.HR;

public class Mission
{
    [Key]
    public int Id { get; set; }

    [Required]
    public int EmployeeId { get; set; }

    [StringLength(500)]
    public string Destination { get; set; } = string.Empty;

    public DateTime StartDate { get; set; } = DateTime.UtcNow;
    public DateTime EndDate { get; set; } = DateTime.UtcNow.AddDays(1);

    [StringLength(2000)]
    public string Purpose { get; set; } = string.Empty;

    [StringLength(50)]
    public string Status { get; set; } = "Pending"; // Pending, Approved, Completed, Cancelled

    public int CompanyId { get; set; }
    public int BranchId { get; set; }
    public int TenantId { get; set; }

    [StringLength(100)]
    public string CreatedBy { get; set; } = string.Empty;

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    [StringLength(100)]
    public string? ModifiedBy { get; set; }

    public DateTime? ModifiedAt { get; set; }

    public bool IsActive { get; set; } = true;
}
