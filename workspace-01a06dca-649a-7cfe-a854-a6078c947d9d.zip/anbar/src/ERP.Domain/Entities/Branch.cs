using System;

namespace ERP.Domain.Entities;

/// <summary>
/// Branch — Multi-Branch per proposal
/// </summary>
public class Branch
{
    public int Id { get; private set; }
    public int CompanyId { get; private set; }
    public string Name { get; private set; } = string.Empty;
    public string Code { get; private set; } = string.Empty;
    public bool IsActive { get; private set; } = true;
    public DateTime CreatedAt { get; private set; }
    public string CreatedBy { get; private set; } = string.Empty;

    public Company? Company { get; private set; }

    private Branch() { }

    public Branch(int companyId, string name, string code, string createdBy)
    {
        if (companyId <= 0) throw new ArgumentException("Company required", nameof(companyId));
        if (string.IsNullOrWhiteSpace(name)) throw new ArgumentException("Branch name required");

        CompanyId = companyId;
        Name = name.Trim();
        Code = code?.Trim() ?? string.Empty;
        CreatedAt = DateTime.UtcNow;
        CreatedBy = createdBy;
        IsActive = true;
    }
}
