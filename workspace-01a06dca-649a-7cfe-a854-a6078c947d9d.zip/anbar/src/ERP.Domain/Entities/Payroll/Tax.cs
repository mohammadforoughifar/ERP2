using System;
using System.ComponentModel.DataAnnotations;

namespace ERP.Domain.Entities.Payroll;

public class Tax
{
    [Key]
    public int Id { get; set; }

    [StringLength(200)]
    public string TaxName { get; set; } = string.Empty;

    public decimal Rate { get; set; } = 0; // Percentage rate

    [StringLength(500)]
    public string? Description { get; set; }

    [StringLength(50)]
    public string TaxType { get; set; } = "IncomeTax"; // IncomeTax, VAT, InsuranceTax, etc.

    public bool IsConfigurable { get; set; } = true;

    public int CompanyId { get; set; }
    public int BranchId { get; set; }
    public int TenantId { get; set; }

    [StringLength(100)]
    public string CreatedBy { get; set; } = string.Empty;

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    [StringLength(100)]
    public string? ModifiedBy { get; set; }

    public DateTime? ModifiedAt { get; set; }

    public bool IsActive { get; set; } = true;
}
