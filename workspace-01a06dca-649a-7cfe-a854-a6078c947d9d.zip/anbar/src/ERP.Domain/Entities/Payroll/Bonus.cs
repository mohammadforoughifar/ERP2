using System;
using System.ComponentModel.DataAnnotations;

namespace ERP.Domain.Entities.Payroll;

public class Bonus
{
    [Key]
    public int Id { get; set; }

    [Required]
    public int EmployeeId { get; set; }

    [StringLength(200)]
    public string BonusName { get; set; } = string.Empty;

    public decimal Amount { get; set; } = 0;

    public DateTime BonusDate { get; set; } = DateTime.UtcNow;

    [StringLength(500)]
    public string? Reason { get; set; }

    [StringLength(50)]
    public string Status { get; set; } = "Pending"; // Pending, Approved, Paid, Cancelled

    public int CompanyId { get; set; }
    public int BranchId { get; set; }
    public int TenantId { get; set; }

    [StringLength(100)]
    public string CreatedBy { get; set; } = string.Empty;

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    [StringLength(100)]
    public string? ModifiedBy { get; set; }

    public DateTime? ModifiedAt { get; set; }

    public bool IsActive { get; set; } = true;
}
