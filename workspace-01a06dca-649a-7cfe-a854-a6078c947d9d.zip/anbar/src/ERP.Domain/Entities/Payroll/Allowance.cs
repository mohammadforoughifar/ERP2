using System;
using System.ComponentModel.DataAnnotations;

namespace ERP.Domain.Entities.Payroll;

public class Allowance
{
    [Key]
    public int Id { get; set; }

    [StringLength(200)]
    public string Name { get; set; } = string.Empty;

    public decimal Amount { get; set; } = 0;

    [StringLength(20)]
    public string Type { get; set; } = "Fixed"; // Fixed, Percentage

    public bool IsTaxable { get; set; } = true;

    public int CompanyId { get; set; }
    public int BranchId { get; set; }
    public int TenantId { get; set; }

    [StringLength(100)]
    public string CreatedBy { get; set; } = string.Empty;

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    [StringLength(100)]
    public string? ModifiedBy { get; set; }

    public DateTime? ModifiedAt { get; set; }

    public bool IsActive { get; set; } = true;
}
