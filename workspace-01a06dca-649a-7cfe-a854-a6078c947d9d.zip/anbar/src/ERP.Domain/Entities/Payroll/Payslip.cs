using System;

namespace ERP.Domain.Entities.Payroll;

/// <summary>
/// Payslip — Phase 11 Payroll
/// Per proposal: Payslip generation (Salary, Allowance, Deduction, Bonus, Tax, Insurance, Net Pay)
/// Configurable for Iranian Payroll (حقوق و دستمزد ایران)
/// </summary>
public class Payslip
{
    public int Id { get; private set; }
    public int PayrollRunId { get; private set; }
    public int EmployeeId { get; private set; }
    public int ContractId { get; private set; }
    public decimal BaseSalary { get; private set; }
    public decimal Allowances { get; private set; }
    public decimal Deductions { get; private set; }
    public decimal Bonus { get; private set; }
    public decimal Tax { get; private set; }
    public decimal Insurance { get; private set; }
    public decimal NetPay { get; private set; }
    public string Status { get; private set; } = "Draft";       // Draft, Confirmed, Paid, Cancelled
    public bool IsActive { get; private set; } = true;
    public DateTime CreatedAt { get; private set; }
    public string CreatedBy { get; private set; } = string.Empty;

    private Payslip() { }

    public Payslip(
        int payrollRunId,
        int employeeId,
        int contractId,
        decimal baseSalary,
        decimal allowances,
        decimal deductions,
        decimal bonus,
        decimal tax,
        decimal insurance,
        string createdBy)
    {
        if (payrollRunId <= 0) throw new ArgumentException("Payroll run required", nameof(payrollRunId));
        if (employeeId <= 0) throw new ArgumentException("Employee required", nameof(employeeId));
        if (contractId <= 0) throw new ArgumentException("Contract required", nameof(contractId));
        if (baseSalary < 0 || allowances < 0 || deductions < 0 || bonus < 0 || tax < 0 || insurance < 0)
            throw new ArgumentException("All monetary values must be non-negative");

        PayrollRunId = payrollRunId;
        EmployeeId = employeeId;
        ContractId = contractId;
        BaseSalary = baseSalary;
        Allowances = allowances;
        Deductions = deductions;
        Bonus = bonus;
        Tax = tax;
        Insurance = insurance;
        NetPay = baseSalary + allowances + bonus - deductions - tax - insurance;
        Status = "Draft";
        CreatedAt = DateTime.UtcNow;
        CreatedBy = createdBy;
        IsActive = true;
    }

    public void Confirm() => Status = "Confirmed";
    public void Pay() => Status = "Paid";
    public void Cancel() => Status = "Cancelled";
    public void Deactivate() => IsActive = false;
    public void Activate() => IsActive = true;
}
