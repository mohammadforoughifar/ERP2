using System;

namespace ERP.Domain.Entities.Payroll;

/// <summary>
/// Salary Component — Phase 11 Payroll
/// Per proposal: Salary, Allowance, Deduction, Bonus, Loan, Advance, Insurance, Tax
/// Configurable rules for Iranian Payroll
/// </summary>
public enum SalaryComponentType
{
    BaseSalary = 1,
    Allowance = 2,
    Deduction = 3,
    Bonus = 4,
    Loan = 5,
    Advance = 6,
    Insurance = 7,
    Tax = 8,
    Overtime = 9
}

public class SalaryComponent
{
    public int Id { get; private set; }
    public int? CompanyId { get; private set; }
    public string ComponentName { get; private set; } = string.Empty;
    public SalaryComponentType Type { get; private set; }
    public decimal DefaultAmount { get; private set; }
    public bool IsFixed { get; private set; } = false;          // Fixed amount or percentage-based
    public decimal Percentage { get; private set; }              // Percentage rate (e.g., 9% for VAT, 7% for Insurance)
    public bool IsTaxable { get; private set; } = true;
    public bool IsActive { get; private set; } = true;
    public DateTime CreatedAt { get; private set; }
    public string CreatedBy { get; private set; } = string.Empty;

    private SalaryComponent() { }

    public SalaryComponent(
        int? companyId,
        string componentName,
        SalaryComponentType type,
        decimal defaultAmount,
        bool isFixed,
        decimal percentage,
        bool isTaxable,
        string createdBy)
    {
        if (string.IsNullOrWhiteSpace(componentName)) throw new ArgumentException("Component name required");
        if (defaultAmount < 0) throw new ArgumentException("Default amount must be non-negative");
        if (percentage < 0) throw new ArgumentException("Percentage must be non-negative");

        CompanyId = companyId;
        ComponentName = componentName.Trim();
        Type = type;
        DefaultAmount = defaultAmount;
        IsFixed = isFixed;
        Percentage = percentage;
        IsTaxable = isTaxable;
        CreatedAt = DateTime.UtcNow;
        CreatedBy = createdBy;
        IsActive = true;
    }

    public void Deactivate() => IsActive = false;
    public void Activate() => IsActive = true;
}
