using System;

namespace ERP.Domain.Entities.Payroll;

/// <summary>
/// Payroll Run — Phase 11 Payroll
/// Per proposal: Payroll execution for a period, generating payslips for employees
/// Configurable for Iranian Payroll rules
/// </summary>
public class PayrollRun
{
    public int Id { get; private set; }
    public int? CompanyId { get; private set; }
    public string PayrollNumber { get; private set; } = string.Empty;
    public DateTime PeriodStart { get; private set; }
    public DateTime PeriodEnd { get; private set; }
    public DateTime RunDate { get; private set; }
    public string Status { get; private set; } = "Draft";      // Draft, Generated, Confirmed, Paid, Cancelled
    public bool IsActive { get; private set; } = true;
    public DateTime CreatedAt { get; private set; }
    public string CreatedBy { get; private set; } = string.Empty;

    private PayrollRun() { }

    public PayrollRun(
        int? companyId,
        string payrollNumber,
        DateTime periodStart,
        DateTime periodEnd,
        DateTime runDate,
        string createdBy)
    {
        if (companyId == null || companyId <= 0) throw new ArgumentException("Company required", nameof(companyId));
        if (string.IsNullOrWhiteSpace(payrollNumber)) throw new ArgumentException("Payroll number required");
        if (periodEnd < periodStart) throw new ArgumentException("Period end must be after period start");

        CompanyId = companyId;
        PayrollNumber = payrollNumber.Trim();
        PeriodStart = periodStart;
        PeriodEnd = periodEnd;
        RunDate = runDate;
        Status = "Draft";
        CreatedAt = DateTime.UtcNow;
        CreatedBy = createdBy;
        IsActive = true;
    }

    public void Generate() => Status = "Generated";
    public void Confirm() => Status = "Confirmed";
    public void Pay() => Status = "Paid";
    public void Cancel() => Status = "Cancelled";
    public void Deactivate() => IsActive = false;
    public void Activate() => IsActive = true;
}
