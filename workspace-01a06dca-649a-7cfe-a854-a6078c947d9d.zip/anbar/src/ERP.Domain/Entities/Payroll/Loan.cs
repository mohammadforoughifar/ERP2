using System;
using System.ComponentModel.DataAnnotations;

namespace ERP.Domain.Entities.Payroll;

public class Loan
{
    [Key]
    public int Id { get; set; }

    [Required]
    public int EmployeeId { get; set; }

    public decimal LoanAmount { get; set; } = 0;

    public decimal RepaymentAmount { get; set; } = 0;

    public int RepaymentMonths { get; set; } = 0;

    [StringLength(20)]
    public string Status { get; set; } = "Active"; // Active, Completed, Defaulted, Cancelled

    public DateTime StartDate { get; set; } = DateTime.UtcNow;

    public int CompanyId { get; set; }
    public int BranchId { get; set; }
    public int TenantId { get; set; }

    [StringLength(100)]
    public string CreatedBy { get; set; } = string.Empty;

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    [StringLength(100)]
    public string? ModifiedBy { get; set; }

    public DateTime? ModifiedAt { get; set; }

    public bool IsActive { get; set; } = true;
}
