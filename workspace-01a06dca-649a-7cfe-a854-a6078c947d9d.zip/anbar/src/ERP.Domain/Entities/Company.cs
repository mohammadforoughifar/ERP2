using System;

namespace ERP.Domain.Entities;

/// <summary>
/// Company — Multi-Company support per proposal (Phase 1 Core)
/// Each Tenant can have multiple Companies
/// </summary>
public class Company
{
    public int Id { get; private set; }
    public int TenantId { get; private set; }
    public string Name { get; private set; } = string.Empty;
    public string RegistrationNumber { get; private set; } = string.Empty;
    public string TaxNumber { get; private set; } = string.Empty;
    public bool IsActive { get; private set; } = true;
    public DateTime CreatedAt { get; private set; }
    public string CreatedBy { get; private set; } = string.Empty;
    public DateTime? ModifiedAt { get; private set; }
    public string? ModifiedBy { get; private set; }

    public Tenant? Tenant { get; private set; }

    private Company() { }

    public Company(int tenantId, string name, string registrationNumber, string taxNumber, string createdBy)
    {
        if (tenantId <= 0) throw new ArgumentException("Tenant required", nameof(tenantId));
        if (string.IsNullOrWhiteSpace(name)) throw new ArgumentException("Company name required", nameof(name));

        TenantId = tenantId;
        Name = name.Trim();
        RegistrationNumber = registrationNumber?.Trim() ?? string.Empty;
        TaxNumber = taxNumber?.Trim() ?? string.Empty;
        CreatedAt = DateTime.UtcNow;
        CreatedBy = createdBy;
        IsActive = true;
    }

    public void Update(string name, string registrationNumber, string taxNumber)
    {
        Name = name.Trim();
        RegistrationNumber = registrationNumber?.Trim() ?? string.Empty;
        TaxNumber = taxNumber?.Trim() ?? string.Empty;
        ModifiedAt = DateTime.UtcNow;
    }
}
