using System;
using System.Collections.Generic;

namespace ERP.Domain.Entities;

/// <summary>
/// User — System User per proposal Phase 1
/// Note: Per previous constraints, IsActive filter applies; save rules validated.
/// </summary>
public class User
{
    public int Id { get; private set; }
    public int? CompanyId { get; private set; } // Multi-Company access
    public string Username { get; private set; } = string.Empty;
    public string Email { get; private set; } = string.Empty;
    public string FirstName { get; private set; } = string.Empty;
    public string LastName { get; private set; } = string.Empty;
    public string StaffNumber { get; private set; } = string.Empty;
    public bool IsActive { get; private set; } = true;
    public DateTime CreatedAt { get; private set; }
    public string CreatedBy { get; private set; } = string.Empty;

    private readonly List<UserRole> _roles = new();
    public IReadOnlyCollection<UserRole> Roles => _roles.AsReadOnly();

    private User() { }

    public User(int? companyId, string username, string email, string firstName, string lastName, string staffNumber, string createdBy)
    {
        if (companyId == null || companyId <= 0) throw new ArgumentException("CompanyId > 0 required");
        if (string.IsNullOrWhiteSpace(username)) throw new ArgumentException("Username required", nameof(username));
        if (string.IsNullOrWhiteSpace(firstName)) throw new ArgumentException("FirstName required", nameof(firstName));
        if (string.IsNullOrWhiteSpace(staffNumber)) throw new ArgumentException("StaffNumber required", nameof(staffNumber));

        CompanyId = companyId;
        Username = username.Trim();
        Email = email?.Trim() ?? string.Empty;
        FirstName = firstName.Trim();
        LastName = lastName?.Trim() ?? string.Empty;
        StaffNumber = staffNumber.Trim();
        CreatedAt = DateTime.UtcNow;
        CreatedBy = createdBy;
        IsActive = true;
    }

    public void UpdateProfile(string firstName, string lastName, string email)
    {
        FirstName = firstName.Trim();
        LastName = lastName?.Trim() ?? string.Empty;
        Email = email?.Trim() ?? string.Empty;
    }

    public void Deactivate() => IsActive = false;
    public void Activate() => IsActive = true;
}
