using System;

namespace ERP.Domain.Entities.Inventory;

/// <summary>
/// Inventory Status — Phase 7 Inventory
/// Per proposal: Inventory Status tracking (Available, Reserved, Damaged, Expired, Quarantine, etc.)
/// </summary>
public enum InventoryStatusValue
{
    Available = 1,
    Reserved = 2,
    Damaged = 3,
    Expired = 4,
    Quarantine = 5,
    InTransit = 6,
    Returned = 7
}

public class InventoryStatus
{
    public int Id { get; private set; }
    public int? CompanyId { get; private set; }
    public int ProductId { get; private set; }
    public int? BatchId { get; private set; }
    public int? SerialId { get; private set; }
    public int WarehouseId { get; private set; }
    public InventoryStatusValue Status { get; private set; }
    public int Quantity { get; private set; }
    public bool IsActive { get; private set; } = true;
    public DateTime CreatedAt { get; private set; }
    public string CreatedBy { get; private set; } = string.Empty;

    private InventoryStatus() { }

    public InventoryStatus(
        int? companyId,
        int productId,
        int? batchId,
        int? serialId,
        int warehouseId,
        InventoryStatusValue status,
        int quantity,
        string createdBy)
    {
        if (companyId == null || companyId <= 0) throw new ArgumentException("Company required", nameof(companyId));
        if (productId <= 0) throw new ArgumentException("Product required", nameof(productId));
        if (warehouseId <= 0) throw new ArgumentException("Warehouse required", nameof(warehouseId));
        if (quantity < 0) throw new ArgumentException("Quantity cannot be negative");

        CompanyId = companyId;
        ProductId = productId;
        BatchId = batchId;
        SerialId = serialId;
        WarehouseId = warehouseId;
        Status = status;
        Quantity = quantity;
        CreatedAt = DateTime.UtcNow;
        CreatedBy = createdBy;
        IsActive = true;
    }

    public void UpdateStatus(InventoryStatusValue newStatus, int newQuantity)
    {
        Status = newStatus;
        if (newQuantity >= 0) Quantity = newQuantity;
    }

    public void Deactivate() => IsActive = false;
    public void Activate() => IsActive = true;
}
