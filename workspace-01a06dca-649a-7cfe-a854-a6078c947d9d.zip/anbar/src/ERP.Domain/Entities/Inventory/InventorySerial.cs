using System;

namespace ERP.Domain.Entities.Inventory;

/// <summary>
/// Inventory Serial — Phase 7 Inventory
/// Per proposal: Serial Tracking, Warranty, Traceability from Purchase to Customer
/// </summary>
public class InventorySerial
{
    public int Id { get; private set; }
    public int? CompanyId { get; private set; }
    public int ProductId { get; private set; }
    public string SerialNumber { get; private set; } = string.Empty;         // شماره سریال
    public DateTime ProductionDate { get; private set; }
    public DateTime ExpirationDate { get; private set; }
    public DateTime? WarrantyExpiry { get; private set; }
    public int WarehouseId { get; private set; }
    public int? BatchId { get; private set; }
    public int? CustomerId { get; private set; }                             // اگر فروخته شده
    public bool IsActive { get; private set; } = true;
    public DateTime CreatedAt { get; private set; }
    public string CreatedBy { get; private set; } = string.Empty;

    private InventorySerial() { }

    public InventorySerial(
        int? companyId,
        int productId,
        string serialNumber,
        DateTime productionDate,
        DateTime expirationDate,
        DateTime? warrantyExpiry,
        int warehouseId,
        int? batchId,
        int? customerId,
        string createdBy)
    {
        if (companyId == null || companyId <= 0) throw new ArgumentException("Company required", nameof(companyId));
        if (productId <= 0) throw new ArgumentException("Product required", nameof(productId));
        if (string.IsNullOrWhiteSpace(serialNumber)) throw new ArgumentException("Serial number required");
        if (warehouseId <= 0) throw new ArgumentException("Warehouse required", nameof(warehouseId));

        CompanyId = companyId;
        ProductId = productId;
        SerialNumber = serialNumber.Trim();
        ProductionDate = productionDate;
        ExpirationDate = expirationDate;
        WarrantyExpiry = warrantyExpiry;
        WarehouseId = warehouseId;
        BatchId = batchId;
        CustomerId = customerId; // Initially null, set when sold
        CreatedAt = DateTime.UtcNow;
        CreatedBy = createdBy;
        IsActive = true;
    }

    public void AssignToCustomer(int customerId)
    {
        CustomerId = customerId;
    }

    public void Deactivate() => IsActive = false;
    public void Activate() => IsActive = true;
}
