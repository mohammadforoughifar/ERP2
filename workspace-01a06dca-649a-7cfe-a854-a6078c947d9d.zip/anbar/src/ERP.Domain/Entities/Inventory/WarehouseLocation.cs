using System;

namespace ERP.Domain.Entities.Inventory;

/// <summary>
/// Warehouse Location — Phase 7 Inventory
/// Per proposal: Bin, Zone, Rack, Shelf tracking
/// </summary>
public class WarehouseLocation
{
    public int Id { get; private set; }
    public int WarehouseId { get; private set; }
    public string Zone { get; private set; } = string.Empty;       // Zone
    public string Rack { get; private set; } = string.Empty;       // Rack
    public string Shelf { get; private set; } = string.Empty;     // Shelf
    public string Bin { get; private set; } = string.Empty;       // Bin
    public int Capacity { get; private set; }                     // Capacity in units
    public bool IsActive { get; private set; } = true;
    public DateTime CreatedAt { get; private set; }
    public string CreatedBy { get; private set; } = string.Empty;

    private WarehouseLocation() { }

    public WarehouseLocation(
        int warehouseId,
        string zone,
        string rack,
        string shelf,
        string bin,
        int capacity,
        string createdBy)
    {
        if (warehouseId <= 0) throw new ArgumentException("Warehouse required", nameof(warehouseId));
        if (capacity < 0) throw new ArgumentException("Capacity cannot be negative");

        WarehouseId = warehouseId;
        Zone = zone?.Trim() ?? string.Empty;
        Rack = rack?.Trim() ?? string.Empty;
        Shelf = shelf?.Trim() ?? string.Empty;
        Bin = bin?.Trim() ?? string.Empty;
        Capacity = capacity;
        CreatedAt = DateTime.UtcNow;
        CreatedBy = createdBy;
        IsActive = true;
    }

    public void UpdateCapacity(int newCapacity)
    {
        if (newCapacity < 0) throw new ArgumentException("Capacity cannot be negative");
        Capacity = newCapacity;
    }

    public void Deactivate() => IsActive = false;
    public void Activate() => IsActive = true;
}
