using System;

namespace ERP.Domain.Entities.Inventory;

/// <summary>
/// Inventory Transaction Type — Phase 7 Inventory
/// Per proposal: All inventory changes must come from transactions (no direct modification)
/// Types: Receipt, Issue, Transfer, Adjustment, Count, ProductionIssue, ProductionReceipt, SalesDelivery, PurchaseReceipt, Return
/// </summary>
public enum InventoryTransactionType
{
    Receipt = 1,              // ورود موجودی (خرید / تولید)
    Issue = 2,                // خروج موجودی (مصرف / فروش)
    Transfer = 3,             // انتقال بین انبارها
    Adjustment = 4,           // تعدیل موجودی
    Count = 5,                // شمارش فیزیکی
    ProductionIssue = 6,      // مصرف مواد اولیه در تولید
    ProductionReceipt = 7,    // دریافت محصول تولید شده
    SalesDelivery = 8,        // تحویل فروش
    PurchaseReceipt = 9,      // دریافت خرید
    Return = 10               // برگشت کالا
}

/// <summary>
/// Inventory Transaction — Phase 7 Inventory
/// Per proposal: Transaction-Based Inventory (no direct inventory modification allowed)
/// All inventory changes create transactions: Receipt, Issue, Transfer, Adjustment, Count, etc.
/// </summary>
public class InventoryTransaction
{
    public int Id { get; private set; }
    public int? CompanyId { get; private set; }
    public int? BranchId { get; private set; }
    public int WarehouseId { get; private set; }
    public int? SourceWarehouseId { get; private set; }    // For Transfer
    public int? TargetWarehouseId { get; private set; }    // For Transfer
    public int ProductId { get; private set; }
    public int? BatchId { get; private set; }
    public int? SerialId { get; private set; }
    public int Quantity { get; private set; }
    public InventoryTransactionType TransactionType { get; private set; }
    public string ReferenceDocument { get; private set; } = string.Empty; // Document number reference
    public DateTime TransactionDate { get; private set; }
    public string Status { get; private set; } = "Draft";    // Draft, Confirmed, Cancelled
    public bool IsActive { get; private set; } = true;
    public DateTime CreatedAt { get; private set; }
    public string CreatedBy { get; private set; } = string.Empty;

    private InventoryTransaction() { }

    public InventoryTransaction(
        int? companyId,
        int? branchId,
        int warehouseId,
        int productId,
        int quantity,
        InventoryTransactionType transactionType,
        int? sourceWarehouseId = null,
        int? targetWarehouseId = null,
        int? batchId = null,
        int? serialId = null,
        string referenceDocument = "",
        DateTime? transactionDate = null,
        string createdBy = "")
    {
        if (companyId == null || companyId <= 0) throw new ArgumentException("Company required", nameof(companyId));
        if (warehouseId <= 0) throw new ArgumentException("Warehouse required", nameof(warehouseId));
        if (productId <= 0) throw new ArgumentException("Product required", nameof(productId));
        if (quantity == 0) throw new ArgumentException("Quantity cannot be zero");
        if (transactionType == InventoryTransactionType.Transfer && (sourceWarehouseId == null || targetWarehouseId == null))
            throw new ArgumentException("Transfer requires source and target warehouse");

        CompanyId = companyId;
        BranchId = branchId;
        WarehouseId = warehouseId;
        SourceWarehouseId = sourceWarehouseId;
        TargetWarehouseId = targetWarehouseId;
        ProductId = productId;
        BatchId = batchId;
        SerialId = serialId;
        Quantity = quantity;
        TransactionType = transactionType;
        ReferenceDocument = referenceDocument?.Trim() ?? string.Empty;
        TransactionDate = transactionDate ?? DateTime.UtcNow;
        Status = "Draft";
        CreatedAt = DateTime.UtcNow;
        CreatedBy = createdBy ?? "system";
        IsActive = true;
    }

    public void Confirm() => Status = "Confirmed";
    public void Cancel() => Status = "Cancelled";
    public void Deactivate() => IsActive = false;
    public void Activate() => IsActive = true;
}
