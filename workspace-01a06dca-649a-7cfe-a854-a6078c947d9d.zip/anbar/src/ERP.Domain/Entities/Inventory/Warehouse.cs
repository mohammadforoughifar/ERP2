using System;

namespace ERP.Domain.Entities.Inventory;

/// <summary>
/// Warehouse — Phase 7 Inventory
/// Per proposal: Multi-Warehouse, Location, Bin, Zone, Rack, Shelf
/// </summary>
public class Warehouse
{
    public int Id { get; private set; }
    public int? CompanyId { get; private set; }
    public int? BranchId { get; private set; }
    public string Code { get; private set; } = string.Empty;
    public string Name { get; private set; } = string.Empty;
    public string Address { get; private set; } = string.Empty;
    public bool IsActive { get; private set; } = true;
    public bool IsDefault { get; private set; } = false;
    public DateTime CreatedAt { get; private set; }
    public string CreatedBy { get; private set; } = string.Empty;

    private Warehouse() { }

    public Warehouse(
        int? companyId,
        int? branchId,
        string code,
        string name,
        string address,
        bool isDefault,
        string createdBy)
    {
        if (companyId == null || companyId <= 0) throw new ArgumentException("Company required", nameof(companyId));
        if (string.IsNullOrWhiteSpace(code)) throw new ArgumentException("Warehouse code required");
        if (string.IsNullOrWhiteSpace(name)) throw new ArgumentException("Warehouse name required");

        CompanyId = companyId;
        BranchId = branchId;
        Code = code.Trim();
        Name = name.Trim();
        Address = address?.Trim() ?? string.Empty;
        IsDefault = isDefault;
        CreatedAt = DateTime.UtcNow;
        CreatedBy = createdBy;
        IsActive = true;
    }

    public void UpdateProfile(string name, string address, bool isDefault)
    {
        Name = name.Trim();
        Address = address?.Trim() ?? string.Empty;
        IsDefault = isDefault;
    }

    public void Deactivate() => IsActive = false;
    public void Activate() => IsActive = true;
}
