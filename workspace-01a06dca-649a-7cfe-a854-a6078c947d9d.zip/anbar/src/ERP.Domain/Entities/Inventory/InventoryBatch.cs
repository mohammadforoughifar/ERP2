using System;

namespace ERP.Domain.Entities.Inventory;

/// <summary>
/// Inventory Batch — Phase 7 Inventory
/// Per proposal: Batch Tracking, Expiration, Warranty, Traceability from Purchase to Warehouse to Sales
/// </summary>
public class InventoryBatch
{
    public int Id { get; private set; }
    public int? CompanyId { get; private set; }
    public int ProductId { get; private set; }
    public string BatchNumber { get; private set; } = string.Empty;         // شماره بچ
    public DateTime ProductionDate { get; private set; }
    public DateTime ExpirationDate { get; private set; }                   // تاریخ انقضا
    public DateTime? WarrantyExpiry { get; private set; }                  // تاریخ گارانتی
    public int WarehouseId { get; private set; }
    public int CurrentQuantity { get; private set; }
    public bool IsActive { get; private set; } = true;
    public DateTime CreatedAt { get; private set; }
    public string CreatedBy { get; private set; } = string.Empty;

    private InventoryBatch() { }

    public InventoryBatch(
        int? companyId,
        int productId,
        string batchNumber,
        DateTime productionDate,
        DateTime expirationDate,
        DateTime? warrantyExpiry,
        int warehouseId,
        int currentQuantity,
        string createdBy)
    {
        if (companyId == null || companyId <= 0) throw new ArgumentException("Company required", nameof(companyId));
        if (productId <= 0) throw new ArgumentException("Product required", nameof(productId));
        if (string.IsNullOrWhiteSpace(batchNumber)) throw new ArgumentException("Batch number required");
        if (warehouseId <= 0) throw new ArgumentException("Warehouse required", nameof(warehouseId));
        if (currentQuantity < 0) throw new ArgumentException("Quantity cannot be negative");

        CompanyId = companyId;
        ProductId = productId;
        BatchNumber = batchNumber.Trim();
        ProductionDate = productionDate;
        ExpirationDate = expirationDate;
        WarrantyExpiry = warrantyExpiry;
        WarehouseId = warehouseId;
        CurrentQuantity = currentQuantity;
        CreatedAt = DateTime.UtcNow;
        CreatedBy = createdBy;
        IsActive = true;
    }

    public void UpdateQuantity(int newQuantity)
    {
        if (newQuantity < 0) throw new ArgumentException("Quantity cannot be negative");
        CurrentQuantity = newQuantity;
    }

    public void Deactivate() => IsActive = false;
    public void Activate() => IsActive = true;
}
