using System;
using System.Collections.Generic;

namespace ERP.Domain.Entities.Workflow;

/// <summary>
/// Workflow Definition — Phase 12 Workflow
/// Per proposal: Dynamic Workflow with Step, Condition, Approval, Role, User, Notification, SLA, Escalation
/// </summary>
public class WorkflowDefinition
{
    public int Id { get; private set; }
    public int? CompanyId { get; private set; }
    public string WorkflowName { get; private set; } = string.Empty;
    public string DocumentType { get; private set; } = string.Empty;     // Document type this workflow applies to
    public string Module { get; private set; } = string.Empty;           // Module (Sales, Purchase, Finance, etc.)
    public bool IsActive { get; private set; } = true;
    public DateTime CreatedAt { get; private set; }
    public string CreatedBy { get; private set; } = string.Empty;

    private readonly List<WorkflowStep> _steps = new();
    public IReadOnlyCollection<WorkflowStep> Steps => _steps.AsReadOnly();

    private WorkflowDefinition() { }

    public WorkflowDefinition(
        int? companyId,
        string workflowName,
        string documentType,
        string module,
        string createdBy)
    {
        if (string.IsNullOrWhiteSpace(workflowName)) throw new ArgumentException("Workflow name required");
        if (string.IsNullOrWhiteSpace(documentType)) throw new ArgumentException("Document type required");

        CompanyId = companyId;
        WorkflowName = workflowName.Trim();
        DocumentType = documentType.Trim();
        Module = module?.Trim() ?? string.Empty;
        CreatedAt = DateTime.UtcNow;
        CreatedBy = createdBy;
        IsActive = true;
    }

    public void AddStep(WorkflowStep step)
    {
        _steps.Add(step);
    }

    public void Deactivate() => IsActive = false;
    public void Activate() => IsActive = true;
}
