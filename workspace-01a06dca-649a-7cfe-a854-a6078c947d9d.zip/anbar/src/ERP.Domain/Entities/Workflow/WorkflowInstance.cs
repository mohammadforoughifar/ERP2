using System;

namespace ERP.Domain.Entities.Workflow;

/// <summary>
/// Workflow Instance — Phase 12 Workflow
/// Per proposal: Running instance of a workflow for a specific document
/// </summary>
public class WorkflowInstance
{
    public int Id { get; private set; }
    public int WorkflowDefinitionId { get; private set; }
    public int? CompanyId { get; private set; }
    public int DocumentId { get; private set; }                 // Document ID this workflow runs on
    public string DocumentType { get; private set; } = string.Empty;
    public string Status { get; private set; } = "Running";      // Running, Completed, Cancelled, Suspended
    public int CurrentStepSequence { get; private set; }
    public DateTime StartedAt { get; private set; }
    public DateTime? CompletedAt { get; private set; }
    public bool IsActive { get; private set; } = true;
    public DateTime CreatedAt { get; private set; }
    public string CreatedBy { get; private set; } = string.Empty;

    private WorkflowInstance() { }

    public WorkflowInstance(
        int workflowDefinitionId,
        int? companyId,
        int documentId,
        string documentType,
        int currentStepSequence,
        string createdBy)
    {
        if (workflowDefinitionId <= 0) throw new ArgumentException("Workflow definition required");
        if (documentId <= 0) throw new ArgumentException("Document ID required");

        WorkflowDefinitionId = workflowDefinitionId;
        CompanyId = companyId;
        DocumentId = documentId;
        DocumentType = documentType?.Trim() ?? string.Empty;
        Status = "Running";
        CurrentStepSequence = currentStepSequence > 0 ? currentStepSequence : 1;
        StartedAt = DateTime.UtcNow;
        CompletedAt = null;
        CreatedAt = DateTime.UtcNow;
        CreatedBy = createdBy;
        IsActive = true;
    }

    public void AdvanceStep(int newStepSequence)
    {
        CurrentStepSequence = newStepSequence > 0 ? newStepSequence : CurrentStepSequence;
    }

    public void Complete() => Status = "Completed";
    public void Cancel() => Status = "Cancelled";
    public void Suspend() => Status = "Suspended";
    public void Deactivate() => IsActive = false;
    public void Activate() => IsActive = true;
}
