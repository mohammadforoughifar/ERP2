using System;

namespace ERP.Domain.Entities.Workflow;

/// <summary>
/// Workflow Task — Phase 12 Workflow
/// Per proposal: Tasks assigned to users/roles for approval/action
/// </summary>
public class WorkflowTask
{
    public int Id { get; private set; }
    public int WorkflowInstanceId { get; private set; }
    public int? AssignedToUserId { get; private set; }
    public int? AssignedToRoleId { get; private set; }
    public string TaskType { get; private set; } = string.Empty;     // Approval, Review, Notification
    public string Status { get; private set; } = "Pending";         // Pending, InProgress, Completed, Rejected, Escalated
    public DateTime AssignedAt { get; private set; }
    public DateTime? CompletedAt { get; private set; }
    public DateTime? DueDate { get; private set; }                  // SLA due date
    public bool IsActive { get; private set; } = true;
    public DateTime CreatedAt { get; private set; }
    public string CreatedBy { get; private set; } = string.Empty;

    public WorkflowInstance? WorkflowInstance { get; private set; }

    private WorkflowTask() { }

    public WorkflowTask(
        int workflowInstanceId,
        int? assignedToUserId,
        int? assignedToRoleId,
        string taskType,
        DateTime? dueDate,
        string createdBy)
    {
        if (workflowInstanceId <= 0) throw new ArgumentException("Workflow instance required");
        if (string.IsNullOrWhiteSpace(taskType)) throw new ArgumentException("Task type required");

        WorkflowInstanceId = workflowInstanceId;
        AssignedToUserId = assignedToUserId;
        AssignedToRoleId = assignedToRoleId;
        TaskType = taskType.Trim();
        Status = "Pending";
        AssignedAt = DateTime.UtcNow;
        CompletedAt = null;
        DueDate = dueDate;
        CreatedAt = DateTime.UtcNow;
        CreatedBy = createdBy;
        IsActive = true;
    }

    public void Complete() => Status = "Completed";
    public void Reject() => Status = "Rejected";
    public void Escalate() => Status = "Escalated";
    public void StartProgress() => Status = "InProgress";
    public void Deactivate() => IsActive = false;
    public void Activate() => IsActive = true;
}
