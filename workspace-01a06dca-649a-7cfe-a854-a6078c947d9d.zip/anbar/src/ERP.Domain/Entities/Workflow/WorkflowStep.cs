using System;

namespace ERP.Domain.Entities.Workflow;

/// <summary>
/// Workflow Step — Phase 12 Workflow
/// Per proposal: Dynamic Workflow Step with Condition, Approval, Role, User, Notification, SLA, Escalation
/// </summary>
public enum WorkflowStepType
{
    Start = 1,
    Approval = 2,
    Condition = 3,
    Notification = 4,
    End = 5
}

public class WorkflowStep
{
    public int Id { get; private set; }
    public int WorkflowDefinitionId { get; private set; }
    public string StepName { get; private set; } = string.Empty;
    public WorkflowStepType StepType { get; private set; }
    public int Sequence { get; private set; }                        // Step order
    public int? RequiredRoleId { get; private set; }
    public int? RequiredUserId { get; private set; }
    public string ConditionExpression { get; private set; } = string.Empty; // Condition logic
    public int? SLAInHours { get; private set; }                      // SLA: time limit in hours
    public int? EscalationUserId { get; private set; }               // Escalation user
    public bool SendNotification { get; private set; } = false;      // Send notification
    public bool IsActive { get; private set; } = true;
    public DateTime CreatedAt { get; private set; }
    public string CreatedBy { get; private set; } = string.Empty;

    public WorkflowDefinition? WorkflowDefinition { get; private set; }

    private WorkflowStep() { }

    public WorkflowStep(
        int workflowDefinitionId,
        string stepName,
        WorkflowStepType stepType,
        int sequence,
        int? requiredRoleId,
        int? requiredUserId,
        string conditionExpression,
        int? slaInHours,
        int? escalationUserId,
        bool sendNotification,
        string createdBy)
    {
        if (workflowDefinitionId <= 0) throw new ArgumentException("Workflow definition required");
        if (string.IsNullOrWhiteSpace(stepName)) throw new ArgumentException("Step name required");
        if (sequence <= 0) throw new ArgumentException("Sequence must be positive");

        WorkflowDefinitionId = workflowDefinitionId;
        StepName = stepName.Trim();
        StepType = stepType;
        Sequence = sequence;
        RequiredRoleId = requiredRoleId;
        RequiredUserId = requiredUserId;
        ConditionExpression = conditionExpression?.Trim() ?? string.Empty;
        SLAInHours = slaInHours;
        EscalationUserId = escalationUserId;
        SendNotification = sendNotification;
        CreatedAt = DateTime.UtcNow;
        CreatedBy = createdBy;
        IsActive = true;
    }

    public void Deactivate() => IsActive = false;
    public void Activate() => IsActive = true;
}
