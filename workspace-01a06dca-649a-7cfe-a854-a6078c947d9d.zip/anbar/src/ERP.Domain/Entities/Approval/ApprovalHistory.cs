using System;

namespace ERP.Domain.Entities.Approval;

/// <summary>
/// Approval History — Phase 12 Approval
/// Per proposal: Audit log for approval/rejection/delegation actions
/// </summary>
public class ApprovalHistory
{
    public int Id { get; private set; }
    public int ApprovalRequestId { get; private set; }
    public int? UserId { get; private set; }                // User who performed action
    public string Action { get; private set; } = string.Empty; // Approve, Reject, Delegate, Escalate, Comment
    public string Comment { get; private set; } = string.Empty; // Approval/rejection reason or comment
    public DateTime ActionDate { get; private set; }
    public bool IsActive { get; private set; } = true;
    public DateTime CreatedAt { get; private set; }
    public string CreatedBy { get; private set; } = string.Empty;

    private ApprovalHistory() { }

    public ApprovalHistory(
        int approvalRequestId,
        int? userId,
        string action,
        string comment,
        string createdBy)
    {
        if (approvalRequestId <= 0) throw new ArgumentException("Approval request required");
        if (string.IsNullOrWhiteSpace(action)) throw new ArgumentException("Action required");

        ApprovalRequestId = approvalRequestId;
        UserId = userId;
        Action = action.Trim();
        Comment = comment?.Trim() ?? string.Empty;
        ActionDate = DateTime.UtcNow;
        CreatedAt = DateTime.UtcNow;
        CreatedBy = createdBy;
        IsActive = true;
    }

    public void Deactivate() => IsActive = false;
    public void Activate() => IsActive = true;
}
