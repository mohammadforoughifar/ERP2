using System;

namespace ERP.Domain.Entities.Approval;

/// <summary>
/// Approval Request — Phase 12 Approval
/// Per proposal: Approval Center (Inbox for managers) with Document, Amount, Requester, Date, Priority, Reason, Actions
/// </summary>
public class ApprovalRequest
{
    public int Id { get; private set; }
    public int? CompanyId { get; private set; }
    public int DocumentId { get; private set; }              // Related document (Invoice, PurchaseOrder, etc.)
    public string DocumentType { get; private set; } = string.Empty;
    public int RequesterId { get; private set; }            // User who submitted for approval
    public int? ApproverId { get; private set; }            // Assigned approver (manager)
    public int? ApproverRoleId { get; private set; }
    public decimal Amount { get; private set; }
    public string Priority { get; private set; } = string.Empty; // Low, Medium, High, Critical
    public string Reason { get; private set; } = string.Empty;
    public string Status { get; private set; } = "Pending";  // Pending, Approved, Rejected, Delegated, Escalated
    public bool IsActive { get; private set; } = true;
    public DateTime CreatedAt { get; private set; }
    public DateTime? DecidedAt { get; private set; }
    public string CreatedBy { get; private set; } = string.Empty;

    private ApprovalRequest() { }

    public ApprovalRequest(
        int? companyId,
        int documentId,
        string documentType,
        int requesterId,
        int? approverId,
        int? approverRoleId,
        decimal amount,
        string priority,
        string reason,
        string createdBy)
    {
        if (companyId == null || companyId <= 0) throw new ArgumentException("Company required", nameof(companyId));
        if (documentId <= 0) throw new ArgumentException("Document required", nameof(documentId));
        if (requesterId <= 0) throw new ArgumentException("Requester required", nameof(requesterId));

        CompanyId = companyId;
        DocumentId = documentId;
        DocumentType = documentType?.Trim() ?? string.Empty;
        RequesterId = requesterId;
        ApproverId = approverId;
        ApproverRoleId = approverRoleId;
        Amount = amount >= 0 ? amount : 0;
        Priority = priority?.Trim() ?? "Medium";
        Reason = reason?.Trim() ?? string.Empty;
        Status = "Pending";
        CreatedAt = DateTime.UtcNow;
        DecidedAt = null;
        CreatedBy = createdBy;
        IsActive = true;
    }

    public void Approve(string approverComment) => Status = "Approved";
    public void Reject(string approverComment) => Status = "Rejected";
    public void Delegate(int newApproverId) => Status = "Delegated";
    public void Escalate() => Status = "Escalated";
    public void Deactivate() => IsActive = false;
    public void Activate() => IsActive = true;
}
