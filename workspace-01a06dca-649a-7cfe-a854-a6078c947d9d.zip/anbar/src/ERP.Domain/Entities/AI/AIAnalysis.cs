using System;
using System.ComponentModel.DataAnnotations;

namespace ERP.Domain.Entities.AI;

public class AIAnalysis
{
    [Key]
    public int Id { get; set; }

    [StringLength(200)]
    public string AnalysisType { get; set; } = string.Empty;

    [StringLength(500)]
    public string? RelatedEntity { get; set; }

    [StringLength(2000)]
    public string AnalysisResult { get; set; } = string.Empty;

    [StringLength(50)]
    public string Status { get; set; } = "Draft";

    public int CompanyId { get; set; }
    public int BranchId { get; set; }
    public int TenantId { get; set; }

    [StringLength(100)]
    public string CreatedBy { get; set; } = string.Empty;

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    public bool IsActive { get; set; } = true;
}
