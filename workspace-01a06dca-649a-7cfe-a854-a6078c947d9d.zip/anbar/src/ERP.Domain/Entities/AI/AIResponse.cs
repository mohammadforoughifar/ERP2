using System;
using System.ComponentModel.DataAnnotations;

namespace ERP.Domain.Entities.AI;

public class AIResponse
{
    [Key]
    public int Id { get; set; }

    [Required]
    public int PromptId { get; set; }

    [StringLength(4000)]
    public string ResponseText { get; set; } = string.Empty;

    public decimal ConfidenceScore { get; set; } = 0;

    [StringLength(500)]
    public string? ChartReference { get; set; }

    [StringLength(50)]
    public string Status { get; set; } = "Generated";

    public int CompanyId { get; set; }
    public int BranchId { get; set; }
    public int TenantId { get; set; }

    [StringLength(100)]
    public string CreatedBy { get; set; } = string.Empty;

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    public bool IsActive { get; set; } = true;
}
