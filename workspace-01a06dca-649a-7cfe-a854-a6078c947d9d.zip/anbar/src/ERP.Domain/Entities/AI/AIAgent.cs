using System;
using System.ComponentModel.DataAnnotations;

namespace ERP.Domain.Entities.AI;

public class AIAgent
{
    [Key]
    public int Id { get; set; }

    [Required]
    [StringLength(200)]
    public string AgentName { get; set; } = string.Empty;

    [StringLength(2000)]
    public string? Description { get; set; }

    [StringLength(500)]
    public string Capabilities { get; set; } = string.Empty;

    [StringLength(100)]
    public string Status { get; set; } = "Active";

    public int CompanyId { get; set; }
    public int BranchId { get; set; }
    public int TenantId { get; set; }

    [StringLength(100)]
    public string CreatedBy { get; set; } = string.Empty;

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    [StringLength(100)]
    public string? ModifiedBy { get; set; }

    public DateTime? ModifiedAt { get; set; }

    public bool IsActive { get; set; } = true;
}
