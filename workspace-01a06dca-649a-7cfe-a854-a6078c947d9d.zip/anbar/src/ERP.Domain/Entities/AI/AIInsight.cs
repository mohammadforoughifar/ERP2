using System;
using System.ComponentModel.DataAnnotations;

namespace ERP.Domain.Entities.AI;

public class AIInsight
{
    [Key]
    public int Id { get; set; }

    [StringLength(500)]
    public string InsightTitle { get; set; } = string.Empty;

    [StringLength(2000)]
    public string InsightContent { get; set; } = string.Empty;

    [StringLength(100)]
    public string Priority { get; set; } = "Medium";

    [StringLength(200)]
    public string? RelatedEntity { get; set; }

    public int CompanyId { get; set; }
    public int BranchId { get; set; }
    public int TenantId { get; set; }

    [StringLength(100)]
    public string CreatedBy { get; set; } = string.Empty;

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    [StringLength(100)]
    public string? ModifiedBy { get; set; }

    public DateTime? ModifiedAt { get; set; }

    public bool IsActive { get; set; } = true;
}
