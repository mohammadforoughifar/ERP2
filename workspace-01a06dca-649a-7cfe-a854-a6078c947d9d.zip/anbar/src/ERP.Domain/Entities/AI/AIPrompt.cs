using System;
using System.ComponentModel.DataAnnotations;

namespace ERP.Domain.Entities.AI;

public class AIPrompt
{
    [Key]
    public int Id { get; set; }

    [Required]
    public int AgentId { get; set; }

    [StringLength(4000)]
    public string PromptText { get; set; } = string.Empty;

    [StringLength(50)]
    public string Intent { get; set; } = "Unknown";

    [StringLength(100)]
    public string Status { get; set; } = "Pending";

    public int CompanyId { get; set; }
    public int BranchId { get; set; }
    public int TenantId { get; set; }

    [StringLength(100)]
    public string CreatedBy { get; set; } = string.Empty;

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    public bool IsActive { get; set; } = true;
}
