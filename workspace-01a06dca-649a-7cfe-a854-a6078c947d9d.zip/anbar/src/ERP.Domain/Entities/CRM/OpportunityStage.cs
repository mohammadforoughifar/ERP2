using System;

namespace ERP.Domain.Entities.CRM;

/// <summary>
/// Opportunity Stage / Pipeline Stage — Phase 8 CRM
/// Per proposal: Pipeline management, Sales Forecast base
/// </summary>
public class OpportunityStage
{
    public int Id { get; private set; }
    public int? CompanyId { get; private set; }
    public string Name { get; private set; } = string.Empty;           // Stage name: Prospecting, Qualification, Proposal, Negotiation, Closed Won
    public int Order { get; private set; }                               // Order in pipeline (1, 2, 3, ...)
    public decimal Probability { get; private set; }                    // Default probability for stage
    public bool IsActive { get; private set; } = true;
    public DateTime CreatedAt { get; private set; }
    public string CreatedBy { get; private set; } = string.Empty;

    private OpportunityStage() { }

    public OpportunityStage(
        int? companyId,
        string name,
        int order,
        decimal probability,
        string createdBy)
    {
        if (string.IsNullOrWhiteSpace(name)) throw new ArgumentException("Stage name required");
        if (order < 1) throw new ArgumentException("Order must be positive");
        if (probability < 0 || probability > 100) throw new ArgumentException("Probability must be 0-100");

        CompanyId = companyId;
        Name = name.Trim();
        Order = order;
        Probability = probability;
        CreatedAt = DateTime.UtcNow;
        CreatedBy = createdBy;
        IsActive = true;
    }

    public void UpdateProfile(string name, int order, decimal probability)
    {
        Name = name.Trim();
        Order = order;
        if (probability >= 0 && probability <= 100) Probability = probability;
    }

    public void Deactivate() => IsActive = false;
    public void Activate() => IsActive = true;
}
