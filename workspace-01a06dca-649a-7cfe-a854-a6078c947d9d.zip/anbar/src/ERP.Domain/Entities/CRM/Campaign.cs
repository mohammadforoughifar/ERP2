using System;

namespace ERP.Domain.Entities.CRM;

/// <summary>
/// Campaign — Phase 8 CRM
/// Per proposal: Campaign tracking, Customer acquisition analysis
/// </summary>
public class Campaign
{
    public int Id { get; private set; }
    public int? CompanyId { get; private set; }
    public string Name { get; private set; } = string.Empty;
    public string Type { get; private set; } = string.Empty;         // Email, Social, Event, etc.
    public DateTime StartDate { get; private set; }
    public DateTime? EndDate { get; private set; }
    public decimal Budget { get; private set; }
    public string Status { get; private set; } = "Planned";         // Planned, Active, Completed, Cancelled
    public bool IsActive { get; private set; } = true;
    public DateTime CreatedAt { get; private set; }
    public string CreatedBy { get; private set; } = string.Empty;

    private Campaign() { }

    public Campaign(
        int? companyId,
        string name,
        string type,
        DateTime startDate,
        DateTime? endDate,
        decimal budget,
        string createdBy)
    {
        if (companyId == null || companyId <= 0) throw new ArgumentException("Company required", nameof(companyId));
        if (string.IsNullOrWhiteSpace(name)) throw new ArgumentException("Campaign name required");

        CompanyId = companyId;
        Name = name.Trim();
        Type = type?.Trim() ?? string.Empty;
        StartDate = startDate;
        EndDate = endDate;
        Budget = budget >= 0 ? budget : 0;
        Status = "Planned";
        CreatedAt = DateTime.UtcNow;
        CreatedBy = createdBy;
        IsActive = true;
    }

    public void Start() => Status = "Active";
    public void Complete() => Status = "Completed";
    public void Cancel() => Status = "Cancelled";
    public void Deactivate() => IsActive = false;
    public void Activate() => IsActive = true;
}
