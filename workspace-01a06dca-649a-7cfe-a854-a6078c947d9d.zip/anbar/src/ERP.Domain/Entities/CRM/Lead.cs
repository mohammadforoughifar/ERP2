using System;

namespace ERP.Domain.Entities.CRM;

/// <summary>
/// Lead — Phase 8 CRM
/// Per proposal: Lead → Opportunity → Customer conversion flow
/// </summary>
public class Lead
{
    public int Id { get; private set; }
    public int? CompanyId { get; private set; }
    public int? AssignedToUserId { get; private set; }
    public string FirstName { get; private set; } = string.Empty;
    public string LastName { get; private set; } = string.Empty;
    public string Email { get; private set; } = string.Empty;
    public string Phone { get; private set; } = string.Empty;
    public string Source { get; private set; } = string.Empty;          // Source: Website, Referral, Campaign, etc.
    public string Status { get; private set; } = "New";                   // New, Contacted, Qualified, Converted, Lost
    public int? ConvertedCustomerId { get; private set; }                // If converted to Customer
    public bool IsActive { get; private set; } = true;
    public DateTime CreatedAt { get; private set; }
    public string CreatedBy { get; private set; } = string.Empty;

    private Lead() { }

    public Lead(
        int? companyId,
        int? assignedToUserId,
        string firstName,
        string lastName,
        string email,
        string phone,
        string source,
        string createdBy)
    {
        if (companyId == null || companyId <= 0) throw new ArgumentException("Company required", nameof(companyId));
        if (string.IsNullOrWhiteSpace(firstName)) throw new ArgumentException("First name required");

        CompanyId = companyId;
        AssignedToUserId = assignedToUserId;
        FirstName = firstName.Trim();
        LastName = lastName?.Trim() ?? string.Empty;
        Email = email?.Trim() ?? string.Empty;
        Phone = phone?.Trim() ?? string.Empty;
        Source = source?.Trim() ?? string.Empty;
        Status = "New";
        CreatedAt = DateTime.UtcNow;
        CreatedBy = createdBy;
        IsActive = true;
    }

    public void UpdateStatus(string status)
    {
        Status = status?.Trim() ?? Status;
    }

    public void ConvertToCustomer(int customerId)
    {
        ConvertedCustomerId = customerId;
        Status = "Converted";
    }

    public void MarkLost() => Status = "Lost";
    public void Deactivate() => IsActive = false;
    public void Activate() => IsActive = true;
}
