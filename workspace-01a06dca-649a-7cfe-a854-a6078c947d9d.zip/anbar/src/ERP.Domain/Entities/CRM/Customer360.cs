using System;

namespace ERP.Domain.Entities.CRM;

/// <summary>
/// Customer 360 — Phase 8 CRM
/// Per proposal: Customer 360 view combining Customer info, Sales, Purchase, Balance,
/// Check, Order, Invoice, Payment, Ticket, Contract, Activity, Customer Profitability
/// This is a read-only aggregate view (not a mutable entity)
/// </summary>
public class Customer360
{
    public int CustomerId { get; private set; }
    public string CustomerName { get; private set; } = string.Empty;
    public string CustomerCode { get; private set; } = string.Empty;
    public string CustomerStatus { get; private set; } = string.Empty;
    public decimal TotalSalesAmount { get; private set; }
    public decimal TotalPurchaseAmount { get; private set; }
    public decimal CustomerBalance { get; private set; }
    public int OpenOrdersCount { get; private set; }
    public int OpenInvoicesCount { get; private set; }
    public int OpenChecksCount { get; private set; }
    public decimal CustomerProfitability { get; private set; }          // Gross Profit from this customer
    public string LastActivityDate { get; private set; } = string.Empty;
    public string CreditStatus { get; private set; } = string.Empty;   // Good, Watch, Blocked

    private Customer360() { }

    public Customer360(
        int customerId,
        string customerName,
        string customerCode,
        string customerStatus,
        decimal totalSalesAmount,
        decimal totalPurchaseAmount,
        decimal customerBalance,
        int openOrdersCount,
        int openInvoicesCount,
        int openChecksCount,
        decimal customerProfitability,
        string lastActivityDate,
        string creditStatus)
    {
        CustomerId = customerId > 0 ? customerId : throw new ArgumentException("Customer ID required");
        CustomerName = customerName?.Trim() ?? string.Empty;
        CustomerCode = customerCode?.Trim() ?? string.Empty;
        CustomerStatus = customerStatus?.Trim() ?? string.Empty;
        TotalSalesAmount = totalSalesAmount >= 0 ? totalSalesAmount : 0;
        TotalPurchaseAmount = totalPurchaseAmount >= 0 ? totalPurchaseAmount : 0;
        CustomerBalance = customerBalance;
        OpenOrdersCount = openOrdersCount >= 0 ? openOrdersCount : 0;
        OpenInvoicesCount = openInvoicesCount >= 0 ? openInvoicesCount : 0;
        OpenChecksCount = openChecksCount >= 0 ? openChecksCount : 0;
        CustomerProfitability = customerProfitability;
        LastActivityDate = lastActivityDate?.Trim() ?? string.Empty;
        CreditStatus = creditStatus?.Trim() ?? string.Empty;
    }
}
