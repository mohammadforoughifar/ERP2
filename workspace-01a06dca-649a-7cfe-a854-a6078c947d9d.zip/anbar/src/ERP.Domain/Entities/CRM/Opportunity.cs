using System;

namespace ERP.Domain.Entities.CRM;

/// <summary>
/// Opportunity — Phase 8 CRM
/// Per proposal: Pipeline management, Sales Forecast base, Customer 360 connection
/// </summary>
public class Opportunity
{
    public int Id { get; private set; }
    public int? CompanyId { get; private set; }
    public int? LeadId { get; private set; }
    public int? CustomerId { get; private set; }
    public int AssignedToUserId { get; private set; }
    public int? OpportunityStageId { get; private set; }
    public string Title { get; private set; } = string.Empty;
    public decimal ExpectedValue { get; private set; }
    public DateTime ExpectedCloseDate { get; private set; }
    public string Status { get; private set; } = "Open";                  // Open, Won, Lost, OnHold
    public decimal Probability { get; private set; }                     // Probability % (0-100)
    public bool IsActive { get; private set; } = true;
    public DateTime CreatedAt { get; private set; }
    public string CreatedBy { get; private set; } = string.Empty;

    private Opportunity() { }

    public Opportunity(
        int? companyId,
        int? leadId,
        int? customerId,
        int assignedToUserId,
        int? opportunityStageId,
        string title,
        decimal expectedValue,
        DateTime expectedCloseDate,
        decimal probability,
        string createdBy)
    {
        if (companyId == null || companyId <= 0) throw new ArgumentException("Company required", nameof(companyId));
        if (assignedToUserId <= 0) throw new ArgumentException("Assigned user required");
        if (string.IsNullOrWhiteSpace(title)) throw new ArgumentException("Title required");
        if (probability < 0 || probability > 100) throw new ArgumentException("Probability must be 0-100");

        CompanyId = companyId;
        LeadId = leadId;
        CustomerId = customerId;
        AssignedToUserId = assignedToUserId;
        OpportunityStageId = opportunityStageId;
        Title = title.Trim();
        ExpectedValue = expectedValue >= 0 ? expectedValue : 0;
        ExpectedCloseDate = expectedCloseDate;
        Probability = probability;
        Status = "Open";
        CreatedAt = DateTime.UtcNow;
        CreatedBy = createdBy;
        IsActive = true;
    }

    public void UpdateStage(int stageId, decimal probability)
    {
        OpportunityStageId = stageId;
        if (probability >= 0 && probability <= 100) Probability = probability;
    }

    public void Win() => Status = "Won";
    public void Lose() => Status = "Lost";
    public void Hold() => Status = "OnHold";
    public void Deactivate() => IsActive = false;
    public void Activate() => IsActive = true;
}
