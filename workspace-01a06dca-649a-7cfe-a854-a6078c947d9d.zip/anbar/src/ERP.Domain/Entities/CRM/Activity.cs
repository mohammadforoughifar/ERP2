using System;

namespace ERP.Domain.Entities.CRM;

/// <summary>
/// Activity — Phase 8 CRM
/// Per proposal: Task, Call, Meeting, Activity tracking linked to Lead/Opportunity/Customer
/// </summary>
public enum ActivityType
{
    Task = 1,
    Call = 2,
    Meeting = 3,
    Email = 4
}

public class Activity
{
    public int Id { get; private set; }
    public int? CompanyId { get; private set; }
    public int? AssignedToUserId { get; private set; }
    public int? LeadId { get; private set; }
    public int? OpportunityId { get; private set; }
    public int? CustomerId { get; private set; }
    public string Subject { get; private set; } = string.Empty;
    public ActivityType Type { get; private set; }
    public DateTime DueDate { get; private set; }
    public string Status { get; private set; } = "NotStarted"; // NotStarted, InProgress, Completed, Cancelled
    public string Description { get; private set; } = string.Empty;
    public bool IsActive { get; private set; } = true;
    public DateTime CreatedAt { get; private set; }
    public string CreatedBy { get; private set; } = string.Empty;

    private Activity() { }

    public Activity(
        int? companyId,
        int? assignedToUserId,
        int? leadId,
        int? opportunityId,
        int? customerId,
        string subject,
        ActivityType type,
        DateTime dueDate,
        string description,
        string createdBy)
    {
        if (companyId == null || companyId <= 0) throw new ArgumentException("Company required", nameof(companyId));
        if (string.IsNullOrWhiteSpace(subject)) throw new ArgumentException("Subject required");

        CompanyId = companyId;
        AssignedToUserId = assignedToUserId;
        LeadId = leadId;
        OpportunityId = opportunityId;
        CustomerId = customerId;
        Subject = subject.Trim();
        Type = type;
        DueDate = dueDate;
        Description = description?.Trim() ?? string.Empty;
        Status = "NotStarted";
        CreatedAt = DateTime.UtcNow;
        CreatedBy = createdBy;
        IsActive = true;
    }

    public void Complete() => Status = "Completed";
    public void Start() => Status = "InProgress";
    public void Cancel() => Status = "Cancelled";
    public void Deactivate() => IsActive = false;
    public void Activate() => IsActive = true;
}
