using System;

namespace ERP.Domain.Entities;

/// <summary>
/// Role — RBAC base per proposal Security (Phase 1 Core)
/// </summary>
public class Role
{
    public int Id { get; private set; }
    public int? CompanyId { get; private set; }
    public string Name { get; private set; } = string.Empty;
    public bool IsActive { get; private set; } = true;
    public DateTime CreatedAt { get; private set; }
    public string CreatedBy { get; private set; } = string.Empty;

    private Role() { }

    public Role(int? companyId, string name, string createdBy)
    {
        if (string.IsNullOrWhiteSpace(name)) throw new ArgumentException("Role name required");
        CompanyId = companyId;
        Name = name.Trim();
        CreatedAt = DateTime.UtcNow;
        CreatedBy = createdBy;
        IsActive = true;
    }
}
