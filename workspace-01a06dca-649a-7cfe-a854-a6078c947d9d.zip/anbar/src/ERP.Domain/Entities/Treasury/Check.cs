using System;

namespace ERP.Domain.Entities.Treasury;

/// <summary>
/// Check Management — Phase 4 Treasury (Iranian Localization)
/// Per proposal: Received Check, Paid Check, Check Status, Due Date, Bank, Branch,
/// Deposit, Return, Endorsement, Settlement, Collection, Check History
/// </summary>
public enum CheckStatus
{
    Received = 1,       // دریافت شده
    Paid = 2,           // پرداخت شده
    Deposited = 3,      // واریز شده
    Returned = 4,       // برگشت خورده
    Endorsed = 5,       // ظهرنویسی شده
    Settled = 6,        // تسویه شده
    Collected = 7,      // وصول شده
    Cancelled = 8       // باطل شده
}

public class Check
{
    public int Id { get; private set; }
    public int? CompanyId { get; private set; }
    public int? BranchId { get; private set; }
    public string CheckNumber { get; private set; } = string.Empty;         // شماره چک
    public string BankName { get; private set; } = string.Empty;            // بانک صادرکننده
    public string BankBranch { get; private set; } = string.Empty;          // شعبه
    public string AccountNumber { get; private set; } = string.Empty;       // شماره حساب
    public string Shaba { get; private set; } = string.Empty;               // شماره شبا
    public string CheckBook { get; private set; } = string.Empty;           // دسته چک
    public DateTime IssueDate { get; private set; }                          // تاریخ صدور
    public DateTime DueDate { get; private set; }                            // تاریخ سررسید
    public decimal Amount { get; private set; }
    public CheckStatus Status { get; private set; } = CheckStatus.Received;
    public int? RelatedCustomerId { get; private set; }                      // دریافت از مشتری
    public int? RelatedSupplierId { get; private set; }                      // پرداخت به تأمین‌کننده
    public int? RelatedDocumentId { get; private set; }                      // سند مرتبط
    public bool IsEndorsed { get; private set; } = false;
    public string EndorsementNote { get; private set; } = string.Empty;      // توضیح ظهرنویسی
    public DateTime? SettlementDate { get; private set; }
    public string Notes { get; private set; } = string.Empty;
    public bool IsActive { get; private set; } = true;
    public DateTime CreatedAt { get; private set; }
    public string CreatedBy { get; private set; } = string.Empty;

    private Check() { }

    public Check(
        int? companyId,
        int? branchId,
        string checkNumber,
        string bankName,
        string bankBranch,
        string accountNumber,
        string shaba,
        string checkBook,
        DateTime issueDate,
        DateTime dueDate,
        decimal amount,
        int? relatedCustomerId,
        int? relatedSupplierId,
        int? relatedDocumentId,
        string notes,
        string createdBy)
    {
        if (companyId == null || companyId <= 0) throw new ArgumentException("Company required", nameof(companyId));
        if (string.IsNullOrWhiteSpace(checkNumber)) throw new ArgumentException("Check number required");
        if (string.IsNullOrWhiteSpace(bankName)) throw new ArgumentException("Bank name required");
        if (amount <= 0) throw new ArgumentException("Amount must be positive");

        CompanyId = companyId;
        BranchId = branchId;
        CheckNumber = checkNumber.Trim();
        BankName = bankName.Trim();
        BankBranch = bankBranch?.Trim() ?? string.Empty;
        AccountNumber = accountNumber?.Trim() ?? string.Empty;
        Shaba = shaba?.Trim() ?? string.Empty;
        CheckBook = checkBook?.Trim() ?? string.Empty;
        IssueDate = issueDate;
        DueDate = dueDate;
        Amount = amount;
        Status = CheckStatus.Received;
        RelatedCustomerId = relatedCustomerId;
        RelatedSupplierId = relatedSupplierId;
        RelatedDocumentId = relatedDocumentId;
        Notes = notes?.Trim() ?? string.Empty;
        CreatedAt = DateTime.UtcNow;
        CreatedBy = createdBy;
        IsActive = true;
    }

    public void UpdateStatus(CheckStatus newStatus)
    {
        Status = newStatus;
        if (newStatus == CheckStatus.Settled || newStatus == CheckStatus.Collected || newStatus == CheckStatus.Cancelled)
        {
            SettlementDate = DateTime.UtcNow;
        }
    }

    public void Endorse(string note)
    {
        IsEndorsed = true;
        EndorsementNote = note?.Trim() ?? string.Empty;
    }

    public void Deactivate() => IsActive = false;
    public void Activate() => IsActive = true;
}
