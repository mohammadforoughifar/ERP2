using System;
using System.Collections.Generic;

namespace ERP.Domain.Entities.Treasury;

/// <summary>
/// Bank Reconciliation — Phase 4 Treasury
/// Per proposal: Bank Reconciliation between bank statement and transactions
/// </summary>
public class BankReconciliation
{
    public int Id { get; private set; }
    public int? CompanyId { get; private set; }
    public int BankAccountId { get; private set; }
    public DateTime ReconciliationDate { get; private set; }
    public DateTime StatementStartDate { get; private set; }
    public DateTime StatementEndDate { get; private set; }
    public decimal StatementBalance { get; private set; }         // مانده طبق بانک
    public decimal SystemBalance { get; private set; }             // مانده طبق سیستم
    public decimal Difference { get; private set; }
    public bool IsReconciled { get; private set; } = false;
    public bool IsActive { get; private set; } = true;
    public DateTime CreatedAt { get; private set; }
    public string CreatedBy { get; private set; } = string.Empty;

    private readonly List<BankReconciliationLine> _lines = new();
    public IReadOnlyCollection<BankReconciliationLine> Lines => _lines.AsReadOnly();

    private BankReconciliation() { }

    public BankReconciliation(
        int? companyId,
        int bankAccountId,
        DateTime reconciliationDate,
        DateTime statementStartDate,
        DateTime statementEndDate,
        decimal statementBalance,
        decimal systemBalance,
        string createdBy)
    {
        if (companyId == null || companyId <= 0) throw new ArgumentException("Company required", nameof(companyId));
        if (bankAccountId <= 0) throw new ArgumentException("Bank account required");

        CompanyId = companyId;
        BankAccountId = bankAccountId;
        ReconciliationDate = reconciliationDate;
        StatementStartDate = statementStartDate;
        StatementEndDate = statementEndDate;
        StatementBalance = statementBalance;
        SystemBalance = systemBalance;
        Difference = statementBalance - systemBalance;
        CreatedAt = DateTime.UtcNow;
        CreatedBy = createdBy;
        IsActive = true;
    }

    public void AddLine(BankReconciliationLine line)
    {
        if (IsReconciled) throw new InvalidOperationException("Cannot add line to reconciled statement");
        _lines.Add(line);
    }

    public void CompleteReconciliation()
    {
        if (Difference != 0) throw new InvalidOperationException("Reconciliation not balanced");
        IsReconciled = true;
    }

    public void Deactivate() => IsActive = false;
    public void Activate() => IsActive = true;
}

public class BankReconciliationLine
{
    public int Id { get; private set; }
    public int BankReconciliationId { get; private set; }
    public int? PaymentId { get; private set; }
    public int? CheckId { get; private set; }
    public string Description { get; private set; } = string.Empty;
    public decimal StatementAmount { get; private set; }         // مبلغ طبق بانک
    public decimal SystemAmount { get; private set; }               // مبلغ طبق سیستم
    public bool IsMatched { get; private set; } = false;

    private BankReconciliationLine() { }

    public BankReconciliationLine(
        int bankReconciliationId,
        int? paymentId,
        int? checkId,
        string description,
        decimal statementAmount,
        decimal systemAmount)
    {
        BankReconciliationId = bankReconciliationId;
        PaymentId = paymentId;
        CheckId = checkId;
        Description = description?.Trim() ?? string.Empty;
        StatementAmount = statementAmount;
        SystemAmount = systemAmount;
        IsMatched = statementAmount == systemAmount;
    }
}
