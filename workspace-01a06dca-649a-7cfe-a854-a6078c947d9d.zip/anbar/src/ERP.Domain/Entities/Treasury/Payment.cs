using System;

namespace ERP.Domain.Entities.Treasury;

/// <summary>
/// Payment — Phase 4 Treasury
/// Per proposal: Receipt / Payment for Cash, Bank, Check settlement
/// </summary>
public enum PaymentType
{
    Receipt = 1,     // دریافت
    Payment = 2      // پرداخت
}

public class Payment
{
    public int Id { get; private set; }
    public int? CompanyId { get; private set; }
    public int? BranchId { get; private set; }
    public string DocumentNumber { get; private set; } = string.Empty;
    public PaymentType Type { get; private set; }
    public DateTime PaymentDate { get; private set; }
    public int? CashAccountId { get; private set; }
    public int? BankAccountId { get; private set; }
    public int? CheckId { get; private set; }
    public int? RelatedCustomerId { get; private set; }
    public int? RelatedSupplierId { get; private set; }
    public decimal Amount { get; private set; }
    public string CurrencyCode { get; private set; } = "IRR";
    public string Description { get; private set; } = string.Empty;
    public bool IsReconciled { get; private set; } = false;
    public bool IsActive { get; private set; } = true;
    public DateTime CreatedAt { get; private set; }
    public string CreatedBy { get; private set; } = string.Empty;

    private Payment() { }

    public Payment(
        int? companyId,
        int? branchId,
        string documentNumber,
        PaymentType type,
        DateTime paymentDate,
        int? cashAccountId,
        int? bankAccountId,
        int? checkId,
        int? relatedCustomerId,
        int? relatedSupplierId,
        decimal amount,
        string currencyCode,
        string description,
        string createdBy)
    {
        if (companyId == null || companyId <= 0) throw new ArgumentException("Company required", nameof(companyId));
        if (string.IsNullOrWhiteSpace(documentNumber)) throw new ArgumentException("Document number required");
        if (amount <= 0) throw new ArgumentException("Amount must be positive");

        CompanyId = companyId;
        BranchId = branchId;
        DocumentNumber = documentNumber.Trim();
        Type = type;
        PaymentDate = paymentDate;
        CashAccountId = cashAccountId;
        BankAccountId = bankAccountId;
        CheckId = checkId;
        RelatedCustomerId = relatedCustomerId;
        RelatedSupplierId = relatedSupplierId;
        Amount = amount;
        CurrencyCode = currencyCode?.Trim() ?? "IRR";
        Description = description?.Trim() ?? string.Empty;
        CreatedAt = DateTime.UtcNow;
        CreatedBy = createdBy;
        IsActive = true;
    }

    public void MarkReconciled() => IsReconciled = true;
    public void Deactivate() => IsActive = false;
    public void Activate() => IsActive = true;
}
