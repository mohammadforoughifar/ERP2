using System;

namespace ERP.Domain.Entities.Treasury;

/// <summary>
/// Bank Account — Phase 4 Treasury
/// Per proposal: Bank Reconciliation base, Bank, Branch, Account Number, Shaba
/// </summary>
public class BankAccount
{
    public int Id { get; private set; }
    public int? CompanyId { get; private set; }
    public int? BranchId { get; private set; }
    public string BankName { get; private set; } = string.Empty;       // نام بانک
    public string BankBranch { get; private set; } = string.Empty;     // شعبه بانک
    public string AccountNumber { get; private set; } = string.Empty;  // شماره حساب
    public string Shaba { get; private set; } = string.Empty;           // شماره شبا
    public string CurrencyCode { get; private set; } = "IRR";
    public decimal OpeningBalance { get; private set; }
    public bool IsActive { get; private set; } = true;
    public DateTime CreatedAt { get; private set; }
    public string CreatedBy { get; private set; } = string.Empty;

    private BankAccount() { }

    public BankAccount(
        int? companyId,
        int? branchId,
        string bankName,
        string bankBranch,
        string accountNumber,
        string shaba,
        string currencyCode,
        decimal openingBalance,
        string createdBy)
    {
        if (companyId == null || companyId <= 0) throw new ArgumentException("Company required", nameof(companyId));
        if (string.IsNullOrWhiteSpace(bankName)) throw new ArgumentException("Bank name required");
        if (string.IsNullOrWhiteSpace(accountNumber)) throw new ArgumentException("Account number required");

        CompanyId = companyId;
        BranchId = branchId;
        BankName = bankName.Trim();
        BankBranch = bankBranch?.Trim() ?? string.Empty;
        AccountNumber = accountNumber.Trim();
        Shaba = shaba?.Trim() ?? string.Empty;
        CurrencyCode = currencyCode?.Trim() ?? "IRR";
        OpeningBalance = openingBalance >= 0 ? openingBalance : 0;
        CreatedAt = DateTime.UtcNow;
        CreatedBy = createdBy;
        IsActive = true;
    }

    public void UpdateProfile(string bankName, string bankBranch, string accountNumber, string shaba, decimal openingBalance)
    {
        BankName = bankName.Trim();
        BankBranch = bankBranch?.Trim() ?? string.Empty;
        AccountNumber = accountNumber.Trim();
        Shaba = shaba?.Trim() ?? string.Empty;
        if (openingBalance >= 0) OpeningBalance = openingBalance;
    }

    public void Deactivate() => IsActive = false;
    public void Activate() => IsActive = true;
}
