using System;

namespace ERP.Domain.Entities.Treasury;

/// <summary>
/// Cash Account — Phase 4 Treasury
/// Per proposal: Cash, Cash Flow, Transfer base
/// </summary>
public class CashAccount
{
    public int Id { get; private set; }
    public int? CompanyId { get; private set; }
    public int? BranchId { get; private set; }
    public string Code { get; private set; } = string.Empty;
    public string Name { get; private set; } = string.Empty;
    public string CurrencyCode { get; private set; } = "IRR";
    public decimal OpeningBalance { get; private set; }
    public bool IsActive { get; private set; } = true;
    public DateTime CreatedAt { get; private set; }
    public string CreatedBy { get; private set; } = string.Empty;

    private CashAccount() { }

    public CashAccount(int? companyId, int? branchId, string code, string name, string currencyCode, decimal openingBalance, string createdBy)
    {
        if (companyId == null || companyId <= 0) throw new ArgumentException("Company required", nameof(companyId));
        if (string.IsNullOrWhiteSpace(code)) throw new ArgumentException("Cash account code required");
        if (string.IsNullOrWhiteSpace(name)) throw new ArgumentException("Cash account name required");

        CompanyId = companyId;
        BranchId = branchId;
        Code = code.Trim();
        Name = name.Trim();
        CurrencyCode = currencyCode?.Trim() ?? "IRR";
        OpeningBalance = openingBalance >= 0 ? openingBalance : 0;
        CreatedAt = DateTime.UtcNow;
        CreatedBy = createdBy;
        IsActive = true;
    }

    public void UpdateProfile(string name, decimal openingBalance)
    {
        Name = name.Trim();
        if (openingBalance >= 0) OpeningBalance = openingBalance;
    }

    public void Deactivate() => IsActive = false;
    public void Activate() => IsActive = true;
}
