using System;

namespace ERP.Domain.Entities.Production;

/// <summary>
/// Production Cost — Phase 9 Production
/// Per proposal: Material Cost, Labor Cost, Machine Cost, Overhead, Production Cost,
/// Standard Cost, Actual Cost, Variance
/// </summary>
public class ProductionCost
{
    public int Id { get; private set; }
    public int? CompanyId { get; private set; }
    public int ProductionOrderId { get; private set; }
    public decimal MaterialCost { get; private set; }
    public decimal LaborCost { get; private set; }
    public decimal MachineCost { get; private set; }
    public decimal OverheadCost { get; private set; }
    public decimal ActualTotalCost { get; private set; }
    public decimal StandardTotalCost { get; private set; }
    public decimal Variance { get; private set; }
    public string CostStatus { get; private set; } = "Calculated"; // Calculated, Confirmed, Adjusted
    public bool IsActive { get; private set; } = true;
    public DateTime CreatedAt { get; private set; }
    public string CreatedBy { get; private set; } = string.Empty;

    private ProductionCost() { }

    public ProductionCost(
        int? companyId,
        int productionOrderId,
        decimal materialCost,
        decimal laborCost,
        decimal machineCost,
        decimal overheadCost,
        decimal standardTotalCost,
        string createdBy)
    {
        if (companyId == null || companyId <= 0) throw new ArgumentException("Company required", nameof(companyId));
        if (productionOrderId <= 0) throw new ArgumentException("Production order required");
        if (materialCost < 0 || laborCost < 0 || machineCost < 0 || overheadCost < 0) throw new ArgumentException("Costs must be non-negative");
        if (standardTotalCost < 0) throw new ArgumentException("Standard cost must be non-negative");

        CompanyId = companyId;
        ProductionOrderId = productionOrderId;
        MaterialCost = materialCost;
        LaborCost = laborCost;
        MachineCost = machineCost;
        OverheadCost = overheadCost;
        ActualTotalCost = materialCost + laborCost + machineCost + overheadCost;
        StandardTotalCost = standardTotalCost;
        Variance = ActualTotalCost - StandardTotalCost;
        CostStatus = "Calculated";
        CreatedAt = DateTime.UtcNow;
        CreatedBy = createdBy;
        IsActive = true;
    }

    public void Confirm() => CostStatus = "Confirmed";
    public void Adjust(decimal newMaterial, decimal newLabor, decimal newMachine, decimal newOverhead, decimal newStandard)
    {
        if (newMaterial < 0 || newLabor < 0 || newMachine < 0 || newOverhead < 0) throw new ArgumentException("Costs must be non-negative");
        MaterialCost = newMaterial;
        LaborCost = newLabor;
        MachineCost = newMachine;
        OverheadCost = newOverhead;
        ActualTotalCost = newMaterial + newLabor + newMachine + newOverhead;
        StandardTotalCost = newStandard >= 0 ? newStandard : StandardTotalCost;
        Variance = ActualTotalCost - StandardTotalCost;
        CostStatus = "Adjusted";
    }

    public void Deactivate() => IsActive = false;
    public void Activate() => IsActive = true;
}
