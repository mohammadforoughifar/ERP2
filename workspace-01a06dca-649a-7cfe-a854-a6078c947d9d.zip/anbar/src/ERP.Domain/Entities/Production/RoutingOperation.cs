using System;

namespace ERP.Domain.Entities.Production;

/// <summary>
/// Routing Operation — Phase 9 Production
/// Per proposal: Operation details: Work Center, Machine, Operation, Time, Cost
/// </summary>
public class RoutingOperation
{
    public int Id { get; private set; }
    public int RoutingId { get; private set; }
    public int WorkCenterId { get; private set; }
    public int Sequence { get; private set; }             // Operation sequence (1, 2, 3, ...)
    public string OperationName { get; private set; } = string.Empty;
    public decimal StandardTime { get; private set; }     // Standard time in minutes/hours
    public decimal StandardCost { get; private set; }     // Standard cost per operation
    public string Description { get; private set; } = string.Empty;

    public Routing? Routing { get; private set; }

    private RoutingOperation() { }

    public RoutingOperation(
        int routingId,
        int workCenterId,
        int sequence,
        string operationName,
        decimal standardTime,
        decimal standardCost,
        string description)
    {
        if (routingId <= 0) throw new ArgumentException("Routing required");
        if (workCenterId <= 0) throw new ArgumentException("Work center required");
        if (sequence <= 0) throw new ArgumentException("Sequence must be positive");
        if (string.IsNullOrWhiteSpace(operationName)) throw new ArgumentException("Operation name required");
        if (standardTime < 0) throw new ArgumentException("Standard time must be non-negative");
        if (standardCost < 0) throw new ArgumentException("Standard cost must be non-negative");

        RoutingId = routingId;
        WorkCenterId = workCenterId;
        Sequence = sequence;
        OperationName = operationName.Trim();
        StandardTime = standardTime;
        StandardCost = standardCost;
        Description = description?.Trim() ?? string.Empty;
    }

    public void UpdateTimeAndCost(decimal standardTime, decimal standardCost)
    {
        if (standardTime < 0) throw new ArgumentException("Standard time must be non-negative");
        if (standardCost < 0) throw new ArgumentException("Standard cost must be non-negative");
        StandardTime = standardTime;
        StandardCost = standardCost;
    }
}
