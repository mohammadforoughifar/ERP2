using System;

namespace ERP.Domain.Entities.Production;

/// <summary>
/// BOM Line — Phase 9 Production
/// Per proposal: Multi-Level BOM component (Raw Material, Semi-Finished)
/// </summary>
public class BOMLine
{
    public int Id { get; private set; }
    public int BOMId { get; private set; }
    public int ComponentProductId { get; private set; }         // Component (Raw Material / Semi-Finished)
    public int ComponentQuantity { get; private set; }
    public decimal ComponentUnitCost { get; private set; }        // Standard / Actual cost
    public int? ComponentBatchId { get; private set; }
    public int OperationSequence { get; private set; }           // Sequence in BOM

    public BOM? BOM { get; private set; }

    private BOMLine() { }

    public BOMLine(
        int bomId,
        int componentProductId,
        int componentQuantity,
        decimal componentUnitCost,
        int operationSequence,
        int? componentBatchId = null)
    {
        if (bomId <= 0) throw new ArgumentException("BOM required");
        if (componentProductId <= 0) throw new ArgumentException("Component product required");
        if (componentQuantity <= 0) throw new ArgumentException("Component quantity must be positive");
        if (componentUnitCost < 0) throw new ArgumentException("Component cost must be non-negative");

        BOMId = bomId;
        ComponentProductId = componentProductId;
        ComponentQuantity = componentQuantity;
        ComponentUnitCost = componentUnitCost;
        OperationSequence = operationSequence > 0 ? operationSequence : 1;
        ComponentBatchId = componentBatchId;
    }

    public void UpdateQuantityAndCost(int quantity, decimal cost)
    {
        if (quantity <= 0) throw new ArgumentException("Quantity must be positive");
        if (cost < 0) throw new ArgumentException("Cost must be non-negative");
        ComponentQuantity = quantity;
        ComponentUnitCost = cost;
    }
}
