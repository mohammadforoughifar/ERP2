using System;

namespace ERP.Domain.Entities.Production;

/// <summary>
/// Production Order — Phase 9 Production
/// Per proposal: Production Order, Material Issue, Product Receipt, Scrap, By-Product, Rework, Subcontracting
/// </summary>
public class ProductionOrder
{
    public int Id { get; private set; }
    public int? CompanyId { get; private set; }
    public int? BranchId { get; private set; }
    public int ProductId { get; private set; }              // Product being produced
    public int? BOMId { get; private set; }
    public int? RoutingId { get; private set; }
    public string ProductionNumber { get; private set; } = string.Empty;
    public DateTime PlannedStartDate { get; private set; }
    public DateTime PlannedEndDate { get; private set; }
    public int PlannedQuantity { get; private set; }
    public int ActualQuantity { get; private set; }        // Actual produced quantity
    public string Status { get; private set; } = "Draft";   // Draft, Confirmed, InProgress, Completed, Cancelled
    public bool IsActive { get; private set; } = true;
    public DateTime CreatedAt { get; private set; }
    public string CreatedBy { get; private set; } = string.Empty;

    private ProductionOrder() { }

    public ProductionOrder(
        int? companyId,
        int? branchId,
        int productId,
        int? bomId,
        int? routingId,
        string productionNumber,
        DateTime plannedStartDate,
        DateTime plannedEndDate,
        int plannedQuantity,
        string createdBy)
    {
        if (companyId == null || companyId <= 0) throw new ArgumentException("Company required", nameof(companyId));
        if (productId <= 0) throw new ArgumentException("Product required", nameof(productId));
        if (string.IsNullOrWhiteSpace(productionNumber)) throw new ArgumentException("Production number required");
        if (plannedQuantity <= 0) throw new ArgumentException("Planned quantity must be positive");

        CompanyId = companyId;
        BranchId = branchId;
        ProductId = productId;
        BOMId = bomId;
        RoutingId = routingId;
        ProductionNumber = productionNumber.Trim();
        PlannedStartDate = plannedStartDate;
        PlannedEndDate = plannedEndDate;
        PlannedQuantity = plannedQuantity;
        ActualQuantity = 0;
        Status = "Draft";
        CreatedAt = DateTime.UtcNow;
        CreatedBy = createdBy;
        IsActive = true;
    }

    public void Confirm() => Status = "Confirmed";
    public void Start() => Status = "InProgress";
    public void Complete(int actualQuantity)
    {
        if (actualQuantity < 0) throw new ArgumentException("Actual quantity must be non-negative");
        ActualQuantity = actualQuantity;
        Status = "Completed";
    }

    public void Cancel() => Status = "Cancelled";
    public void Deactivate() => IsActive = false;
    public void Activate() => IsActive = true;
}
