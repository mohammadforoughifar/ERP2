using System;

namespace ERP.Domain.Entities.Production;

/// <summary>
/// BOM (Bill of Materials) — Phase 9 Production
/// Per proposal: Multi-Level BOM, BOM for Finished Product, Raw Material, Semi-Finished
/// </summary>
public class BOM
{
    public int Id { get; private set; }
    public int? CompanyId { get; private set; }
    public int ProductId { get; private set; }              // Finished / Semi-Finished Product
    public int? ParentBOMId { get; private set; }           // For multi-level BOM
    public int Level { get; private set; }                  // BOM level (1, 2, 3, ...)
    public string BOMNumber { get; private set; } = string.Empty;
    public string Description { get; private set; } = string.Empty;
    public decimal Quantity { get; private set; }           // Base quantity for BOM
    public bool IsActive { get; private set; } = true;
    public DateTime CreatedAt { get; private set; }
    public string CreatedBy { get; private set; } = string.Empty;

    private BOM() { }

    public BOM(
        int? companyId,
        int productId,
        int? parentBOMId,
        int level,
        string bomNumber,
        string description,
        decimal quantity,
        string createdBy)
    {
        if (companyId == null || companyId <= 0) throw new ArgumentException("Company required", nameof(companyId));
        if (productId <= 0) throw new ArgumentException("Product required", nameof(productId));
        if (string.IsNullOrWhiteSpace(bomNumber)) throw new ArgumentException("BOM number required");
        if (level < 1) throw new ArgumentException("Level must be positive");
        if (quantity <= 0) throw new ArgumentException("Quantity must be positive");

        CompanyId = companyId;
        ProductId = productId;
        ParentBOMId = parentBOMId;
        Level = level;
        BOMNumber = bomNumber.Trim();
        Description = description?.Trim() ?? string.Empty;
        Quantity = quantity;
        CreatedAt = DateTime.UtcNow;
        CreatedBy = createdBy;
        IsActive = true;
    }

    public void UpdateProfile(string description, decimal quantity)
    {
        Description = description?.Trim() ?? string.Empty;
        if (quantity > 0) Quantity = quantity;
    }

    public void Deactivate() => IsActive = false;
    public void Activate() => IsActive = true;
}
