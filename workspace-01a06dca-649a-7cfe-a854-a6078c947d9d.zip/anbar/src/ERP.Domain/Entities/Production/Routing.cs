using System;

namespace ERP.Domain.Entities.Production;

/// <summary>
/// Routing — Phase 9 Production
/// Per proposal: Routing steps for production: Work Center → Operation sequence
/// </summary>
public class Routing
{
    public int Id { get; private set; }
    public int? CompanyId { get; private set; }
    public int ProductId { get; private set; }              // Product being produced
    public string RoutingNumber { get; private set; } = string.Empty;
    public string Description { get; private set; } = string.Empty;
    public bool IsActive { get; private set; } = true;
    public DateTime CreatedAt { get; private set; }
    public string CreatedBy { get; private set; } = string.Empty;

    private Routing() { }

    public Routing(
        int? companyId,
        int productId,
        string routingNumber,
        string description,
        string createdBy)
    {
        if (companyId == null || companyId <= 0) throw new ArgumentException("Company required", nameof(companyId));
        if (productId <= 0) throw new ArgumentException("Product required", nameof(productId));
        if (string.IsNullOrWhiteSpace(routingNumber)) throw new ArgumentException("Routing number required");

        CompanyId = companyId;
        ProductId = productId;
        RoutingNumber = routingNumber.Trim();
        Description = description?.Trim() ?? string.Empty;
        CreatedAt = DateTime.UtcNow;
        CreatedBy = createdBy;
        IsActive = true;
    }

    public void UpdateProfile(string description)
    {
        Description = description?.Trim() ?? string.Empty;
    }

    public void Deactivate() => IsActive = false;
    public void Activate() => IsActive = true;
}
