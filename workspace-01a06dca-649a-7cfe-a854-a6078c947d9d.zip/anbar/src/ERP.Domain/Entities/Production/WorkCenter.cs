using System;

namespace ERP.Domain.Entities.Production;

/// <summary>
/// Work Center / Machine — Phase 9 Production
/// Per proposal: Work Center, Machine, Capacity, Operation
/// </summary>
public class WorkCenter
{
    public int Id { get; private set; }
    public int? CompanyId { get; private set; }
    public string Code { get; private set; } = string.Empty;
    public string Name { get; private set; } = string.Empty;
    public string Type { get; private set; } = string.Empty;        // Machine, Work Center, Assembly Line
    public decimal CapacityPerHour { get; private set; }             // Capacity (units/hour)
    public bool IsActive { get; private set; } = true;
    public DateTime CreatedAt { get; private set; }
    public string CreatedBy { get; private set; } = string.Empty;

    private WorkCenter() { }

    public WorkCenter(
        int? companyId,
        string code,
        string name,
        string type,
        decimal capacityPerHour,
        string createdBy)
    {
        if (companyId == null || companyId <= 0) throw new ArgumentException("Company required", nameof(companyId));
        if (string.IsNullOrWhiteSpace(code)) throw new ArgumentException("Work center code required");
        if (string.IsNullOrWhiteSpace(name)) throw new ArgumentException("Work center name required");

        CompanyId = companyId;
        Code = code.Trim();
        Name = name.Trim();
        Type = type?.Trim() ?? string.Empty;
        CapacityPerHour = capacityPerHour >= 0 ? capacityPerHour : 0;
        CreatedAt = DateTime.UtcNow;
        CreatedBy = createdBy;
        IsActive = true;
    }

    public void UpdateProfile(string name, string type, decimal capacityPerHour)
    {
        Name = name.Trim();
        Type = type?.Trim() ?? string.Empty;
        if (capacityPerHour >= 0) CapacityPerHour = capacityPerHour;
    }

    public void Deactivate() => IsActive = false;
    public void Activate() => IsActive = true;
}
