using System;

namespace ERP.Domain.Entities.Production;

/// <summary>
/// Production Order Line — Phase 9 Production
/// Per proposal: Material Issue (Raw Material consumption) and Product Receipt tracking
/// </summary>
public enum ProductionLineType
{
    MaterialIssue = 1,      // مصرف مواد اولیه
    ProductReceipt = 2,     // دریافت محصول تولید شده
    Scrap = 3,               // ضایعات
    Rework = 4              // بازکاری
}

public class ProductionOrderLine
{
    public int Id { get; private set; }
    public int ProductionOrderId { get; private set; }
    public int ProductId { get; private set; }              // Material or Produced Product
    public ProductionLineType LineType { get; private set; }
    public int PlannedQuantity { get; private set; }
    public int ActualQuantity { get; private set; }         // Actual quantity issued/received
    public int? BatchId { get; private set; }
    public int? SerialId { get; private set; }
    public int WarehouseId { get; private set; }

    public ProductionOrder? ProductionOrder { get; private set; }

    private ProductionOrderLine() { }

    public ProductionOrderLine(
        int productionOrderId,
        int productId,
        ProductionLineType lineType,
        int plannedQuantity,
        int warehouseId,
        int? batchId = null,
        int? serialId = null)
    {
        if (productionOrderId <= 0) throw new ArgumentException("Production order required");
        if (productId <= 0) throw new ArgumentException("Product required");
        if (plannedQuantity <= 0) throw new ArgumentException("Planned quantity must be positive");
        if (warehouseId <= 0) throw new ArgumentException("Warehouse required");

        ProductionOrderId = productionOrderId;
        ProductId = productId;
        LineType = lineType;
        PlannedQuantity = plannedQuantity;
        ActualQuantity = 0;
        BatchId = batchId;
        SerialId = serialId;
        WarehouseId = warehouseId;
    }

    public void UpdateActualQuantity(int actualQuantity)
    {
        if (actualQuantity < 0) throw new ArgumentException("Actual quantity must be non-negative");
        ActualQuantity = actualQuantity;
    }
}
