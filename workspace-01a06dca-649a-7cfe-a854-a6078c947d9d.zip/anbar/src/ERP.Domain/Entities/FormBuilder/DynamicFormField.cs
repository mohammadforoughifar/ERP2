using System;
using System.ComponentModel.DataAnnotations;

namespace ERP.Domain.Entities.FormBuilder;

public class DynamicFormField
{
    [Key]
    public int Id { get; set; }

    [Required]
    public int DynamicFormId { get; set; }

    [Required]
    [StringLength(150)]
    public string FieldName { get; set; } = string.Empty;

    [Required]
    [StringLength(50)]
    public string FieldType { get; set; } = string.Empty;

    [StringLength(200)]
    public string Label { get; set; } = string.Empty;

    [StringLength(500)]
    public string? Placeholder { get; set; }

    [StringLength(2000)]
    public string? DefaultValue { get; set; }

    [StringLength(2000)]
    public string? Options { get; set; }

    public int SortOrder { get; set; } = 0;

    public bool IsRequired { get; set; } = false;
    public bool IsVisible { get; set; } = true;
    public bool IsDisabled { get; set; } = false;
    public bool IsReadonly { get; set; } = false;

    [StringLength(500)]
    public string? ValidationRule { get; set; }

    public int? DependencyFieldId { get; set; }

    [StringLength(50)]
    public string? DependencyCondition { get; set; }

    public int CompanyId { get; set; }
    public int BranchId { get; set; }
    public int TenantId { get; set; }

    [StringLength(100)]
    public string CreatedBy { get; set; } = string.Empty;

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    [StringLength(100)]
    public string? ModifiedBy { get; set; }

    public DateTime? ModifiedAt { get; set; }

    public bool IsActive { get; set; } = true;
}
