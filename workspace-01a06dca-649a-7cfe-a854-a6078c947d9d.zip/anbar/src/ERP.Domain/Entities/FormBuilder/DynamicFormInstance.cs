using System;
using System.ComponentModel.DataAnnotations;

namespace ERP.Domain.Entities.FormBuilder;

public class DynamicFormInstance
{
    [Key]
    public int Id { get; set; }

    [Required]
    public int DynamicFormId { get; set; }

    [StringLength(100)]
    public string InstanceCode { get; set; } = string.Empty;

    [StringLength(50)]
    public string Status { get; set; } = "Draft";

    public int CompanyId { get; set; }
    public int BranchId { get; set; }
    public int TenantId { get; set; }

    [StringLength(100)]
    public string CreatedBy { get; set; } = string.Empty;

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    [StringLength(100)]
    public string? ModifiedBy { get; set; }

    public DateTime? ModifiedAt { get; set; }

    public bool IsActive { get; set; } = true;
}
