using System;
using System.ComponentModel.DataAnnotations;

namespace ERP.Domain.Entities.FormBuilder;

public class DynamicFormFieldValue
{
    [Key]
    public int Id { get; set; }

    [Required]
    public int DynamicFormInstanceId { get; set; }

    [Required]
    public int DynamicFormFieldId { get; set; }

    [StringLength(150)]
    public string FieldName { get; set; } = string.Empty;

    [StringLength(4000)]
    public string? ValueString { get; set; }

    [StringLength(4000)]
    public string? ValueText { get; set; }

    public int CompanyId { get; set; }
    public int BranchId { get; set; }
    public int TenantId { get; set; }

    [StringLength(100)]
    public string CreatedBy { get; set; } = string.Empty;

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    [StringLength(100)]
    public string? ModifiedBy { get; set; }

    public DateTime? ModifiedAt { get; set; }

    public bool IsActive { get; set; } = true;
}
