using System;

namespace ERP.Domain.Entities.Purchasing;

/// <summary>
/// Goods Receipt Line — Phase 6 Purchasing
/// Per proposal: Partial receipt tracking against Purchase Order Line
/// </summary>
public class GoodsReceiptLine
{
    public int Id { get; private set; }
    public int GoodsReceiptId { get; private set; }
    public int PurchaseOrderLineId { get; private set; }
    public int ProductId { get; private set; }
    public int ReceivedQuantity { get; private set; }
    public int WarehouseId { get; private set; }

    public GoodsReceipt? GoodsReceipt { get; private set; }

    private GoodsReceiptLine() { }

    public GoodsReceiptLine(
        int goodsReceiptId,
        int purchaseOrderLineId,
        int productId,
        int receivedQuantity,
        int warehouseId)
    {
        if (goodsReceiptId <= 0) throw new ArgumentException("Goods receipt required");
        if (purchaseOrderLineId <= 0) throw new ArgumentException("Purchase order line required");
        if (productId <= 0) throw new ArgumentException("Product required");
        if (receivedQuantity <= 0) throw new ArgumentException("Received quantity must be positive");
        if (warehouseId <= 0) throw new ArgumentException("Warehouse required");

        GoodsReceiptId = goodsReceiptId;
        PurchaseOrderLineId = purchaseOrderLineId;
        ProductId = productId;
        ReceivedQuantity = receivedQuantity;
        WarehouseId = warehouseId;
    }

    public void UpdateReceivedQuantity(int receivedQuantity)
    {
        if (receivedQuantity <= 0) throw new ArgumentException("Received quantity must be positive");
        ReceivedQuantity = receivedQuantity;
    }
}
