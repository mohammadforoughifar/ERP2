using System;

namespace ERP.Domain.Entities.Purchasing;

/// <summary>
/// Purchase Invoice Line — Phase 6 Purchasing
/// Per proposal: Tax per line, Product reference, Discount
/// </summary>
public class PurchaseInvoiceLine
{
    public int Id { get; private set; }
    public int PurchaseInvoiceId { get; private set; }
    public int GoodsReceiptLineId { get; private set; }
    public int ProductId { get; private set; }
    public int Quantity { get; private set; }
    public decimal UnitPrice { get; private set; }
    public decimal DiscountPercent { get; private set; }
    public decimal LineSubTotal { get; private set; }
    public decimal LineTaxAmount { get; private set; }
    public decimal LineTotal { get; private set; }

    public PurchaseInvoice? PurchaseInvoice { get; private set; }

    private PurchaseInvoiceLine() { }

    public PurchaseInvoiceLine(
        int purchaseInvoiceId,
        int goodsReceiptLineId,
        int productId,
        int quantity,
        decimal unitPrice,
        decimal discountPercent = 0,
        decimal taxRate = 0.09m)
    {
        if (purchaseInvoiceId <= 0) throw new ArgumentException("Purchase invoice required");
        if (goodsReceiptLineId <= 0) throw new ArgumentException("Goods receipt line required");
        if (productId <= 0) throw new ArgumentException("Product required");
        if (quantity <= 0) throw new ArgumentException("Quantity must be positive");
        if (unitPrice < 0) throw new ArgumentException("Unit price must be non-negative");

        PurchaseInvoiceId = purchaseInvoiceId;
        GoodsReceiptLineId = goodsReceiptLineId;
        ProductId = productId;
        Quantity = quantity;
        UnitPrice = unitPrice;
        DiscountPercent = discountPercent >= 0 && discountPercent <= 100 ? discountPercent : 0;
        LineSubTotal = (Quantity * UnitPrice) - ((Quantity * UnitPrice) * (DiscountPercent / 100));
        LineTaxAmount = LineSubTotal * (taxRate >= 0 ? taxRate : 0);
        LineTotal = LineSubTotal + LineTaxAmount;
    }
}
