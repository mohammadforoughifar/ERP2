using System;

namespace ERP.Domain.Entities.Purchasing;

/// <summary>
/// Purchase Invoice — Phase 6 Purchasing
/// Per proposal: Purchase Invoice linked to Purchase Order / Goods Receipt
/// Accounting Entry linkage (Debit Inventory / Credit AP)
/// </summary>
public class PurchaseInvoice
{
    public int Id { get; private set; }
    public int? CompanyId { get; private set; }
    public int SupplierId { get; private set; }
    public int? PurchaseOrderId { get; private set; }
    public int? GoodsReceiptId { get; private set; }
    public string InvoiceNumber { get; private set; } = string.Empty;
    public DateTime InvoiceDate { get; private set; }
    public DateTime DueDate { get; private set; }
    public decimal SubTotal { get; private set; }
    public decimal TaxAmount { get; private set; }
    public decimal DiscountAmount { get; private set; }
    public decimal TotalAmount { get; private set; }
    public string Status { get; private set; } = "Draft"; // Draft, Confirmed, Posted, Paid, Cancelled, Reversed
    public bool IsPosted { get; private set; } = false;
    public int? AccountingEntryId { get; private set; }
    public bool IsActive { get; private set; } = true;
    public DateTime CreatedAt { get; private set; }
    public string CreatedBy { get; private set; } = string.Empty;

    private PurchaseInvoice() { }

    public PurchaseInvoice(
        int? companyId,
        int supplierId,
        int? purchaseOrderId,
        int? goodsReceiptId,
        string invoiceNumber,
        DateTime invoiceDate,
        DateTime dueDate,
        decimal subTotal,
        decimal taxAmount,
        decimal discountAmount,
        decimal totalAmount,
        string createdBy)
    {
        if (companyId == null || companyId <= 0) throw new ArgumentException("Company required", nameof(companyId));
        if (supplierId <= 0) throw new ArgumentException("Supplier required", nameof(supplierId));
        if (string.IsNullOrWhiteSpace(invoiceNumber)) throw new ArgumentException("Invoice number required");

        CompanyId = companyId;
        SupplierId = supplierId;
        PurchaseOrderId = purchaseOrderId;
        GoodsReceiptId = goodsReceiptId;
        InvoiceNumber = invoiceNumber.Trim();
        InvoiceDate = invoiceDate;
        DueDate = dueDate;
        SubTotal = subTotal >= 0 ? subTotal : 0;
        TaxAmount = taxAmount >= 0 ? taxAmount : 0;
        DiscountAmount = discountAmount >= 0 ? discountAmount : 0;
        TotalAmount = totalAmount >= 0 ? totalAmount : 0;
        Status = "Draft";
        CreatedAt = DateTime.UtcNow;
        CreatedBy = createdBy;
        IsActive = true;
    }

    public void Confirm() => Status = "Confirmed";
    public void Post(int accountingEntryId)
    {
        if (Status != "Confirmed") throw new InvalidOperationException("Invoice must be confirmed before posting");
        IsPosted = true;
        AccountingEntryId = accountingEntryId;
        Status = "Posted";
    }

    public void Pay() => Status = "Paid";
    public void Cancel() => Status = "Cancelled";
    public void Reverse() => Status = "Reversed";
    public void Deactivate() => IsActive = false;
    public void Activate() => IsActive = true;
}
