using System;

namespace ERP.Domain.Entities.Purchasing;

/// <summary>
/// Goods Receipt — Phase 6 Purchasing
/// Per proposal: Receipt of goods from Supplier against Purchase Order
/// Document Flow: Purchase Order → Goods Receipt → Purchase Invoice
/// </summary>
public class GoodsReceipt
{
    public int Id { get; private set; }
    public int? CompanyId { get; private set; }
    public int? BranchId { get; private set; }
    public int SupplierId { get; private set; }
    public int PurchaseOrderId { get; private set; }
    public string ReceiptNumber { get; private set; } = string.Empty;
    public DateTime ReceiptDate { get; private set; }
    public string Status { get; private set; } = "Draft"; // Draft, Confirmed, Completed, Cancelled
    public bool IsActive { get; private set; } = true;
    public DateTime CreatedAt { get; private set; }
    public string CreatedBy { get; private set; } = string.Empty;

    private GoodsReceipt() { }

    public GoodsReceipt(
        int? companyId,
        int? branchId,
        int supplierId,
        int purchaseOrderId,
        string receiptNumber,
        DateTime receiptDate,
        string createdBy)
    {
        if (companyId == null || companyId <= 0) throw new ArgumentException("Company required", nameof(companyId));
        if (supplierId <= 0) throw new ArgumentException("Supplier required", nameof(supplierId));
        if (purchaseOrderId <= 0) throw new ArgumentException("Purchase order required", nameof(purchaseOrderId));
        if (string.IsNullOrWhiteSpace(receiptNumber)) throw new ArgumentException("Receipt number required");

        CompanyId = companyId;
        BranchId = branchId;
        SupplierId = supplierId;
        PurchaseOrderId = purchaseOrderId;
        ReceiptNumber = receiptNumber.Trim();
        ReceiptDate = receiptDate;
        Status = "Draft";
        CreatedAt = DateTime.UtcNow;
        CreatedBy = createdBy;
        IsActive = true;
    }

    public void Confirm() => Status = "Confirmed";
    public void Complete() => Status = "Completed";
    public void Cancel() => Status = "Cancelled";
    public void Deactivate() => IsActive = false;
    public void Activate() => IsActive = true;
}
