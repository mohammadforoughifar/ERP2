using System;

namespace ERP.Domain.Entities.Purchasing;

/// <summary>
/// Purchase Return — Phase 6 Purchasing
/// Per proposal: Return goods to Supplier, linked to Purchase Order / Goods Receipt
/// </summary>
public class PurchaseReturn
{
    public int Id { get; private set; }
    public int? CompanyId { get; private set; }
    public int SupplierId { get; private set; }
    public int? PurchaseOrderId { get; private set; }
    public int? GoodsReceiptId { get; private set; }
    public string ReturnNumber { get; private set; } = string.Empty;
    public DateTime ReturnDate { get; private set; }
    public string Reason { get; private set; } = string.Empty;
    public string Status { get; private set; } = "Draft"; // Draft, Confirmed, Completed, Cancelled
    public bool IsActive { get; private set; } = true;
    public DateTime CreatedAt { get; private set; }
    public string CreatedBy { get; private set; } = string.Empty;

    private PurchaseReturn() { }

    public PurchaseReturn(
        int? companyId,
        int supplierId,
        int? purchaseOrderId,
        int? goodsReceiptId,
        string returnNumber,
        DateTime returnDate,
        string reason,
        string createdBy)
    {
        if (companyId == null || companyId <= 0) throw new ArgumentException("Company required", nameof(companyId));
        if (supplierId <= 0) throw new ArgumentException("Supplier required", nameof(supplierId));
        if (string.IsNullOrWhiteSpace(returnNumber)) throw new ArgumentException("Return number required");

        CompanyId = companyId;
        SupplierId = supplierId;
        PurchaseOrderId = purchaseOrderId;
        GoodsReceiptId = goodsReceiptId;
        ReturnNumber = returnNumber.Trim();
        ReturnDate = returnDate;
        Reason = reason?.Trim() ?? string.Empty;
        Status = "Draft";
        CreatedAt = DateTime.UtcNow;
        CreatedBy = createdBy;
        IsActive = true;
    }

    public void Confirm() => Status = "Confirmed";
    public void Complete() => Status = "Completed";
    public void Cancel() => Status = "Cancelled";
    public void Deactivate() => IsActive = false;
    public void Activate() => IsActive = true;
}
