using System;

namespace ERP.Domain.Entities.Purchasing;

/// <summary>
/// Purchase Order Line — Phase 6 Purchasing
/// Per proposal: Partial receipt tracking, Product reference, Quantity, Unit Price
/// </summary>
public class PurchaseOrderLine
{
    public int Id { get; private set; }
    public int PurchaseOrderId { get; private set; }
    public int ProductId { get; private set; }
    public int Quantity { get; private set; }
    public decimal UnitPrice { get; private set; }
    public decimal LineTotal { get; private set; }

    public PurchaseOrder? PurchaseOrder { get; private set; }

    private PurchaseOrderLine() { }

    public PurchaseOrderLine(
        int purchaseOrderId,
        int productId,
        int quantity,
        decimal unitPrice)
    {
        if (purchaseOrderId <= 0) throw new ArgumentException("Purchase order required");
        if (productId <= 0) throw new ArgumentException("Product required");
        if (quantity <= 0) throw new ArgumentException("Quantity must be positive");
        if (unitPrice < 0) throw new ArgumentException("Unit price must be non-negative");

        PurchaseOrderId = purchaseOrderId;
        ProductId = productId;
        Quantity = quantity;
        UnitPrice = unitPrice;
        LineTotal = Quantity * UnitPrice;
    }

    public void UpdateQuantityAndPrice(int quantity, decimal unitPrice)
    {
        if (quantity <= 0) throw new ArgumentException("Quantity must be positive");
        if (unitPrice < 0) throw new ArgumentException("Unit price must be non-negative");
        Quantity = quantity;
        UnitPrice = unitPrice;
        LineTotal = Quantity * UnitPrice;
    }
}
