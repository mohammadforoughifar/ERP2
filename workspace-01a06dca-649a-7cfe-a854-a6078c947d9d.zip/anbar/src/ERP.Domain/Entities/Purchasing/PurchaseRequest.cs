using System;

namespace ERP.Domain.Entities.Purchasing;

/// <summary>
/// Purchase Request — Phase 6 Purchasing
/// Per proposal: Request → RFQ → Purchase Order → Receipt → Invoice flow
/// </summary>
public class PurchaseRequest
{
    public int Id { get; private set; }
    public int? CompanyId { get; private set; }
    public int? BranchId { get; private set; }
    public int RequesterId { get; private set; }          // کاربر درخواست‌دهنده
    public string RequestNumber { get; private set; } = string.Empty;
    public DateTime RequestDate { get; private set; }
    public string Status { get; private set; } = "Draft"; // Draft, Submitted, Approved, Rejected, Converted
    public bool IsActive { get; private set; } = true;
    public DateTime CreatedAt { get; private set; }
    public string CreatedBy { get; private set; } = string.Empty;

    private PurchaseRequest() { }

    public PurchaseRequest(
        int? companyId,
        int? branchId,
        int requesterId,
        string requestNumber,
        DateTime requestDate,
        string createdBy)
    {
        if (companyId == null || companyId <= 0) throw new ArgumentException("Company required", nameof(companyId));
        if (requesterId <= 0) throw new ArgumentException("Requester required", nameof(requesterId));
        if (string.IsNullOrWhiteSpace(requestNumber)) throw new ArgumentException("Request number required");

        CompanyId = companyId;
        BranchId = branchId;
        RequesterId = requesterId;
        RequestNumber = requestNumber.Trim();
        RequestDate = requestDate;
        Status = "Draft";
        CreatedAt = DateTime.UtcNow;
        CreatedBy = createdBy;
        IsActive = true;
    }

    public void Submit() => Status = "Submitted";
    public void Approve() => Status = "Approved";
    public void Reject() => Status = "Rejected";
    public void ConvertToRFQ() => Status = "Converted";
    public void Deactivate() => IsActive = false;
    public void Activate() => IsActive = true;
}
