using System;

namespace ERP.Domain.Entities.Purchasing;

/// <summary>
/// Purchase Order — Phase 6 Purchasing
/// Per proposal: Purchase Order → Goods Receipt → Purchase Invoice flow
/// Partial Conversion: Order quantity may be partially received
/// </summary>
public class PurchaseOrder
{
    public int Id { get; private set; }
    public int? CompanyId { get; private set; }
    public int? BranchId { get; private set; }
    public int SupplierId { get; private set; }
    public int? RFQId { get; private set; }
    public int? PurchaseRequestId { get; private set; }
    public string OrderNumber { get; private set; } = string.Empty;
    public DateTime OrderDate { get; private set; }
    public string Status { get; private set; } = "Draft"; // Draft, Confirmed, Partial, Completed, Cancelled
    public decimal TotalAmount { get; private set; }
    public bool IsActive { get; private set; } = true;
    public DateTime CreatedAt { get; private set; }
    public string CreatedBy { get; private set; } = string.Empty;

    private PurchaseOrder() { }

    public PurchaseOrder(
        int? companyId,
        int? branchId,
        int supplierId,
        int? rfqId,
        int? purchaseRequestId,
        string orderNumber,
        DateTime orderDate,
        decimal totalAmount,
        string createdBy)
    {
        if (companyId == null || companyId <= 0) throw new ArgumentException("Company required", nameof(companyId));
        if (supplierId <= 0) throw new ArgumentException("Supplier required", nameof(supplierId));
        if (string.IsNullOrWhiteSpace(orderNumber)) throw new ArgumentException("Order number required");

        CompanyId = companyId;
        BranchId = branchId;
        SupplierId = supplierId;
        RFQId = rfqId;
        PurchaseRequestId = purchaseRequestId;
        OrderNumber = orderNumber.Trim();
        OrderDate = orderDate;
        TotalAmount = totalAmount >= 0 ? totalAmount : 0;
        Status = "Draft";
        CreatedAt = DateTime.UtcNow;
        CreatedBy = createdBy;
        IsActive = true;
    }

    public void Confirm() => Status = "Confirmed";
    public void Complete() => Status = "Completed";
    public void Partial() => Status = "Partial";
    public void Cancel() => Status = "Cancelled";
    public void Deactivate() => IsActive = false;
    public void Activate() => IsActive = true;
}
