using System;

namespace ERP.Domain.Entities.Purchasing;

/// <summary>
/// Request for Quotation (RFQ) — Phase 6 Purchasing
/// Per proposal: RFQ → Supplier Quotation → Purchase Order flow
/// </summary>
public class RequestForQuotation
{
    public int Id { get; private set; }
    public int? CompanyId { get; private set; }
    public int? PurchaseRequestId { get; private set; }
    public int? SupplierId { get; private set; }         // Optional: specific supplier
    public string RFQNumber { get; private set; } = string.Empty;
    public DateTime IssueDate { get; private set; }
    public DateTime Deadline { get; private set; }
    public string Status { get; private set; } = "Draft"; // Draft, Issued, Closed, Converted
    public bool IsActive { get; private set; } = true;
    public DateTime CreatedAt { get; private set; }
    public string CreatedBy { get; private set; } = string.Empty;

    private RequestForQuotation() { }

    public RequestForQuotation(
        int? companyId,
        int? purchaseRequestId,
        int? supplierId,
        string rfqNumber,
        DateTime issueDate,
        DateTime deadline,
        string createdBy)
    {
        if (companyId == null || companyId <= 0) throw new ArgumentException("Company required", nameof(companyId));
        if (string.IsNullOrWhiteSpace(rfqNumber)) throw new ArgumentException("RFQ number required");

        CompanyId = companyId;
        PurchaseRequestId = purchaseRequestId;
        SupplierId = supplierId;
        RFQNumber = rfqNumber.Trim();
        IssueDate = issueDate;
        Deadline = deadline;
        Status = "Draft";
        CreatedAt = DateTime.UtcNow;
        CreatedBy = createdBy;
        IsActive = true;
    }

    public void Issue() => Status = "Issued";
    public void Close() => Status = "Closed";
    public void ConvertToOrder() => Status = "Converted";
    public void Deactivate() => IsActive = false;
    public void Activate() => IsActive = true;
}
