namespace ERP.Domain.Entities;

/// <summary>
/// User-Role association for RBAC
/// Per proposal: User can have multiple Roles, Role can have multiple Users
/// </summary>
public class UserRole
{
    public int UserId { get; private set; }
    public int RoleId { get; private set; }
    public DateTime AssignedAt { get; private set; }

    public User? User { get; private set; }
    public Role? Role { get; private set; }

    private UserRole() { }

    public UserRole(int userId, int roleId)
    {
        UserId = userId;
        RoleId = roleId;
        AssignedAt = System.DateTime.UtcNow;
    }
}
