using System;

namespace ERP.Domain.Entities.MRP;

/// <summary>
/// MRP Analysis — Phase 10 MRP
/// Per proposal: Analysis of Demand vs Supply, Material Shortage, Capacity Requirement
/// </summary>
public class MRPAnalysis
{
    public int Id { get; private set; }
    public int MRPPlanId { get; private set; }
    public int? CompanyId { get; private set; }
    public int? ProductId { get; private set; }
    public string AnalysisType { get; private set; } = string.Empty;     // MaterialShortage, CapacityRequirement, InventoryStatus
    public string Description { get; private set; } = string.Empty;
    public int AffectedQuantity { get; private set; }
    public DateTime AnalysisDate { get; private set; }
    public bool IsActive { get; private set; } = true;
    public DateTime CreatedAt { get; private set; }
    public string CreatedBy { get; private set; } = string.Empty;

    private MRPAnalysis() { }

    public MRPAnalysis(
        int mrpPlanId,
        int? companyId,
        int? productId,
        string analysisType,
        string description,
        int affectedQuantity,
        DateTime analysisDate,
        string createdBy)
    {
        if (mrpPlanId <= 0) throw new ArgumentException("MRP plan required");
        if (string.IsNullOrWhiteSpace(analysisType)) throw new ArgumentException("Analysis type required");
        if (affectedQuantity < 0) throw new ArgumentException("Affected quantity must be non-negative");

        MRPPlanId = mrpPlanId;
        CompanyId = companyId;
        ProductId = productId;
        AnalysisType = analysisType.Trim();
        Description = description?.Trim() ?? string.Empty;
        AffectedQuantity = affectedQuantity;
        AnalysisDate = analysisDate;
        CreatedAt = DateTime.UtcNow;
        CreatedBy = createdBy;
        IsActive = true;
    }

    public void Deactivate() => IsActive = false;
    public void Activate() => IsActive = true;
}
