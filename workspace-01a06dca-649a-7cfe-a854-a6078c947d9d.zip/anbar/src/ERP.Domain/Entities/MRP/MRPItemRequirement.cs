using System;

namespace ERP.Domain.Entities.MRP;

/// <summary>
/// MRP Item Requirement — Phase 10 MRP
/// Per proposal: Demand (Sales Orders, Forecast) vs Supply (Inventory, Purchase Orders, Production Orders)
/// Analysis: Material Shortage, Safety Stock, Lead Time
/// </summary>
public class MRPItemRequirement
{
    public int Id { get; private set; }
    public int MRPPlanId { get; private set; }
    public int? CompanyId { get; private set; }
    public int ProductId { get; private set; }
    public int DemandQuantity { get; private set; }          // Demand from Sales Orders / Forecast
    public int SupplyQuantity { get; private set; }        // Supply from Inventory + Purchase Orders + Production Orders
    public int NetRequirement { get; private set; }         // Net = Demand - Supply
    public int SafetyStock { get; private set; }
    public int ReorderPoint { get; private set; }
    public int LeadTimeDays { get; private set; }
    public DateTime AnalysisDate { get; private set; }
    public bool IsActive { get; private set; } = true;
    public DateTime CreatedAt { get; private set; }
    public string CreatedBy { get; private set; } = string.Empty;

    private MRPItemRequirement() { }

    public MRPItemRequirement(
        int mrpPlanId,
        int? companyId,
        int productId,
        int demandQuantity,
        int supplyQuantity,
        int safetyStock,
        int reorderPoint,
        int leadTimeDays,
        DateTime analysisDate,
        string createdBy)
    {
        if (mrpPlanId <= 0) throw new ArgumentException("MRP plan required");
        if (productId <= 0) throw new ArgumentException("Product required");
        if (demandQuantity < 0) throw new ArgumentException("Demand must be non-negative");
        if (supplyQuantity < 0) throw new ArgumentException("Supply must be non-negative");

        MRPPlanId = mrpPlanId;
        CompanyId = companyId;
        ProductId = productId;
        DemandQuantity = demandQuantity;
        SupplyQuantity = supplyQuantity;
        NetRequirement = demandQuantity - supplyQuantity;
        SafetyStock = safetyStock >= 0 ? safetyStock : 0;
        ReorderPoint = reorderPoint >= 0 ? reorderPoint : 0;
        LeadTimeDays = leadTimeDays >= 0 ? leadTimeDays : 0;
        AnalysisDate = analysisDate;
        CreatedAt = DateTime.UtcNow;
        CreatedBy = createdBy;
        IsActive = true;
    }

    public void UpdateAnalysis(int demandQuantity, int supplyQuantity)
    {
        if (demandQuantity < 0 || supplyQuantity < 0) throw new ArgumentException("Demand and supply must be non-negative");
        DemandQuantity = demandQuantity;
        SupplyQuantity = supplyQuantity;
        NetRequirement = demandQuantity - supplyQuantity;
    }

    public void Deactivate() => IsActive = false;
    public void Activate() => IsActive = true;
}
