using System;

namespace ERP.Domain.Entities.MRP;

/// <summary>
/// MRP Plan — Phase 10 MRP
/// Per proposal: MRP analyzes Sales Orders, Forecast, Inventory, Purchase Orders,
/// Production Orders, BOM, Lead Time, Safety Stock to generate recommendations
/// </summary>
public class MRPPlan
{
    public int Id { get; private set; }
    public int? CompanyId { get; private set; }
    public int? BranchId { get; private set; }
    public string PlanNumber { get; private set; } = string.Empty;
    public DateTime PlanDate { get; private set; }
    public DateTime AnalysisStartDate { get; private set; }
    public DateTime AnalysisEndDate { get; private set; }
    public string Status { get; private set; } = "Draft"; // Draft, Generated, Confirmed, Executed, Cancelled
    public bool IsActive { get; private set; } = true;
    public DateTime CreatedAt { get; private set; }
    public string CreatedBy { get; private set; } = string.Empty;

    private MRPPlan() { }

    public MRPPlan(
        int? companyId,
        int? branchId,
        string planNumber,
        DateTime planDate,
        DateTime analysisStartDate,
        DateTime analysisEndDate,
        string createdBy)
    {
        if (companyId == null || companyId <= 0) throw new ArgumentException("Company required", nameof(companyId));
        if (string.IsNullOrWhiteSpace(planNumber)) throw new ArgumentException("Plan number required");

        CompanyId = companyId;
        BranchId = branchId;
        PlanNumber = planNumber.Trim();
        PlanDate = planDate;
        AnalysisStartDate = analysisStartDate;
        AnalysisEndDate = analysisEndDate;
        Status = "Draft";
        CreatedAt = DateTime.UtcNow;
        CreatedBy = createdBy;
        IsActive = true;
    }

    public void Generate() => Status = "Generated";
    public void Confirm() => Status = "Confirmed";
    public void Execute() => Status = "Executed";
    public void Cancel() => Status = "Cancelled";
    public void Deactivate() => IsActive = false;
    public void Activate() => IsActive = true;
}
