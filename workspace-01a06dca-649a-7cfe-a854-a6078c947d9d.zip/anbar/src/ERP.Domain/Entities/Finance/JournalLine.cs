using System;

namespace ERP.Domain.Entities.Finance;

/// <summary>
/// Journal Line — Phase 3 Finance
/// Per proposal: Debit/Credit, Account, Cost Center, Project, Reference Document
/// </summary>
public class JournalLine
{
    public int Id { get; private set; }
    public int JournalEntryId { get; private set; }
    public int ChartOfAccountId { get; private set; }
    public decimal Amount { get; private set; }
    public bool IsDebit { get; private set; }
    public int? CostCenterId { get; private set; }        // Optional Cost Center
    public int? ProjectId { get; private set; }            // Optional Project
    public int? BusinessPartnerId { get; private set; }    // Customer / Supplier reference
    public string ReferenceDocument { get; private set; } = string.Empty;
    public string Description { get; private set; } = string.Empty;

    public JournalEntry? JournalEntry { get; private set; }

    private JournalLine() { }

    public JournalLine(
        int journalEntryId,
        int chartOfAccountId,
        decimal amount,
        bool isDebit,
        int? costCenterId,
        int? projectId,
        int? businessPartnerId,
        string referenceDocument,
        string description)
    {
        if (journalEntryId <= 0) throw new ArgumentException("Journal entry required");
        if (chartOfAccountId <= 0) throw new ArgumentException("Account required");
        if (amount <= 0) throw new ArgumentException("Amount must be positive");

        JournalEntryId = journalEntryId;
        ChartOfAccountId = chartOfAccountId;
        Amount = amount;
        IsDebit = isDebit;
        CostCenterId = costCenterId;
        ProjectId = projectId;
        BusinessPartnerId = businessPartnerId;
        ReferenceDocument = referenceDocument?.Trim() ?? string.Empty;
        Description = description?.Trim() ?? string.Empty;
    }
}
