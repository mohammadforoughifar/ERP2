using System;
using System.Collections.Generic;

namespace ERP.Domain.Entities.Finance;

/// <summary>
/// Journal Entry — Phase 3 Finance
/// Per proposal: General Ledger core, Debit/Credit balance, Multi-Currency, Cost Center, Project
/// Every JournalEntry must have balanced lines (Debit = Credit)
/// </summary>
public class JournalEntry
{
    public int Id { get; private set; }
    public int? CompanyId { get; private set; }
    public string DocumentNumber { get; private set; } = string.Empty; // Configurable numbering
    public DateTime EntryDate { get; private set; }
    public string Description { get; private set; } = string.Empty;
    public string CurrencyCode { get; private set; } = "IRR"; // Default: Iranian Rial / تومان
    public decimal ExchangeRate { get; private set; } = 1m;
    public bool IsPosted { get; private set; } = false;
    public bool IsReversed { get; private set; } = false;
    public int? ReversedByEntryId { get; private set; }
    public bool IsActive { get; private set; } = true;
    public DateTime CreatedAt { get; private set; }
    public string CreatedBy { get; private set; } = string.Empty;

    private readonly List<JournalLine> _lines = new();
    public IReadOnlyCollection<JournalLine> Lines => _lines.AsReadOnly();

    private JournalEntry() { }

    public JournalEntry(
        int? companyId,
        string documentNumber,
        DateTime entryDate,
        string description,
        string currencyCode,
        decimal exchangeRate,
        string createdBy)
    {
        if (companyId == null || companyId <= 0) throw new ArgumentException("Company required", nameof(companyId));
        if (string.IsNullOrWhiteSpace(documentNumber)) throw new ArgumentException("Document number required");

        CompanyId = companyId;
        DocumentNumber = documentNumber.Trim();
        EntryDate = entryDate;
        Description = description?.Trim() ?? string.Empty;
        CurrencyCode = currencyCode?.Trim() ?? "IRR";
        ExchangeRate = exchangeRate > 0 ? exchangeRate : 1m;
        CreatedAt = DateTime.UtcNow;
        CreatedBy = createdBy;
        IsPosted = false;
        IsReversed = false;
        IsActive = true;
    }

    public void AddLine(JournalLine line)
    {
        if (IsPosted) throw new InvalidOperationException("Cannot add line to posted entry");
        if (IsReversed) throw new InvalidOperationException("Cannot add line to reversed entry");
        _lines.Add(line);
    }

    public void Post()
    {
        if (IsPosted) throw new InvalidOperationException("Already posted");
        if (IsReversed) throw new InvalidOperationException("Entry is reversed");
        if (!IsBalanced()) throw new InvalidOperationException("Journal entry is not balanced");
        IsPosted = true;
    }

    public void Reverse(int newEntryId)
    {
        if (!IsPosted) throw new InvalidOperationException("Cannot reverse unposted entry");
        if (IsReversed) throw new InvalidOperationException("Already reversed");
        ReversedByEntryId = newEntryId;
        IsReversed = true;
    }

    public bool IsBalanced()
    {
        decimal debitTotal = 0;
        decimal creditTotal = 0;
        foreach (var line in _lines)
        {
            if (line.IsDebit)
                debitTotal += line.Amount;
            else
                creditTotal += line.Amount;
        }
        return debitTotal == creditTotal && debitTotal > 0;
    }

    public decimal GetDebitTotal()
    {
        decimal total = 0;
        foreach (var line in _lines) if (line.IsDebit) total += line.Amount;
        return total;
    }

    public decimal GetCreditTotal()
    {
        decimal total = 0;
        foreach (var line in _lines) if (!line.IsDebit) total += line.Amount;
        return total;
    }
}
