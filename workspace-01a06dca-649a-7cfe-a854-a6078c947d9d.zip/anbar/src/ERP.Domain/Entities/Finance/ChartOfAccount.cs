using System;

namespace ERP.Domain.Entities.Finance;

/// <summary>
/// Chart of Account — Phase 3 Finance
/// Per proposal: Group, Main, Sub, Detail, Floating Detail, Cost Center, Project
/// Multi-Level: Level 1 = Group, Level 2 = Main, Level 3 = Sub, Level 4 = Detail
/// </summary>
public class ChartOfAccount
{
    public int Id { get; private set; }
    public int? CompanyId { get; private set; }
    public int ParentId { get; private set; } // Self-referencing hierarchy
    public string Code { get; private set; } = string.Empty;         // Numeric account code: 1-100-10-01
    public string Name { get; private set; } = string.Empty;
    public int Level { get; private set; }                             // 1=Group, 2=Main, 3=Sub, 4=Detail
    public ERP.Domain.ValueObjects.AccountType AccountType { get; private set; }
    public bool IsCostCenterApplicable { get; private set; } = false;
    public bool IsProjectApplicable { get; private set; } = false;
    public bool IsActive { get; private set; } = true;
    public DateTime CreatedAt { get; private set; }
    public string CreatedBy { get; private set; } = string.Empty;

    private ChartOfAccount() { }

    public ChartOfAccount(
        int? companyId,
        int parentId,
        string code,
        string name,
        int level,
        ERP.Domain.ValueObjects.AccountType accountType,
        bool isCostCenterApplicable,
        bool isProjectApplicable,
        string createdBy)
    {
        if (companyId == null || companyId <= 0) throw new ArgumentException("Company required", nameof(companyId));
        if (string.IsNullOrWhiteSpace(code)) throw new ArgumentException("Account code required");
        if (string.IsNullOrWhiteSpace(name)) throw new ArgumentException("Account name required");
        if (level < 1 || level > 4) throw new ArgumentException("Level must be 1-4");

        CompanyId = companyId;
        ParentId = parentId;
        Code = code.Trim();
        Name = name.Trim();
        Level = level;
        AccountType = accountType;
        IsCostCenterApplicable = isCostCenterApplicable;
        IsProjectApplicable = isProjectApplicable;
        CreatedAt = DateTime.UtcNow;
        CreatedBy = createdBy;
        IsActive = true;
    }

    public void UpdateProfile(string name, bool isCostCenterApplicable, bool isProjectApplicable)
    {
        Name = name.Trim();
        IsCostCenterApplicable = isCostCenterApplicable;
        IsProjectApplicable = isProjectApplicable;
    }

    public void Deactivate() => IsActive = false;
    public void Activate() => IsActive = true;
}
