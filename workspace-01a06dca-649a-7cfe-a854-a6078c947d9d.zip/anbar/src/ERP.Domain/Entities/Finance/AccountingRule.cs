using System;

namespace ERP.Domain.Entities.Finance;

/// <summary>
/// Accounting Rule — Phase 3 Finance
/// Per proposal: Configurable Accounting Rules for Sales, Purchase, Inventory, Production, etc.
/// Example: IF DocumentType == SalesInvoice THEN Debit Customer AR / Credit Revenue
/// </summary>
public class AccountingRule
{
    public int Id { get; private set; }
    public int? CompanyId { get; private set; }
    public string RuleName { get; private set; } = string.Empty;
    public string DocumentType { get; private set; } = string.Empty;  // SalesOrder, PurchaseInvoice, etc.
    public string Module { get; private set; } = string.Empty;        // Sales, Purchase, Inventory, Production
    public int DebitAccountId { get; private set; }
    public int CreditAccountId { get; private set; }
    public string ConditionExpression { get; private set; } = string.Empty; // Optional condition
    public bool IsActive { get; private set; } = true;
    public DateTime CreatedAt { get; private set; }
    public string CreatedBy { get; private set; } = string.Empty;

    private AccountingRule() { }

    public AccountingRule(
        int? companyId,
        string ruleName,
        string documentType,
        string module,
        int debitAccountId,
        int creditAccountId,
        string conditionExpression,
        string createdBy)
    {
        if (companyId == null || companyId <= 0) throw new ArgumentException("Company required", nameof(companyId));
        if (string.IsNullOrWhiteSpace(ruleName)) throw new ArgumentException("Rule name required");
        if (string.IsNullOrWhiteSpace(documentType)) throw new ArgumentException("Document type required");
        if (string.IsNullOrWhiteSpace(module)) throw new ArgumentException("Module required");
        if (debitAccountId <= 0 || creditAccountId <= 0) throw new ArgumentException("Account IDs must be valid");

        CompanyId = companyId;
        RuleName = ruleName.Trim();
        DocumentType = documentType.Trim();
        Module = module.Trim();
        DebitAccountId = debitAccountId;
        CreditAccountId = creditAccountId;
        ConditionExpression = conditionExpression?.Trim() ?? string.Empty;
        CreatedAt = DateTime.UtcNow;
        CreatedBy = createdBy;
        IsActive = true;
    }

    public void UpdateRule(string ruleName, int debitAccountId, int creditAccountId, string conditionExpression)
    {
        RuleName = ruleName.Trim();
        DebitAccountId = debitAccountId;
        CreditAccountId = creditAccountId;
        ConditionExpression = conditionExpression?.Trim() ?? string.Empty;
    }

    public void Deactivate() => IsActive = false;
    public void Activate() => IsActive = true;
}
