using System;

namespace ERP.Domain.Entities;

/// <summary>
/// Permission — ABAC / RBAC permission entry per proposal
/// </summary>
public class Permission
{
    public int Id { get; private set; }
    public int? CompanyId { get; private set; }
    public string Module { get; private set; } = string.Empty;     // e.g. Sales, Finance
    public string Action { get; private set; } = string.Empty;     // View, Create, Edit, Delete, Approve
    public string Resource { get; private set; } = string.Empty;  // e.g. Invoice, PurchaseOrder
    public bool IsActive { get; private set; } = true;
    public DateTime CreatedAt { get; private set; }
    public string CreatedBy { get; private set; } = string.Empty;

    private Permission() { }

    public Permission(int? companyId, string module, string action, string resource, string createdBy)
    {
        if (string.IsNullOrWhiteSpace(module)) throw new ArgumentException("Module required");
        if (string.IsNullOrWhiteSpace(action)) throw new ArgumentException("Action required");
        if (string.IsNullOrWhiteSpace(resource)) throw new ArgumentException("Resource required");

        CompanyId = companyId;
        Module = module.Trim();
        Action = action.Trim();
        Resource = resource.Trim();
        CreatedAt = DateTime.UtcNow;
        CreatedBy = createdBy;
        IsActive = true;
    }
}
