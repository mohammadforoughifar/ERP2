using System;

namespace ERP.Domain.Entities.Sales;

/// <summary>
/// Sales Order Line — Phase 5 Sales
/// Per proposal: Partial Conversion support, Item reference, Quantity, Unit Price, Discount
/// </summary>
public class SalesOrderLine
{
    public int Id { get; private set; }
    public int SalesOrderId { get; private set; }
    public int ProductId { get; private set; }
    public int Quantity { get; private set; }
    public decimal UnitPrice { get; private set; }
    public decimal DiscountPercent { get; private set; }
    public decimal LineTotal { get; private set; }

    public SalesOrder? SalesOrder { get; private set; }

    private SalesOrderLine() { }

    public SalesOrderLine(
        int salesOrderId,
        int productId,
        int quantity,
        decimal unitPrice,
        decimal discountPercent = 0)
    {
        if (salesOrderId <= 0) throw new ArgumentException("Sales order required");
        if (productId <= 0) throw new ArgumentException("Product required");
        if (quantity <= 0) throw new ArgumentException("Quantity must be positive");
        if (unitPrice < 0) throw new ArgumentException("Unit price must be non-negative");

        SalesOrderId = salesOrderId;
        ProductId = productId;
        Quantity = quantity;
        UnitPrice = unitPrice;
        DiscountPercent = discountPercent >= 0 && discountPercent <= 100 ? discountPercent : 0;
        LineTotal = CalculateLineTotal();
    }

    private decimal CalculateLineTotal()
    {
        decimal subtotal = Quantity * UnitPrice;
        return subtotal - (subtotal * (DiscountPercent / 100));
    }

    public void UpdateQuantityAndPrice(int quantity, decimal unitPrice)
    {
        if (quantity <= 0) throw new ArgumentException("Quantity must be positive");
        if (unitPrice < 0) throw new ArgumentException("Unit price must be non-negative");
        Quantity = quantity;
        UnitPrice = unitPrice;
        LineTotal = CalculateLineTotal();
    }
}
