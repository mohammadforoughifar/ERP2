using System;

namespace ERP.Domain.Entities.Sales;

/// <summary>
/// Delivery — Phase 5 Sales
/// Per proposal: Partial Conversion from Sales Order, Delivery to Customer
/// Document Flow: Sales Order → Delivery → Invoice
/// </summary>
public class Delivery
{
    public int Id { get; private set; }
    public int? CompanyId { get; private set; }
    public int? BranchId { get; private set; }
    public int CustomerId { get; private set; }
    public int SalesOrderId { get; private set; }
    public string DeliveryNumber { get; private set; } = string.Empty;
    public DateTime DeliveryDate { get; private set; }
    public string Status { get; private set; } = "Draft"; // Draft, Confirmed, Shipped, Completed, Cancelled
    public bool IsActive { get; private set; } = true;
    public DateTime CreatedAt { get; private set; }
    public string CreatedBy { get; private set; } = string.Empty;

    private Delivery() { }

    public Delivery(
        int? companyId,
        int? branchId,
        int customerId,
        int salesOrderId,
        string deliveryNumber,
        DateTime deliveryDate,
        string createdBy)
    {
        if (companyId == null || companyId <= 0) throw new ArgumentException("Company required", nameof(companyId));
        if (customerId <= 0) throw new ArgumentException("Customer required", nameof(customerId));
        if (salesOrderId <= 0) throw new ArgumentException("Sales order required", nameof(salesOrderId));
        if (string.IsNullOrWhiteSpace(deliveryNumber)) throw new ArgumentException("Delivery number required");

        CompanyId = companyId;
        BranchId = branchId;
        CustomerId = customerId;
        SalesOrderId = salesOrderId;
        DeliveryNumber = deliveryNumber.Trim();
        DeliveryDate = deliveryDate;
        Status = "Draft";
        CreatedAt = DateTime.UtcNow;
        CreatedBy = createdBy;
        IsActive = true;
    }

    public void Confirm() => Status = "Confirmed";
    public void Ship() => Status = "Shipped";
    public void Complete() => Status = "Completed";
    public void Cancel() => Status = "Cancelled";
    public void Deactivate() => IsActive = false;
    public void Activate() => IsActive = true;
}
