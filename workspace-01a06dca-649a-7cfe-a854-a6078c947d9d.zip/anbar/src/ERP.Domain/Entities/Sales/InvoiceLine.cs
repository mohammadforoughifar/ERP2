using System;

namespace ERP.Domain.Entities.Sales;

/// <summary>
/// Invoice Line — Phase 5 Sales
/// Per proposal: Tax calculation per line, Product reference, Discount
/// </summary>
public class InvoiceLine
{
    public int Id { get; private set; }
    public int InvoiceId { get; private set; }
    public int DeliveryLineId { get; private set; }
    public int ProductId { get; private set; }
    public int Quantity { get; private set; }
    public decimal UnitPrice { get; private set; }
    public decimal DiscountPercent { get; private set; }
    public decimal LineSubTotal { get; private set; }
    public decimal LineTaxAmount { get; private set; }      // مالیات بر ارزش افزوده
    public decimal LineTotal { get; private set; }

    public Invoice? Invoice { get; private set; }

    private InvoiceLine() { }

    public InvoiceLine(
        int invoiceId,
        int deliveryLineId,
        int productId,
        int quantity,
        decimal unitPrice,
        decimal discountPercent = 0,
        decimal taxRate = 0.09m) // Default VAT rate: 9% (Iranian VAT configurable)
    {
        if (invoiceId <= 0) throw new ArgumentException("Invoice required");
        if (deliveryLineId <= 0) throw new ArgumentException("Delivery line required");
        if (productId <= 0) throw new ArgumentException("Product required");
        if (quantity <= 0) throw new ArgumentException("Quantity must be positive");
        if (unitPrice < 0) throw new ArgumentException("Unit price must be non-negative");

        InvoiceId = invoiceId;
        DeliveryLineId = deliveryLineId;
        ProductId = productId;
        Quantity = quantity;
        UnitPrice = unitPrice;
        DiscountPercent = discountPercent >= 0 && discountPercent <= 100 ? discountPercent : 0;
        LineSubTotal = CalculateSubTotal();
        LineTaxAmount = LineSubTotal * (taxRate >= 0 ? taxRate : 0);
        LineTotal = LineSubTotal + LineTaxAmount - (LineSubTotal * (DiscountPercent / 100));
    }

    private decimal CalculateSubTotal()
    {
        return (Quantity * UnitPrice) - ((Quantity * UnitPrice) * (DiscountPercent / 100));
    }

    public void UpdateQuantityAndPrice(int quantity, decimal unitPrice, decimal taxRate = 0.09m)
    {
        if (quantity <= 0) throw new ArgumentException("Quantity must be positive");
        if (unitPrice < 0) throw new ArgumentException("Unit price must be non-negative");
        Quantity = quantity;
        UnitPrice = unitPrice;
        LineSubTotal = CalculateSubTotal();
        LineTaxAmount = LineSubTotal * (taxRate >= 0 ? taxRate : 0);
        LineTotal = LineSubTotal + LineTaxAmount - (LineSubTotal * (DiscountPercent / 100));
    }
}
