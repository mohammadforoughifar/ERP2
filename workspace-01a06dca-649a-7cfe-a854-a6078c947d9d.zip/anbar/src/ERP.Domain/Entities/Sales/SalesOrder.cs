using System;

namespace ERP.Domain.Entities.Sales;

/// <summary>
/// Sales Order — Phase 5 Sales
/// Per proposal: Partial Conversion, Relationship with Quotation, Delivery, Invoice
/// Document Flow: Quotation → Sales Order → Delivery → Invoice → Receipt
/// </summary>
public class SalesOrder
{
    public int Id { get; private set; }
    public int? CompanyId { get; private set; }
    public int? BranchId { get; private set; }
    public int CustomerId { get; private set; }
    public int? QuotationId { get; private set; }
    public string OrderNumber { get; private set; } = string.Empty;
    public DateTime OrderDate { get; private set; }
    public string Status { get; private set; } = "Draft"; // Draft, Confirmed, Partial, Completed, Cancelled
    public decimal TotalAmount { get; private set; }
    public bool IsActive { get; private set; } = true;
    public DateTime CreatedAt { get; private set; }
    public string CreatedBy { get; private set; } = string.Empty;

    private SalesOrder() { }

    public SalesOrder(
        int? companyId,
        int? branchId,
        int customerId,
        int? quotationId,
        string orderNumber,
        DateTime orderDate,
        decimal totalAmount,
        string createdBy)
    {
        if (companyId == null || companyId <= 0) throw new ArgumentException("Company required", nameof(companyId));
        if (customerId <= 0) throw new ArgumentException("Customer required", nameof(customerId));
        if (string.IsNullOrWhiteSpace(orderNumber)) throw new ArgumentException("Order number required");

        CompanyId = companyId;
        BranchId = branchId;
        CustomerId = customerId;
        QuotationId = quotationId;
        OrderNumber = orderNumber.Trim();
        OrderDate = orderDate;
        TotalAmount = totalAmount >= 0 ? totalAmount : 0;
        Status = "Draft";
        CreatedAt = DateTime.UtcNow;
        CreatedBy = createdBy;
        IsActive = true;
    }

    public void Confirm() => Status = "Confirmed";
    public void Complete() => Status = "Completed";
    public void Cancel() => Status = "Cancelled";
    public void Partial() => Status = "Partial";
    public void Deactivate() => IsActive = false;
    public void Activate() => IsActive = true;
}
