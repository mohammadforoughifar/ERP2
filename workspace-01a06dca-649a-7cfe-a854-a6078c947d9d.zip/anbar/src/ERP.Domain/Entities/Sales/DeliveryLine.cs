using System;

namespace ERP.Domain.Entities.Sales;

/// <summary>
/// Delivery Line — Phase 5 Sales
/// Per proposal: Partial delivery quantity tracking against Sales Order
/// </summary>
public class DeliveryLine
{
    public int Id { get; private set; }
    public int DeliveryId { get; private set; }
    public int SalesOrderLineId { get; private set; }
    public int ProductId { get; private set; }
    public int DeliveredQuantity { get; private set; }

    public Delivery? Delivery { get; private set; }

    private DeliveryLine() { }

    public DeliveryLine(
        int deliveryId,
        int salesOrderLineId,
        int productId,
        int deliveredQuantity)
    {
        if (deliveryId <= 0) throw new ArgumentException("Delivery required");
        if (salesOrderLineId <= 0) throw new ArgumentException("Sales order line required");
        if (productId <= 0) throw new ArgumentException("Product required");
        if (deliveredQuantity <= 0) throw new ArgumentException("Delivered quantity must be positive");

        DeliveryId = deliveryId;
        SalesOrderLineId = salesOrderLineId;
        ProductId = productId;
        DeliveredQuantity = deliveredQuantity;
    }

    public void UpdateDeliveredQuantity(int deliveredQuantity)
    {
        if (deliveredQuantity <= 0) throw new ArgumentException("Delivered quantity must be positive");
        DeliveredQuantity = deliveredQuantity;
    }
}
