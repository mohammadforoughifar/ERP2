using System;

namespace ERP.Domain.Entities.Sales;

/// <summary>
/// Quotation — Phase 5 Sales
/// Per proposal: Quotation → Order flow, Customer 360 base
/// </summary>
public class Quotation
{
    public int Id { get; private set; }
    public int? CompanyId { get; private set; }
    public int? BranchId { get; private set; }
    public int CustomerId { get; private set; }
    public string QuotationNumber { get; private set; } = string.Empty;
    public DateTime QuotationDate { get; private set; }
    public DateTime ValidUntil { get; private set; }
    public decimal TotalAmount { get; private set; }
    public string Status { get; private set; } = "Draft"; // Draft, Submitted, Approved, Rejected, Converted
    public bool IsActive { get; private set; } = true;
    public DateTime CreatedAt { get; private set; }
    public string CreatedBy { get; private set; } = string.Empty;

    private Quotation() { }

    public Quotation(
        int? companyId,
        int? branchId,
        int customerId,
        string quotationNumber,
        DateTime quotationDate,
        DateTime validUntil,
        decimal totalAmount,
        string createdBy)
    {
        if (companyId == null || companyId <= 0) throw new ArgumentException("Company required", nameof(companyId));
        if (customerId <= 0) throw new ArgumentException("Customer required", nameof(customerId));
        if (string.IsNullOrWhiteSpace(quotationNumber)) throw new ArgumentException("Quotation number required");

        CompanyId = companyId;
        BranchId = branchId;
        CustomerId = customerId;
        QuotationNumber = quotationNumber.Trim();
        QuotationDate = quotationDate;
        ValidUntil = validUntil;
        TotalAmount = totalAmount >= 0 ? totalAmount : 0;
        Status = "Draft";
        CreatedAt = DateTime.UtcNow;
        CreatedBy = createdBy;
        IsActive = true;
    }

    public void UpdateStatus(string status)
    {
        Status = status?.Trim() ?? Status;
    }

    public void ConvertToOrder()
    {
        Status = "Converted";
    }

    public void Deactivate() => IsActive = false;
    public void Activate() => IsActive = true;
}
