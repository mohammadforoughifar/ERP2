using System;

namespace ERP.Domain.Entities.Sales;

/// <summary>
/// Sales Receipt — Phase 5 Sales
/// Per proposal: Receipt from Customer (Cash, Bank, Check, Credit Card)
/// Document Flow: Invoice → Receipt (Order-to-Cash complete)
/// </summary>
public class SalesReceipt
{
    public int Id { get; private set; }
    public int? CompanyId { get; private set; }
    public int? BranchId { get; private set; }
    public int CustomerId { get; private set; }
    public int? InvoiceId { get; private set; }
    public string ReceiptNumber { get; private set; } = string.Empty;
    public DateTime ReceiptDate { get; private set; }
    public decimal Amount { get; private set; }
    public string PaymentMethod { get; private set; } = string.Empty; // Cash, BankTransfer, Check, CreditCard
    public int? CashAccountId { get; private set; }
    public int? BankAccountId { get; private set; }
    public int? CheckId { get; private set; }
    public bool IsActive { get; private set; } = true;
    public DateTime CreatedAt { get; private set; }
    public string CreatedBy { get; private set; } = string.Empty;

    private SalesReceipt() { }

    public SalesReceipt(
        int? companyId,
        int? branchId,
        int customerId,
        int? invoiceId,
        string receiptNumber,
        DateTime receiptDate,
        decimal amount,
        string paymentMethod,
        int? cashAccountId,
        int? bankAccountId,
        int? checkId,
        string createdBy)
    {
        if (companyId == null || companyId <= 0) throw new ArgumentException("Company required", nameof(companyId));
        if (customerId <= 0) throw new ArgumentException("Customer required", nameof(customerId));
        if (string.IsNullOrWhiteSpace(receiptNumber)) throw new ArgumentException("Receipt number required");
        if (amount <= 0) throw new ArgumentException("Amount must be positive");

        CompanyId = companyId;
        BranchId = branchId;
        CustomerId = customerId;
        InvoiceId = invoiceId;
        ReceiptNumber = receiptNumber.Trim();
        ReceiptDate = receiptDate;
        Amount = amount;
        PaymentMethod = paymentMethod?.Trim() ?? "Cash";
        CashAccountId = cashAccountId;
        BankAccountId = bankAccountId;
        CheckId = checkId;
        CreatedAt = DateTime.UtcNow;
        CreatedBy = createdBy;
        IsActive = true;
    }

    public void Deactivate() => IsActive = false;
    public void Activate() => IsActive = true;
}
