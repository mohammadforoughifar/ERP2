using System;

namespace ERP.Domain.Entities;

/// <summary>
/// Multi-Tenant Aggregate Root — Phase 1 Core
/// Per proposal: Multi-Company, Multi-Branch, Multi-Warehouse base
/// </summary>
public class Tenant
{
    public int Id { get; private set; }
    public string Name { get; private set; } = string.Empty;
    public string Code { get; private set; } = string.Empty;
    public bool IsActive { get; private set; } = true;
    public DateTime CreatedAt { get; private set; }
    public string CreatedBy { get; private set; } = string.Empty;
    public DateTime? ModifiedAt { get; private set; }
    public string? ModifiedBy { get; private set; }

    private Tenant() { } // EF Core

    public Tenant(string name, string code, string createdBy)
    {
        if (string.IsNullOrWhiteSpace(name)) throw new ArgumentException("Tenant name required", nameof(name));
        if (string.IsNullOrWhiteSpace(code)) throw new ArgumentException("Tenant code required", nameof(code));

        Name = name.Trim();
        Code = code.Trim();
        CreatedAt = DateTime.UtcNow;
        CreatedBy = createdBy;
        IsActive = true;
    }

    public void UpdateName(string name)
    {
        if (string.IsNullOrWhiteSpace(name)) throw new ArgumentException("Name required");
        Name = name.Trim();
        ModifiedAt = DateTime.UtcNow;
    }

    public void Deactivate() => IsActive = false;
    public void Activate() => IsActive = true;
}
