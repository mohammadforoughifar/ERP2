using System;
using System.ComponentModel.DataAnnotations;

namespace ERP.Domain.Entities.Reporting;

public class Chart
{
    [Key]
    public int Id { get; set; }

    [Required]
    public int ReportId { get; set; }

    [StringLength(200)]
    public string ChartName { get; set; } = string.Empty;

    [StringLength(50)]
    public string ChartType { get; set; } = "Bar"; // Bar, Line, Pie, Area, Gauge

    [StringLength(500)]
    public string? DataSource { get; set; }

    [StringLength(500)]
    public string? XAxisLabel { get; set; }

    [StringLength(500)]
    public string? YAxisLabel { get; set; }

    public int CompanyId { get; set; }
    public int BranchId { get; set; }
    public int TenantId { get; set; }

    [StringLength(100)]
    public string CreatedBy { get; set; } = string.Empty;

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    [StringLength(100)]
    public string? ModifiedBy { get; set; }

    public DateTime? ModifiedAt { get; set; }

    public bool IsActive { get; set; } = true;
}
