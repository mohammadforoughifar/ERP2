using System;
using System.ComponentModel.DataAnnotations;

namespace ERP.Domain.Entities.Reporting;

public class Dashboard
{
    [Key]
    public int Id { get; set; }

    [Required]
    [StringLength(200)]
    public string DashboardName { get; set; } = string.Empty;

    [StringLength(500)]
    public string? Description { get; set; }

    [StringLength(50)]
    public string Status { get; set; } = "Active"; // Active, Inactive

    public int CompanyId { get; set; }
    public int BranchId { get; set; }
    public int TenantId { get; set; }

    [StringLength(100)]
    public string CreatedBy { get; set; } = string.Empty;

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    [StringLength(100)]
    public string? ModifiedBy { get; set; }

    public DateTime? ModifiedAt { get; set; }

    public bool IsActive { get; set; } = true;
}
