using System;
using System.ComponentModel.DataAnnotations;

namespace ERP.Domain.Entities.Reporting;

public class KPI
{
    [Key]
    public int Id { get; set; }

    [Required]
    public int DashboardId { get; set; }

    [StringLength(200)]
    public string KPIName { get; set; } = string.Empty;

    [StringLength(200)]
    public string Metric { get; set; } = string.Empty; // Metric name (e.g., Sales, Profit)

    public decimal TargetValue { get; set; } = 0;

    public decimal ActualValue { get; set; } = 0;

    [StringLength(50)]
    public string Unit { get; set; } = string.Empty; // Currency, Percentage, Count

    [StringLength(20)]
    public string Trend { get; set; } = "Stable"; // Increasing, Decreasing, Stable

    public int CompanyId { get; set; }
    public int BranchId { get; set; }
    public int TenantId { get; set; }

    [StringLength(100)]
    public string CreatedBy { get; set; } = string.Empty;

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    [StringLength(100)]
    public string? ModifiedBy { get; set; }

    public DateTime? ModifiedAt { get; set; }

    public bool IsActive { get; set; } = true;
}
