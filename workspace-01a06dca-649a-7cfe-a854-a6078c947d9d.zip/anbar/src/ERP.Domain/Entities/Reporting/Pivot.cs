using System;
using System.ComponentModel.DataAnnotations;

namespace ERP.Domain.Entities.Reporting;

public class Pivot
{
    [Key]
    public int Id { get; set; }

    [Required]
    public int ReportId { get; set; }

    [StringLength(200)]
    public string PivotName { get; set; } = string.Empty;

    [StringLength(200)]
    public string RowFields { get; set; } = string.Empty;

    [StringLength(200)]
    public string ColumnFields { get; set; } = string.Empty;

    [StringLength(500)]
    public string AggregateFields { get; set; } = string.Empty; // Sum, Avg, Count, etc.

    public int CompanyId { get; set; }
    public int BranchId { get; set; }
    public int TenantId { get; set; }

    [StringLength(100)]
    public string CreatedBy { get; set; } = string.Empty;

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    [StringLength(100)]
    public string? ModifiedBy { get; set; }

    public DateTime? ModifiedAt { get; set; }

    public bool IsActive { get; set; } = true;
}
