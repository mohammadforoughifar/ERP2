namespace ERP.Domain.ValueObjects;

/// <summary>
/// Account Type — Debit or Credit
/// Per proposal: Accounting Engine core
/// </summary>
public enum AccountType
{
    Asset = 1,
    Liability = 2,
    Equity = 3,
    Revenue = 4,
    Expense = 5
}
