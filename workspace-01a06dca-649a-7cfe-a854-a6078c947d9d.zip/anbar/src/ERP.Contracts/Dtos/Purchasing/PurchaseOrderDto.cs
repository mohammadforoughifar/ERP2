using System;

namespace ERP.Contracts.Dtos.Purchasing;

public record PurchaseOrderDto(
    int Id,
    int? CompanyId,
    int? BranchId,
    int SupplierId,
    int? RFQId,
    int? PurchaseRequestId,
    string OrderNumber,
    DateTime OrderDate,
    string Status,
    decimal TotalAmount,
    bool IsActive,
    DateTime CreatedAt,
    string CreatedBy
);

public record PurchaseOrderLineDto(
    int Id,
    int PurchaseOrderId,
    int ProductId,
    int Quantity,
    decimal UnitPrice,
    decimal LineTotal
);
