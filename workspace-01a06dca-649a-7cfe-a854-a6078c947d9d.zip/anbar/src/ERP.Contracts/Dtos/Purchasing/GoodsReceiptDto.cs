using System;

namespace ERP.Contracts.Dtos.Purchasing;

public record GoodsReceiptDto(
    int Id,
    int? CompanyId,
    int? BranchId,
    int SupplierId,
    int PurchaseOrderId,
    string ReceiptNumber,
    DateTime ReceiptDate,
    string Status,
    bool IsActive,
    DateTime CreatedAt,
    string CreatedBy
);

public record GoodsReceiptLineDto(
    int Id,
    int GoodsReceiptId,
    int PurchaseOrderLineId,
    int ProductId,
    int ReceivedQuantity,
    int WarehouseId
);
