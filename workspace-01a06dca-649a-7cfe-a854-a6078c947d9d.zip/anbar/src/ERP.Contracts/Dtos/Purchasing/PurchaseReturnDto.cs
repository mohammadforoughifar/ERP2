using System;

namespace ERP.Contracts.Dtos.Purchasing;

public record PurchaseReturnDto(
    int Id,
    int? CompanyId,
    int SupplierId,
    int? PurchaseOrderId,
    int? GoodsReceiptId,
    string ReturnNumber,
    DateTime ReturnDate,
    string Reason,
    string Status,
    bool IsActive,
    DateTime CreatedAt,
    string CreatedBy
);
