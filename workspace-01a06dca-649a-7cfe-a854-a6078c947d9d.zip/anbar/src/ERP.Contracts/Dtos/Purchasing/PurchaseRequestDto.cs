using System;

namespace ERP.Contracts.Dtos.Purchasing;

public record PurchaseRequestDto(
    int Id,
    int? CompanyId,
    int? BranchId,
    int RequesterId,
    string RequestNumber,
    DateTime RequestDate,
    string Status,
    bool IsActive,
    DateTime CreatedAt,
    string CreatedBy
);

public record RequestForQuotationDto(
    int Id,
    int? CompanyId,
    int? PurchaseRequestId,
    int? SupplierId,
    string RFQNumber,
    DateTime IssueDate,
    DateTime Deadline,
    string Status,
    bool IsActive,
    DateTime CreatedAt,
    string CreatedBy
);
