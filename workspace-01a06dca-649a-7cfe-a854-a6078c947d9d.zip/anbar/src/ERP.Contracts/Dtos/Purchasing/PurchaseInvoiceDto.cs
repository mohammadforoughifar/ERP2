using System;

namespace ERP.Contracts.Dtos.Purchasing;

public record PurchaseInvoiceDto(
    int Id,
    int? CompanyId,
    int SupplierId,
    int? PurchaseOrderId,
    int? GoodsReceiptId,
    string InvoiceNumber,
    DateTime InvoiceDate,
    DateTime DueDate,
    decimal SubTotal,
    decimal TaxAmount,
    decimal DiscountAmount,
    decimal TotalAmount,
    string Status,
    bool IsPosted,
    int? AccountingEntryId,
    bool IsActive,
    DateTime CreatedAt,
    string CreatedBy
);
