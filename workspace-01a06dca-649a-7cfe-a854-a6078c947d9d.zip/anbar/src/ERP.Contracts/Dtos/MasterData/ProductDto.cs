using System;

namespace ERP.Contracts.Dtos.MasterData;

public record ProductDto(
    int Id,
    int? CompanyId,
    string Code,
    string Name,
    string Barcode,
    string Brand,
    string Category,
    string Unit,
    string UnitGroup,
    bool IsBatchTracked,
    bool IsSerialTracked,
    bool HasExpiry,
    decimal Weight,
    bool IsActive,
    DateTime CreatedAt,
    string CreatedBy
);
