using System;

namespace ERP.Contracts.Dtos.MasterData;

public record SupplierDto(
    int Id,
    int? CompanyId,
    string Code,
    string Name,
    string LegalName,
    string NationalId,
    string TaxNumber,
    string Phone,
    string Email,
    string Address,
    bool IsActive,
    DateTime CreatedAt,
    string CreatedBy
);
