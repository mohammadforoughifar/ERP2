namespace ERP.Contracts.Dtos.Integration;
public class IntegrationLogDto { public int Id { get; set; } public string Name { get; set; } = string.Empty; public bool IsActive { get; set; } = true; }