using System;
using System.Collections.Generic;

namespace ERP.Contracts.Dtos.Sales;

public record InvoiceLineDto(
    int Id,
    int InvoiceId,
    int DeliveryLineId,
    int ProductId,
    int Quantity,
    decimal UnitPrice,
    decimal DiscountPercent,
    decimal LineSubTotal,
    decimal LineTaxAmount,
    decimal LineTotal
);

public record InvoiceDto(
    int Id,
    int? CompanyId,
    int? BranchId,
    int CustomerId,
    int? DeliveryId,
    int? SalesOrderId,
    string InvoiceNumber,
    DateTime InvoiceDate,
    DateTime DueDate,
    decimal SubTotal,
    decimal TaxAmount,
    decimal DiscountAmount,
    decimal TotalAmount,
    string Status,
    bool IsPosted,
    int? AccountingEntryId,
    bool IsActive,
    DateTime CreatedAt,
    string CreatedBy,
    List<InvoiceLineDto> Lines
);
