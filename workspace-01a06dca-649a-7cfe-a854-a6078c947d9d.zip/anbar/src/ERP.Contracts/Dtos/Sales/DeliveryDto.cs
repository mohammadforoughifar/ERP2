using System;

namespace ERP.Contracts.Dtos.Sales;

public record DeliveryDto(
    int Id,
    int? CompanyId,
    int? BranchId,
    int CustomerId,
    int SalesOrderId,
    string DeliveryNumber,
    DateTime DeliveryDate,
    string Status,
    bool IsActive,
    DateTime CreatedAt,
    string CreatedBy
);

public record DeliveryLineDto(
    int Id,
    int DeliveryId,
    int SalesOrderLineId,
    int ProductId,
    int DeliveredQuantity
);
