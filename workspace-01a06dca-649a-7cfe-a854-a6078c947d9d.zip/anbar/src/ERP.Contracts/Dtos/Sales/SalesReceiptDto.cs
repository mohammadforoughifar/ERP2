using System;

namespace ERP.Contracts.Dtos.Sales;

public record SalesReceiptDto(
    int Id,
    int? CompanyId,
    int? BranchId,
    int CustomerId,
    int? InvoiceId,
    string ReceiptNumber,
    DateTime ReceiptDate,
    decimal Amount,
    string PaymentMethod,
    int? CashAccountId,
    int? BankAccountId,
    int? CheckId,
    bool IsActive,
    DateTime CreatedAt,
    string CreatedBy
);
