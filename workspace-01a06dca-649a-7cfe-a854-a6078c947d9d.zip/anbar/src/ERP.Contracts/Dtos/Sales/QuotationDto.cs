using System;

namespace ERP.Contracts.Dtos.Sales;

public record QuotationDto(
    int Id,
    int? CompanyId,
    int? BranchId,
    int CustomerId,
    string QuotationNumber,
    DateTime QuotationDate,
    DateTime ValidUntil,
    decimal TotalAmount,
    string Status,
    bool IsActive,
    DateTime CreatedAt,
    string CreatedBy
);

public record SalesOrderDto(
    int Id,
    int? CompanyId,
    int? BranchId,
    int CustomerId,
    int? QuotationId,
    string OrderNumber,
    DateTime OrderDate,
    string Status,
    decimal TotalAmount,
    bool IsActive,
    DateTime CreatedAt,
    string CreatedBy
);

public record SalesOrderLineDto(
    int Id,
    int SalesOrderId,
    int ProductId,
    int Quantity,
    decimal UnitPrice,
    decimal DiscountPercent,
    decimal LineTotal
);
