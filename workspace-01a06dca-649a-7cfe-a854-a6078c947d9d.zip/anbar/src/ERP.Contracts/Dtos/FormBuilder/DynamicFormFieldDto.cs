namespace ERP.Contracts.Dtos.FormBuilder;

public class DynamicFormFieldDto
{
    public int Id { get; set; }
    public int DynamicFormId { get; set; }
    public string FieldName { get; set; } = string.Empty;
    public string FieldType { get; set; } = string.Empty;
    public string Label { get; set; } = string.Empty;
    public string? Placeholder { get; set; }
    public string? DefaultValue { get; set; }
    public string? Options { get; set; }
    public int SortOrder { get; set; }
    public bool IsRequired { get; set; }
    public bool IsVisible { get; set; }
    public bool IsDisabled { get; set; }
    public bool IsReadonly { get; set; }
    public string? ValidationRule { get; set; }
    public int? DependencyFieldId { get; set; }
    public string? DependencyCondition { get; set; }
    public bool IsActive { get; set; } = true;
}
