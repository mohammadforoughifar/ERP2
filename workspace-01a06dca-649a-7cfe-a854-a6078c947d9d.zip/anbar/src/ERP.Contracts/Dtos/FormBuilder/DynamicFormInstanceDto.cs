namespace ERP.Contracts.Dtos.FormBuilder;

public class DynamicFormInstanceDto
{
    public int Id { get; set; }
    public int DynamicFormId { get; set; }
    public string InstanceCode { get; set; } = string.Empty;
    public string Status { get; set; } = "Draft";
    public int CompanyId { get; set; }
    public int BranchId { get; set; }
    public int TenantId { get; set; }
    public bool IsActive { get; set; } = true;
}
