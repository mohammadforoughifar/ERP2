namespace ERP.Contracts.Dtos.FormBuilder;

public class DynamicFormDto
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public string? Description { get; set; }
    public string FormCode { get; set; } = string.Empty;
    public int CompanyId { get; set; }
    public int BranchId { get; set; }
    public int TenantId { get; set; }
    public bool IsActive { get; set; } = true;
}
