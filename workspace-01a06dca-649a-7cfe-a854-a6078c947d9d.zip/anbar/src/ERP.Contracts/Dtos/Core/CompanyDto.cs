using System;

namespace ERP.Contracts.Dtos.Core;

public record CompanyDto(
    int Id,
    int TenantId,
    string Name,
    string RegistrationNumber,
    string TaxNumber,
    bool IsActive,
    DateTime CreatedAt,
    string CreatedBy
);
