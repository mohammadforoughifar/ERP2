using System;

namespace ERP.Contracts.Dtos.Core;

/// <summary>
/// Tenant DTO for API / UI — Phase 1 Core
/// Per proposal: Multi-Tenant base
/// </summary>
public record TenantDto(
    int Id,
    string Name,
    string Code,
    bool IsActive,
    DateTime CreatedAt,
    string CreatedBy
);
