using System;

namespace ERP.Contracts.Dtos.Approval;

public record ApprovalRequestDto(
    int Id,
    int? CompanyId,
    int DocumentId,
    string DocumentType,
    int RequesterId,
    int? ApproverId,
    int? ApproverRoleId,
    decimal Amount,
    string Priority,
    string Reason,
    string Status,
    bool IsActive,
    DateTime CreatedAt,
    DateTime? DecidedAt,
    string CreatedBy
);

public record ApprovalHistoryDto(
    int Id,
    int ApprovalRequestId,
    int? UserId,
    string Action,
    string Comment,
    DateTime ActionDate,
    bool IsActive,
    DateTime CreatedAt,
    string CreatedBy
);
