using System;

namespace ERP.Contracts.Dtos.MRP;

public record MRPPlanDto(
    int Id,
    int? CompanyId,
    int? BranchId,
    string PlanNumber,
    DateTime PlanDate,
    DateTime AnalysisStartDate,
    DateTime AnalysisEndDate,
    string Status,
    bool IsActive,
    DateTime CreatedAt,
    string CreatedBy
);

public record MRPRecommendationDto(
    int Id,
    int MRPPlanId,
    int? CompanyId,
    int RecommendationType,
    int? ProductId,
    int? SupplierId,
    int RecommendedQuantity,
    DateTime RecommendedDate,
    DateTime? RequiredDate,
    decimal RecommendedCost,
    string Status,
    bool IsActive,
    DateTime CreatedAt,
    string CreatedBy
);
