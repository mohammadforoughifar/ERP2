using System;

namespace ERP.Contracts.Dtos.MRP;

public record MRPItemRequirementDto(
    int Id,
    int MRPPlanId,
    int? CompanyId,
    int ProductId,
    int DemandQuantity,
    int SupplyQuantity,
    int NetRequirement,
    int SafetyStock,
    int ReorderPoint,
    int LeadTimeDays,
    DateTime AnalysisDate,
    bool IsActive,
    DateTime CreatedAt,
    string CreatedBy
);

public record MRPAnalysisDto(
    int Id,
    int MRPPlanId,
    int? CompanyId,
    int? ProductId,
    string AnalysisType,
    string Description,
    int AffectedQuantity,
    DateTime AnalysisDate,
    bool IsActive,
    DateTime CreatedAt,
    string CreatedBy
);
