namespace ERP.Contracts.Dtos.Payroll;

public class SalaryDto
{
    public int Id { get; set; }
    public int EmployeeId { get; set; }
    public int ContractId { get; set; }
    public decimal BaseAmount { get; set; }
    public string Currency { get; set; } = "IRR";
    public string Status { get; set; } = "Active";
    public System.DateTime EffectiveFrom { get; set; }
    public System.DateTime? EffectiveTo { get; set; }
    public bool IsActive { get; set; } = true;
}
