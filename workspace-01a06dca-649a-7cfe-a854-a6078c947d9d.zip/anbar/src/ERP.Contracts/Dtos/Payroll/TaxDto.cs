namespace ERP.Contracts.Dtos.Payroll;

public class TaxDto
{
    public int Id { get; set; }
    public string TaxName { get; set; } = string.Empty;
    public decimal Rate { get; set; }
    public string Description { get; set; } = string.Empty;
    public string TaxType { get; set; } = "IncomeTax";
    public bool IsConfigurable { get; set; } = true;
    public bool IsActive { get; set; } = true;
}
