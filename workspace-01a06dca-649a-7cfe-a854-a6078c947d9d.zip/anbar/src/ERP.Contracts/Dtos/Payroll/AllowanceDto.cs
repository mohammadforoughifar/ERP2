namespace ERP.Contracts.Dtos.Payroll;

public class AllowanceDto
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public decimal Amount { get; set; }
    public string Type { get; set; } = "Fixed";
    public bool IsTaxable { get; set; } = true;
    public bool IsActive { get; set; } = true;
}
