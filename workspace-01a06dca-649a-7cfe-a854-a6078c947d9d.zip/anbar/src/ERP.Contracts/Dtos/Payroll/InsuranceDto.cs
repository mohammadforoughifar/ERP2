namespace ERP.Contracts.Dtos.Payroll;

public class InsuranceDto
{
    public int Id { get; set; }
    public string InsuranceName { get; set; } = string.Empty;
    public decimal Rate { get; set; }
    public string Description { get; set; } = string.Empty;
    public string InsuranceType { get; set; } = "Social";
    public bool IsActive { get; set; } = true;
}
