namespace ERP.Contracts.Dtos.Payroll;

public class BonusDto
{
    public int Id { get; set; }
    public int EmployeeId { get; set; }
    public string BonusName { get; set; } = string.Empty;
    public decimal Amount { get; set; }
    public System.DateTime BonusDate { get; set; }
    public string Reason { get; set; } = string.Empty;
    public string Status { get; set; } = "Pending";
    public bool IsActive { get; set; } = true;
}
