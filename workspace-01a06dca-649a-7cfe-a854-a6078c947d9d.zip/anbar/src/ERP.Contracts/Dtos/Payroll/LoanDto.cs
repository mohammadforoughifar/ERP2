namespace ERP.Contracts.Dtos.Payroll;

public class LoanDto
{
    public int Id { get; set; }
    public int EmployeeId { get; set; }
    public decimal LoanAmount { get; set; }
    public decimal RepaymentAmount { get; set; }
    public int RepaymentMonths { get; set; }
    public string Status { get; set; } = "Active";
    public System.DateTime StartDate { get; set; }
    public bool IsActive { get; set; } = true;
}
