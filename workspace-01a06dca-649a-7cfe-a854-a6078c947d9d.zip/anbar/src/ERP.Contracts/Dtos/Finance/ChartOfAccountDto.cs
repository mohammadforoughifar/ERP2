using System;

namespace ERP.Contracts.Dtos.Finance;

public record ChartOfAccountDto(
    int Id,
    int? CompanyId,
    int ParentId,
    string Code,
    string Name,
    int Level,
    int AccountType,
    bool IsCostCenterApplicable,
    bool IsProjectApplicable,
    bool IsActive,
    DateTime CreatedAt,
    string CreatedBy
);
