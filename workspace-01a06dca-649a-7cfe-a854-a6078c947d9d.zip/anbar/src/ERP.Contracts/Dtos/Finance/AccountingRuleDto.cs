using System;

namespace ERP.Contracts.Dtos.Finance;

public record AccountingRuleDto(
    int Id,
    int? CompanyId,
    string RuleName,
    string DocumentType,
    string Module,
    int DebitAccountId,
    int CreditAccountId,
    string ConditionExpression,
    bool IsActive,
    DateTime CreatedAt,
    string CreatedBy
);
