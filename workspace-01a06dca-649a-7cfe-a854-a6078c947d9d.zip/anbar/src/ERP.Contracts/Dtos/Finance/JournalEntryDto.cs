using System;
using System.Collections.Generic;

namespace ERP.Contracts.Dtos.Finance;

public record JournalLineDto(
    int ChartOfAccountId,
    decimal Amount,
    bool IsDebit,
    int? CostCenterId,
    int? ProjectId,
    int? BusinessPartnerId,
    string ReferenceDocument,
    string Description
);

public record JournalEntryDto(
    int Id,
    int? CompanyId,
    string DocumentNumber,
    DateTime EntryDate,
    string Description,
    string CurrencyCode,
    decimal ExchangeRate,
    bool IsPosted,
    bool IsReversed,
    int? ReversedByEntryId,
    bool IsActive,
    DateTime CreatedAt,
    string CreatedBy,
    List<JournalLineDto> Lines
);
