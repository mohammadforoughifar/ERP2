using System;

namespace ERP.Contracts.Dtos.CRM;

public record ActivityDto(
    int Id,
    int? CompanyId,
    int? AssignedToUserId,
    int? LeadId,
    int? OpportunityId,
    int? CustomerId,
    string Subject,
    int Type,
    DateTime DueDate,
    string Status,
    string Description,
    bool IsActive,
    DateTime CreatedAt,
    string CreatedBy
);

public record CampaignDto(
    int Id,
    int? CompanyId,
    string Name,
    string Type,
    DateTime StartDate,
    DateTime? EndDate,
    decimal Budget,
    string Status,
    bool IsActive,
    DateTime CreatedAt,
    string CreatedBy
);

public record Customer360Dto(
    int CustomerId,
    string CustomerName,
    string CustomerCode,
    string CustomerStatus,
    decimal TotalSalesAmount,
    decimal TotalPurchaseAmount,
    decimal CustomerBalance,
    int OpenOrdersCount,
    int OpenInvoicesCount,
    int OpenChecksCount,
    decimal CustomerProfitability,
    string LastActivityDate,
    string CreditStatus
);
