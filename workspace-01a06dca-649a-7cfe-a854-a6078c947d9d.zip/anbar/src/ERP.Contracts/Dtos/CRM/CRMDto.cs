using System;

namespace ERP.Contracts.Dtos.CRM;

public record LeadDto(
    int Id,
    int? CompanyId,
    int? AssignedToUserId,
    string FirstName,
    string LastName,
    string Email,
    string Phone,
    string Source,
    string Status,
    int? ConvertedCustomerId,
    bool IsActive,
    DateTime CreatedAt,
    string CreatedBy
);

public record OpportunityDto(
    int Id,
    int? CompanyId,
    int? LeadId,
    int? CustomerId,
    int AssignedToUserId,
    int? OpportunityStageId,
    string Title,
    decimal ExpectedValue,
    DateTime ExpectedCloseDate,
    string Status,
    decimal Probability,
    bool IsActive,
    DateTime CreatedAt,
    string CreatedBy
);

public record OpportunityStageDto(
    int Id,
    int? CompanyId,
    string Name,
    int Order,
    decimal Probability,
    bool IsActive,
    DateTime CreatedAt,
    string CreatedBy
);
