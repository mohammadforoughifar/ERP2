namespace ERP.Contracts.Dtos.Reporting;

public class ChartDto
{
    public int Id { get; set; }
    public int ReportId { get; set; }
    public string ChartName { get; set; } = string.Empty;
    public string ChartType { get; set; } = "Bar";
    public bool IsActive { get; set; } = true;
}
