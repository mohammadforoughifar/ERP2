namespace ERP.Contracts.Dtos.Reporting;

public class KPIDto
{
    public int Id { get; set; }
    public int DashboardId { get; set; }
    public string KPIName { get; set; } = string.Empty;
    public decimal TargetValue { get; set; }
    public decimal ActualValue { get; set; }
    public string Unit { get; set; } = string.Empty;
    public bool IsActive { get; set; } = true;
}
