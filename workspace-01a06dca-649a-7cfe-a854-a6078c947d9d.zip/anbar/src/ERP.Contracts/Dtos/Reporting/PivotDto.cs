namespace ERP.Contracts.Dtos.Reporting;

public class PivotDto
{
    public int Id { get; set; }
    public int ReportId { get; set; }
    public string PivotName { get; set; } = string.Empty;
    public string RowFields { get; set; } = string.Empty;
    public bool IsActive { get; set; } = true;
}
