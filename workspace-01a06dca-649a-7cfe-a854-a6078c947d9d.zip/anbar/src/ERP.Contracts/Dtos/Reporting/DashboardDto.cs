namespace ERP.Contracts.Dtos.Reporting;

public class DashboardDto
{
    public int Id { get; set; }
    public string DashboardName { get; set; } = string.Empty;
    public string? Description { get; set; }
    public string Status { get; set; } = "Active";
    public bool IsActive { get; set; } = true;
}
