namespace ERP.Contracts.Dtos.Reporting;

public class ReportDto
{
    public int Id { get; set; }
    public string ReportName { get; set; } = string.Empty;
    public string? Description { get; set; }
    public string ReportType { get; set; } = "Table";
    public string Status { get; set; } = "Draft";
    public bool IsActive { get; set; } = true;
}
