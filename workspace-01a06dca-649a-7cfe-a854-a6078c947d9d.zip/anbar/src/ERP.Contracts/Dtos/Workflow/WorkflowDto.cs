using System;

namespace ERP.Contracts.Dtos.Workflow;

public record WorkflowDefinitionDto(
    int Id,
    int? CompanyId,
    string WorkflowName,
    string DocumentType,
    string Module,
    bool IsActive,
    DateTime CreatedAt,
    string CreatedBy
);

public record WorkflowStepDto(
    int Id,
    int WorkflowDefinitionId,
    string StepName,
    int StepType,
    int Sequence,
    int? RequiredRoleId,
    int? RequiredUserId,
    string ConditionExpression,
    int? SLAInHours,
    int? EscalationUserId,
    bool SendNotification,
    bool IsActive,
    DateTime CreatedAt,
    string CreatedBy
);
