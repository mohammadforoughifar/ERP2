using System;

namespace ERP.Contracts.Dtos.Workflow;

public record WorkflowInstanceDto(
    int Id,
    int WorkflowDefinitionId,
    int? CompanyId,
    int DocumentId,
    string DocumentType,
    string Status,
    int CurrentStepSequence,
    DateTime StartedAt,
    DateTime? CompletedAt,
    bool IsActive,
    DateTime CreatedAt,
    string CreatedBy
);

public record WorkflowTaskDto(
    int Id,
    int WorkflowInstanceId,
    int? AssignedToUserId,
    int? AssignedToRoleId,
    string TaskType,
    string Status,
    DateTime AssignedAt,
    DateTime? CompletedAt,
    DateTime? DueDate,
    bool IsActive,
    DateTime CreatedAt,
    string CreatedBy
);
