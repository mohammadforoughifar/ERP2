using System;

namespace ERP.Contracts.Dtos.Production;

public record RoutingDto(
    int Id,
    int? CompanyId,
    int ProductId,
    string RoutingNumber,
    string Description,
    bool IsActive,
    DateTime CreatedAt,
    string CreatedBy
);

public record RoutingOperationDto(
    int Id,
    int RoutingId,
    int WorkCenterId,
    int Sequence,
    string OperationName,
    decimal StandardTime,
    decimal StandardCost,
    string Description
);
