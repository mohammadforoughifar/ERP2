using System;

namespace ERP.Contracts.Dtos.Production;

public record WorkCenterDto(
    int Id,
    int? CompanyId,
    string Code,
    string Name,
    string Type,
    decimal CapacityPerHour,
    bool IsActive,
    DateTime CreatedAt,
    string CreatedBy
);
