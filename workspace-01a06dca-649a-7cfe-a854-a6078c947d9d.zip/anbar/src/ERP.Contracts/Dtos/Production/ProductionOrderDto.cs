using System;

namespace ERP.Contracts.Dtos.Production;

public record ProductionOrderDto(
    int Id,
    int? CompanyId,
    int? BranchId,
    int ProductId,
    int? BOMId,
    int? RoutingId,
    string ProductionNumber,
    DateTime PlannedStartDate,
    DateTime PlannedEndDate,
    int PlannedQuantity,
    int ActualQuantity,
    string Status,
    bool IsActive,
    DateTime CreatedAt,
    string CreatedBy
);
