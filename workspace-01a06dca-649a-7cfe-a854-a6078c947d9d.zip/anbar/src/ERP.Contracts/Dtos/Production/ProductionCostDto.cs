using System;

namespace ERP.Contracts.Dtos.Production;

public record ProductionOrderLineDto(
    int Id,
    int ProductionOrderId,
    int ProductId,
    int LineType,
    int PlannedQuantity,
    int ActualQuantity,
    int? BatchId,
    int? SerialId,
    int WarehouseId
);

public record ProductionCostDto(
    int Id,
    int? CompanyId,
    int ProductionOrderId,
    decimal MaterialCost,
    decimal LaborCost,
    decimal MachineCost,
    decimal OverheadCost,
    decimal ActualTotalCost,
    decimal StandardTotalCost,
    decimal Variance,
    string CostStatus,
    bool IsActive,
    DateTime CreatedAt,
    string CreatedBy
);
