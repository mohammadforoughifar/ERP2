using System;

namespace ERP.Contracts.Dtos.Production;

public record BOMDto(
    int Id,
    int? CompanyId,
    int ProductId,
    int? ParentBOMId,
    int Level,
    string BOMNumber,
    string Description,
    decimal Quantity,
    bool IsActive,
    DateTime CreatedAt,
    string CreatedBy
);

public record BOMLineDto(
    int Id,
    int BOMId,
    int ComponentProductId,
    int ComponentQuantity,
    decimal ComponentUnitCost,
    int OperationSequence,
    int? ComponentBatchId
);
