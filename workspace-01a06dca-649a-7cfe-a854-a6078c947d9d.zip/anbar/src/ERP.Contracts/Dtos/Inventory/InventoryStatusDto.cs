using System;

namespace ERP.Contracts.Dtos.Inventory;

public record InventoryStatusDto(
    int Id,
    int? CompanyId,
    int ProductId,
    int? BatchId,
    int? SerialId,
    int WarehouseId,
    int Status,
    int Quantity,
    bool IsActive,
    DateTime CreatedAt,
    string CreatedBy
);
