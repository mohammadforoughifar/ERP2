using System;

namespace ERP.Contracts.Dtos.Inventory;

public record InventoryBatchDto(
    int Id,
    int? CompanyId,
    int ProductId,
    string BatchNumber,
    DateTime ProductionDate,
    DateTime ExpirationDate,
    DateTime? WarrantyExpiry,
    int WarehouseId,
    int CurrentQuantity,
    bool IsActive,
    DateTime CreatedAt,
    string CreatedBy
);

public record InventorySerialDto(
    int Id,
    int? CompanyId,
    int ProductId,
    string SerialNumber,
    DateTime ProductionDate,
    DateTime ExpirationDate,
    DateTime? WarrantyExpiry,
    int WarehouseId,
    int? BatchId,
    int? CustomerId,
    bool IsActive,
    DateTime CreatedAt,
    string CreatedBy
);
