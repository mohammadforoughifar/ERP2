using System;

namespace ERP.Contracts.Dtos.Inventory;

public record WarehouseDto(
    int Id,
    int? CompanyId,
    int? BranchId,
    string Code,
    string Name,
    string Address,
    bool IsDefault,
    bool IsActive,
    DateTime CreatedAt,
    string CreatedBy
);

public record InventoryTransactionDto(
    int Id,
    int? CompanyId,
    int? BranchId,
    int WarehouseId,
    int? SourceWarehouseId,
    int? TargetWarehouseId,
    int ProductId,
    int? BatchId,
    int? SerialId,
    int Quantity,
    int TransactionType,
    string ReferenceDocument,
    DateTime TransactionDate,
    string Status,
    bool IsActive,
    DateTime CreatedAt,
    string CreatedBy
);
