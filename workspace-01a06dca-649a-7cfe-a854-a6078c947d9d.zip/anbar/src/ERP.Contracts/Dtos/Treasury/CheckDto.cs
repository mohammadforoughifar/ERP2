using System;

namespace ERP.Contracts.Dtos.Treasury;

public record CheckDto(
    int Id,
    int? CompanyId,
    int? BranchId,
    string CheckNumber,
    string BankName,
    string BankBranch,
    string AccountNumber,
    string Shaba,
    string CheckBook,
    DateTime IssueDate,
    DateTime DueDate,
    decimal Amount,
    int Status, // CheckStatus enum value
    int? RelatedCustomerId,
    int? RelatedSupplierId,
    int? RelatedDocumentId,
    bool IsEndorsed,
    string EndorsementNote,
    DateTime? SettlementDate,
    string Notes,
    bool IsActive,
    DateTime CreatedAt,
    string CreatedBy
);
