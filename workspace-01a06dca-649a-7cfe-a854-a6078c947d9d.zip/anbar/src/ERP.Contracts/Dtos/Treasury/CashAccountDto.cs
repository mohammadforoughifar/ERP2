using System;

namespace ERP.Contracts.Dtos.Treasury;

public record CashAccountDto(
    int Id,
    int? CompanyId,
    int? BranchId,
    string Code,
    string Name,
    string CurrencyCode,
    decimal OpeningBalance,
    bool IsActive,
    DateTime CreatedAt,
    string CreatedBy
);
