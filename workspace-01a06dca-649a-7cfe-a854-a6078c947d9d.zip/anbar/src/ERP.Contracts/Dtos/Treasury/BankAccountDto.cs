using System;

namespace ERP.Contracts.Dtos.Treasury;

public record BankAccountDto(
    int Id,
    int? CompanyId,
    int? BranchId,
    string BankName,
    string BankBranch,
    string AccountNumber,
    string Shaba,
    string CurrencyCode,
    decimal OpeningBalance,
    bool IsActive,
    DateTime CreatedAt,
    string CreatedBy
);
