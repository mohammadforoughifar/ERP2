using System;

namespace ERP.Contracts.Dtos.Treasury;

public record PaymentDto(
    int Id,
    int? CompanyId,
    int? BranchId,
    string DocumentNumber,
    int Type, // PaymentType enum value
    DateTime PaymentDate,
    int? CashAccountId,
    int? BankAccountId,
    int? CheckId,
    int? RelatedCustomerId,
    int? RelatedSupplierId,
    decimal Amount,
    string CurrencyCode,
    string Description,
    bool IsReconciled,
    bool IsActive,
    DateTime CreatedAt,
    string CreatedBy
);
