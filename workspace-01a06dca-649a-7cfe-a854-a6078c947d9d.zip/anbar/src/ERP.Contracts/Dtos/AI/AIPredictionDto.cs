namespace ERP.Contracts.Dtos.AI;

public class AIPredictionDto
{
    public int Id { get; set; }
    public string PredictionType { get; set; } = string.Empty;
    public decimal PredictedValue { get; set; }
    public decimal ActualValue { get; set; }
    public System.DateTime PredictionDate { get; set; }
    public string Status { get; set; } = "Pending";
    public bool IsActive { get; set; } = true;
}
