namespace ERP.Contracts.Dtos.AI;

public class AIAnalysisDto
{
    public int Id { get; set; }
    public string AnalysisType { get; set; } = string.Empty;
    public string? RelatedEntity { get; set; }
    public string AnalysisResult { get; set; } = string.Empty;
    public string Status { get; set; } = "Draft";
    public bool IsActive { get; set; } = true;
}
