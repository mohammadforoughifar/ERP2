namespace ERP.Contracts.Dtos.AI;

public class AIInsightDto
{
    public int Id { get; set; }
    public string InsightTitle { get; set; } = string.Empty;
    public string InsightContent { get; set; } = string.Empty;
    public string Priority { get; set; } = "Medium";
    public string? RelatedEntity { get; set; }
    public bool IsActive { get; set; } = true;
}
