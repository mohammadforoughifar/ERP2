namespace ERP.Contracts.Dtos.AI;

public class AIAgentDto
{
    public int Id { get; set; }
    public string AgentName { get; set; } = string.Empty;
    public string? Description { get; set; }
    public string Capabilities { get; set; } = string.Empty;
    public string Status { get; set; } = "Active";
    public bool IsActive { get; set; } = true;
}
