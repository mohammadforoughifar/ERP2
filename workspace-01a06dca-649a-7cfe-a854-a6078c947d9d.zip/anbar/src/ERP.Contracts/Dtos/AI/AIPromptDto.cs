namespace ERP.Contracts.Dtos.AI;

public class AIPromptDto
{
    public int Id { get; set; }
    public int AgentId { get; set; }
    public string PromptText { get; set; } = string.Empty;
    public string Intent { get; set; } = "Unknown";
    public string Status { get; set; } = "Pending";
    public bool IsActive { get; set; } = true;
}
