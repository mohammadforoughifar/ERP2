namespace ERP.Contracts.Dtos.AI;

public class AIResponseDto
{
    public int Id { get; set; }
    public int PromptId { get; set; }
    public string ResponseText { get; set; } = string.Empty;
    public decimal ConfidenceScore { get; set; }
    public string? ChartReference { get; set; }
    public string Status { get; set; } = "Generated";
    public bool IsActive { get; set; } = true;
}
