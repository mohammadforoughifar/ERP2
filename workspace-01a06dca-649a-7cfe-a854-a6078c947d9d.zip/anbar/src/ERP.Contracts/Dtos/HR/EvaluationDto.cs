namespace ERP.Contracts.Dtos.HR;

public class EvaluationDto
{
    public int Id { get; set; }
    public int EmployeeId { get; set; }
    public string Title { get; set; } = string.Empty;
    public int Score { get; set; }
    public string Comments { get; set; } = string.Empty;
    public System.DateTime EvaluationDate { get; set; }
    public string Status { get; set; } = "Draft";
    public bool IsActive { get; set; } = true;
}
