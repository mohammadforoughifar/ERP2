using System;

namespace ERP.Contracts.Dtos.HR;

public record EmployeeDto(
    int Id,
    int? CompanyId,
    string FirstName,
    string LastName,
    string StaffNumber,
    string NationalId,
    string Phone,
    string Email,
    string Address,
    int? DepartmentId,
    int? PositionId,
    DateTime HireDate,
    DateTime? TerminationDate,
    bool IsActive,
    DateTime CreatedAt,
    string CreatedBy
);

public record ContractDto(
    int Id,
    int? CompanyId,
    int EmployeeId,
    int ContractType,
    string ContractNumber,
    DateTime StartDate,
    DateTime? EndDate,
    DateTime? RenewalDate,
    decimal BaseSalary,
    bool IsActive,
    DateTime CreatedAt,
    string CreatedBy
);

public record AttendanceDto(
    int Id,
    int? CompanyId,
    int EmployeeId,
    DateTime Date,
    int Status,
    int? HoursWorked,
    int? OvertimeHours,
    bool IsActive,
    DateTime CreatedAt,
    string CreatedBy
);
