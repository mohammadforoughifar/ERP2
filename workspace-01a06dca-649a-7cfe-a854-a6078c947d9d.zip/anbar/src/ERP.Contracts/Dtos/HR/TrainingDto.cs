namespace ERP.Contracts.Dtos.HR;

public class TrainingDto
{
    public int Id { get; set; }
    public int EmployeeId { get; set; }
    public string Title { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public System.DateTime StartDate { get; set; }
    public System.DateTime EndDate { get; set; }
    public string Status { get; set; } = "Scheduled";
    public bool IsActive { get; set; } = true;
}
