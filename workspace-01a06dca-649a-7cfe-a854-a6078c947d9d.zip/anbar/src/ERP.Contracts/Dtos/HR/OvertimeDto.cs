namespace ERP.Contracts.Dtos.HR;

public class OvertimeDto
{
    public int Id { get; set; }
    public int EmployeeId { get; set; }
    public System.DateTime WorkDate { get; set; }
    public decimal Hours { get; set; }
    public string Status { get; set; } = "Pending";
    public bool IsActive { get; set; } = true;
}
