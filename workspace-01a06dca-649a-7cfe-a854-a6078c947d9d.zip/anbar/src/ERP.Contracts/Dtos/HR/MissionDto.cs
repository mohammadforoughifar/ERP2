namespace ERP.Contracts.Dtos.HR;

public class MissionDto
{
    public int Id { get; set; }
    public int EmployeeId { get; set; }
    public string Destination { get; set; } = string.Empty;
    public System.DateTime StartDate { get; set; }
    public System.DateTime EndDate { get; set; }
    public string Purpose { get; set; } = string.Empty;
    public string Status { get; set; } = "Pending";
    public bool IsActive { get; set; } = true;
}
