using System;

namespace ERP.Contracts.Dtos.HR;

public record LeaveDto(
    int Id,
    int? CompanyId,
    int EmployeeId,
    int LeaveType,
    DateTime StartDate,
    DateTime EndDate,
    int Days,
    string Reason,
    string Status,
    bool IsActive,
    DateTime CreatedAt,
    string CreatedBy
);

namespace ERP.Contracts.Dtos.Payroll;

public record PayrollRunDto(
    int Id,
    int? CompanyId,
    string PayrollNumber,
    DateTime PeriodStart,
    DateTime PeriodEnd,
    DateTime RunDate,
    string Status,
    bool IsActive,
    DateTime CreatedAt,
    string CreatedBy
);

public record PayslipDto(
    int Id,
    int PayrollRunId,
    int EmployeeId,
    int ContractId,
    decimal BaseSalary,
    decimal Allowances,
    decimal Deductions,
    decimal Bonus,
    decimal Tax,
    decimal Insurance,
    decimal NetPay,
    string Status,
    bool IsActive,
    DateTime CreatedAt,
    string CreatedBy
);
