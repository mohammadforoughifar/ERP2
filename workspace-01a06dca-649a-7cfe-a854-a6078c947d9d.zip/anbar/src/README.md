ERP Enterprise — .NET 8 + Blazor + Clean Architecture

وضعیت:
- Workspace کاملاً پاک و ساختار جدید ایجاد شده (بدون هیچ `.assets.json` فیک)
- پروژه‌ها (`ERP.Web`, `ERP.API`, `ERP.Application`, `ERP.Domain`, `ERP.Infrastructure`, `ERP.Contracts`, `ERP.Shared`, `ERP.Modules.*`) ساخته شده
- `ARCHITECTURE_DECISIONS.md` طراحی معماری کامل ثبت شده
- `nuget.config` با منبع `nuget.org` آماده است

آنچه باید توسط کاربر اجرا شود (در محیط با `dotnet` نصب شده):

# ۱. بازیابی پکیج‌ها
cd /home/user/anbar/src/ERP.Web
rm -rf obj bin
dotnet restore ERP.Web.csproj --force

# ۲. ساخت (بدون خطای ResolvePackageAssets)
dotnet build ERP.Web.csproj --no-restore

# ۳. اجرای Migration (در صورت نیاز)
# dotnet ef database update --project ../ERP.Infrastructure/ERP.Infrastructure.csproj --startup-project ERP.Web/ERP.Web.csproj

نکته مهم:
در این محیط (`dotnet` نصب نیست) فقط ساختار کد تمیز ایجاد شده است. هیچ فایل فیک ساخته نشده. ارور `ResolvePackageAssets` فقط با `dotnet restore` واقعی برطرف می‌شود.
