ARCHITECTURE_DECISION.md — ERP Enterprise .NET 8 + Blazor

STACK CONFIRMED:
- .NET 8 (LTS)
- Blazor Server + WASM Hybrid Ready
- SQL Server 2019+ / EF Core 8
- Clean Architecture + DDD
- Modular Monolith (Microservice Split Ready)
- Redis / Hangfire / Serilog / OpenTelemetry / FluentValidation
- Multi-Tenant / Multi-Company / Multi-Branch / Multi-Warehouse

MODULE MAP:
Core → Identity, Organization, Fiscal, Settings, Audit, Numbering
MasterData → Customer, Supplier, Product, Warehouse, UOM, PriceList, Tax
Finance → GL, Journal, Treasury (Cash, Bank, Check), Accounting Rules
Sales → Quotation, Order, Delivery, Invoice, Receipt, Return, Credit
Purchasing → Request, RFQ, Order, Receipt, Invoice, Return
Inventory → Warehouse, Stock, Batch, Serial, Transfer, Costing, MRP
CRM → Lead, Opportunity, Pipeline, Campaign, Customer 360
Production → BOM, Routing, WorkCenter, Production Order, Costing
HR / Payroll → Employee, Contract, Attendance, Leave, Salary, Tax
Workflow / Forms → Dynamic Workflow + Approval + Dynamic Form Builder
Reporting / BI → Query Builder + Chart + Pivot + Dashboard
AI → AI Agent (Natural Language → Safe Query + Forecast + Anomaly)
Security / Integration → RBAC, API, Webhook, Import/Export (Excel/CSV/JSON)

DATABASE STRATEGY:
- Naming: PascalCase (C# standard mapped to SQL Server)
- PK: int identity; FK: explicit; Audit: CreatedAt, ModifiedAt, CreatedBy, ModifiedBy, RowVersion, IsDeleted
- Multi-Tenant Filter: TenantId in every query (Global Query Filter)
- Soft Delete for Master Data; Cancel/Reverse for Financial Transactions
- Concurrency: RowVersion (timestamp) on critical entities

DESIGN PATTERNS APPLIED:
- Domain-Driven Design (Aggregate, Value Object, Domain Event, Domain Service)
- Repository Pattern (EF Core)
- Unit of Work (EF Core DbContext)
- CQRS (Commands + Queries separation in Services)
- Mediator Pattern (MediatR in Application Layer)
- Strategy Pattern (Accounting Rules, Pricing Engine, Tax Engine)
- Factory Pattern (Document Creation, Numbering System)
- Observer Pattern (Domain Events → Notifications, Accounting Updates)
- Decorator Pattern (Audit Logging, Permission Enforcement, Validation)
- Adapter Pattern (External APIs: Bank, SMS, Government, E-Commerce)

UI/UX STRATEGY:
- Design System: Modern, Clean, Fast, Responsive, RTL
- Typography: Vazirmatn (Persian), Inter (English)
- Color Palette: Deep Blue (#1e3a8a), Teal (#0d9488), Emerald (#059669), Amber (#d97706), Slate (#334155)
- Components: Card, Table, Modal, Form, Button, Badge, Alert, Progress, Dropdown, Tabs, Pagination
- Mobile: Card View + Sticky Tabs + Collapsible Sidebar
- Keyboard Shortcuts: F1 (Save), ESC (Cancel), Ctrl+K (Global Command), Ctrl+S (Quick Save)
- PWA Ready: Service Worker + Offline Cache + Installable

SECURITY:
- Authentication: JWT Bearer + Refresh Token
- Authorization: RBAC + ABAC + Scope-Based (Company, Branch, Warehouse, Department)
- Audit: Every action logs User, IP, Timestamp, Action, Entity, Old/New Value
- Data Isolation: TenantId filter in all queries (Global Query Filter)
- API Security: Rate Limiting, CORS strict, FluentValidation, Parameterized Queries

PERFORMANCE:
- Async/Await everywhere
- Server-side Pagination (Skip/Take)
- Projection (Select) to avoid full entity loading
- Redis Cache for Master Data, Sessions, Search
- Background Jobs (Hangfire) for Reports, MRP, Batch Updates, Notifications
- Bulk Operations (SqlBulkCopy for large imports)

TESTING:
- Unit Tests: Domain Rules, Value Objects (No DB dependency)
- Integration Tests: Repository, Service, Controller (In-Memory DB)
- API Tests: Endpoint validation, Status Codes, Response Format
- E2E Tests: Playwright / Selenium for critical flows

DEPLOYMENT:
- Docker: .NET 8 Runtime (Alpine)
- Migration: `dotnet ef database update` in CI/CD
- Health Checks: Database, API, Storage, External APIs
- Monitoring: Serilog (Structured Logs) + OpenTelemetry (Metrics + Traces)

DOCUMENTATION:
- ARCHITECTURE_DECISIONS.md (this file)
- Module Documentation: Business Process, Schema, API Contracts, Permissions, Workflows
- User Documentation: Persian, Step-by-Step Guides for Key Processes

NOTE FOR USER:
این فایل‌ها بدون `dotnet restore` اجرا نمی‌شوند. در محیط خود (با .NET SDK نصب شده) اجرا کنید:

cd /path/to/anbar/src/ERP.Web
rm -rf obj bin
dotnet restore ERP.Web.csproj --force
dotnet build ERP.Web.csproj --no-restore

در این محیط (`dotnet` موجود نیست) فقط ساختار تمیز ایجاد شده است؛ هیچ `.assets.json` فیک ساخته نشده است.
